# Known Limitations and Untested Behaviour

## Untested (status NOT RUN)

1. **No physical ARCore device was available** (`adb devices` listed none). Therefore AR plane detection,
   camera background, anchors (`AttachAnchor`, `TryAddAnchorAsync`, `TryRemoveAnchor`), tracking-loss
   handling with real ARCore states, touch input on a real touchscreen, safe-area layout on notched phones,
   performance/frame rate and the outline on a mobile GPU (OpenGLES3) were **not executed**. The APK builds
   and the code paths are covered by Editor tests with substitutes (physics floor, injected pointers, pure
   state mapping), but that is not device evidence.
2. The outline was visually verified only in Editor renders (Metal). Its shaders compile without errors for
   the project and target only core URP HLSL features, but the GLES3 variant has not been seen on screen.

## Environment deviations

3. **Unity version is not LTS.** CLAUDE.md asks for an LTS release; the only installed editor with Android
   support is **6000.6.5f1** (Unity 6.6, *Supported* stream; current LTS lines are 6000.3.x and 6000.0.x).
   AR Foundation/ARCore 6.6.2 were chosen because they match this editor and compile against URP 17.6.
   Moving to 6000.3 LTS would require AR Foundation/ARCore 6.3.x and re-running the setup wizard and tests.
4. **Project path contains a colon** (`AR:VR_Project`). Unity cannot open such a path; rename the folder or
   open it through a colon-free symbolic link (see README). Batch builds/tests were run through a link.
5. The APK is signed with the **Android debug keystore** (fine for `adb install`, not for Google Play).
   Configure a release keystore in *Player Settings → Publishing Settings* for distribution.

## Behavioural limitations

6. `android.permission.INTERNET` is present in the APK although the app does not use networking. Unity adds
   it automatically (*Internet Access: Auto*) because engine modules required by AR Foundation are linked.
   It is a normal (install-time) permission; removing it would need a custom manifest with `tools:node="remove"`.
7. Placement is limited to **horizontal, upward-facing planes** (floors, table tops); wall-mounted placement is
   not supported.
8. Placed furniture is **not persisted** between sessions.
9. Rotation around X/Z can tilt furniture; surface moves keep the item’s base on the surface height but do not
   resolve interpenetration with the floor or other furniture (no physics collision between items).
10. Two-finger twist always rotates around the vertical (local Y) axis; one-finger rotation uses the selected axis.
11. The outline appends materials to each renderer; it assumes one sub-mesh per renderer. All generated models
    satisfy this and the validator enforces it; imported multi-sub-mesh models would only outline their last sub-mesh.
12. In Move mode the gizmo handles take priority over furniture when a touch starts on a handle.
13. Demo mode on a phone uses a fixed camera (orbit/zoom is mouse-only).
14. The models are procedural (no sculpted detail, no normal maps); thumbnails are CPU-rendered with flat shading.
15. Re-running the setup wizard **rebuilds both scenes**; manual edits to the scenes would be overwritten, and
    scene YAML diffs are large because object IDs are regenerated.
16. Asset/scene EditMode tests require the generated content (already committed); on a fresh checkout without
    it, run *AR Interior → 2. Run Full Setup* first.
17. Screenshot capture tests are opt-in (`-captureScreenshots`) and report as *skipped* otherwise.

## Unresolved defects

None known at delivery time. Defects found and fixed during development are listed in
[TEST_REPORT.md](TEST_REPORT.md#defects-found-and-fixed).
