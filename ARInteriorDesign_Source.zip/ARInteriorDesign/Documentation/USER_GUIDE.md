# User Guide

## Installing

1. Use an [ARCore-supported](https://developers.google.com/ar/devices) Android phone (Android 8.0+, 64-bit).
2. Enable *Developer options → USB debugging*, connect the phone and run:
   ```bash
   adb install -r ARInteriorDesign.apk
   ```
3. Start **AR Interior Design** and allow camera access. If Google Play Services for AR is missing or
   outdated, the app shows *Installing AR services…* and Android offers the install/update.

Phones without ARCore can install the app too: the status shows **AR not supported** and the **Demo**
button (top right, highlighted) opens the virtual room.

## Screen layout

| Area | Purpose |
|---|---|
| Top bar | Title, status pill (green = ready, amber = scanning/initialising, orange = tracking lost, red = not supported), *Selected: name · size*, **Demo/AR** scene switch |
| Guidance banner | The next useful step or the reason tracking is limited (touches pass through it) |
| Tool bar (right) | **Select**, **Move**, **Rotate**, **Scale**, **Delete** |
| Tool options (above catalogue) | Move: *Floor / X / Y / Z*; Rotate: *X / Y / Z* + *Snap 15° On/Off*; Scale: *Size %* + *Reset size* |
| Catalogue (bottom) | Modern Chair, Dining Table, Sofa, Floor Lamp, Bookshelf — scroll sideways |

## 1. Scan the room

Point the camera at the floor and move the phone slowly from side to side. When ARCore finds a surface it is
shown as an amber grid with a light outline and the status turns green: *Tracking · N surfaces*.

Tips shown by the banner: *Too dark* → switch on lights; *Point at textured surfaces* → aim at a rug or
patterned floor; *Moving too fast* → slow down.

## 2. Place furniture

1. Tap a card in the catalogue (it turns amber). Tap it again to cancel.
2. Tap a highlighted surface. The item appears there, facing you, already selected.
3. One tap places one item; to place another, choose a card again.

## 3. Select and deselect

* Tap any placed item to select it — it gets a **yellow-orange outline** and its name/size appear in the top bar.
* Tap empty space to deselect.

## 4. Move

Choose **Move**. X/Y/Z arrows appear on the selected item.

* **Floor** (default): drag anywhere — the item slides along the floor under your finger. Dragging another
  item selects and moves that one.
* **X / Y / Z**: restricts the drag to the item’s red (X), green (Y, up/down) or blue (Z) axis.
* Or drag an arrow directly to move along that axis.

## 5. Rotate

Choose **Rotate**, pick the axis (**Y** = turn around, default) and drag sideways (drag up/down for X).
Turn **Snap 15°** on for exact steps of 15°. Two fingers twisting on the screen also turn the item around Y.

## 6. Scale

Choose **Scale** and drag up to enlarge or down to shrink, or pinch with two fingers. Size is uniform and
limited per item (e.g. sofa 50–150 %). **Reset size** returns to 100 %.

## 7. Delete

Select an item and tap **Delete**. The button is disabled when nothing is selected.

## Demo mode (Editor or non-AR phone)

Tap **Demo** (or open `DemoScene` in Unity). The virtual floor and rug act as detected surfaces.
In the Editor: left mouse = finger, right-drag = orbit, scroll = zoom. Tap **AR** to return to the AR scene.

## Troubleshooting

| Symptom | What to do |
|---|---|
| “Scanning for surfaces” never ends | Better light, textured floor, move slowly, keep 0.5–3 m from the floor |
| “Tracking lost” | Point back at the scanned area; furniture stays where it was |
| “No surface detected there” | Tap on a highlighted grid, not on walls or empty space |
| “Limit of 25 items reached” | Delete something first |
| Nothing happens when dragging | Select an item first, and pick Move/Rotate/Scale (Select mode only selects) |
