# Test Report

Date: 2026-10-23 · Unity 6000.6.5f1 (batch mode, macOS arm64, Metal) · active build target Android.
Statuses: **PASSED** = executed and passed, **FAILED** = executed and failed, **NOT RUN** = could not be executed.

## Summary

| Check | Status | Evidence |
|---|---|---|
| Package resolution (AR Foundation 6.6.2, ARCore 6.6.2, URP 17.6.0, Input System 1.20.1 …) | PASSED | `Done resolving packages`, lock file committed |
| Script compilation (all 4 project assemblies) | PASSED | 0 errors, 0 warnings in `Assets/ARInterior` |
| Setup wizard (`RunFullSetupBatch`) incl. re-run for idempotency | PASSED | exit 0, “Validation PASSED”, no duplicates after 2nd run |
| Project validator (catalogue, prefabs, dimensions, pivots, colliders, materials, outline shader/colour, URP feature, XR loader, Android settings, build scenes, null references, button wiring) | PASSED | 0 problems |
| EditMode tests | PASSED | **68 / 68** |
| PlayMode tests | PASSED | **21 / 21** passed, 2 opt-in screenshot tests skipped by design |
| Screenshot capture (opt-in) | PASSED | 2 / 2, images in `Documentation/Screenshots` |
| Android APK build (IL2CPP, ARM64) | PASSED | `Build Finished, Result: Success`; `Builds/Android/ARInteriorDesign.apk`, 35 441 428 bytes, SHA-256 `d8827d9f407f82053907aa592e30fc9e004c16c39b210a70f27345f94d28b9e2` |
| APK inspection (`aapt2`, `apksigner`) | PASSED | package `com.university.arinteriordesign`, minSdk 26, targetSdk 36, `arm64-v8a`, `libUnityARCore.so` present, v2 signature (debug certificate) |
| Source ZIP extracted into a clean folder → open, compile, validate | PASSED | exit 0, “Validation PASSED” (all `.meta` files and references resolve) |
| Install / run on a physical ARCore device | **NOT RUN** | no device connected (`adb devices` empty) |
| Real ARCore plane detection, anchors, tracking loss | **NOT RUN** | requires a device |
| Outline on a mobile GPU (GLES3) | **NOT RUN** | verified only in Editor (Metal) renders |
| Performance / frame rate on device | **NOT RUN** | requires a device |

## How to reproduce

```bash
P=<colon-free path to the project>
U=/Applications/Unity/Hub/Editor/6000.6.5f1/Unity.app/Contents/MacOS/Unity
$U -batchmode -projectPath $P -buildTarget Android -executeMethod ARInterior.EditorTools.Setup.ProjectSetupWizard.RunFullSetupBatch -logFile setup.log
$U -batchmode -projectPath $P -buildTarget Android -executeMethod ARInterior.EditorTools.Setup.ProjectValidator.ValidateBatch -logFile validate.log
$U -batchmode -projectPath $P -buildTarget Android -runTests -testPlatform EditMode -assemblyNames ARInterior.Tests.EditMode -testResults editmode.xml
$U -batchmode -projectPath $P -buildTarget Android -runTests -testPlatform PlayMode -assemblyNames ARInterior.Tests.PlayMode -testResults playmode.xml
$U -batchmode -projectPath $P -buildTarget Android -executeMethod ARInterior.EditorTools.Setup.AndroidBuilder.BuildApkBatch -logFile build.log
```

Exit codes: wizard/validator 0 = pass, 2 = validation problems; builder 0 = success, 3 = build failed; test runner 0 = all passed, 2 = failures.

## EditMode tests (68) — all PASSED

| Fixture | Cases | What is verified (expected = actual) |
|---|---|---|
| `ManipulationMathTests` | 17 | 15° snapping (7 angles incl. negatives), positive clamped scale incl. NaN and invalid limits, drag→scale (×2 / ×0.5), drag→degrees, twist angle, pinch ratio, ray–axis closest point and parallel rejection, ray–floor intersection, yaw-only camera facing |
| `GestureRecognizerTests` | 11 | single tap; UI-started touch never reaches the scene; duplicate *Began* → one tap; long press is not a tap; drag threshold / update / end; rejected drag ignored until release; cancel → drag cancel; vanished pointer → cancel; second finger ends drag, starts pinch, remaining finger ignored; external cancel stops updates; reset cancels |
| `StatusAndGuidanceTests` | 8 | AR state mapping (unsupported → demo hint, tracking without planes → scanning, planes → ready “Tracking · 2 surfaces”, lost + low light → “Too dark”, installing); guidance priorities |
| `TransformControllerTests` | 9 | owner lock rejects a second owner and non-owner writes; kind-specific operations; continuous and 15°-snapped rotation; local-axis rotation; uniform positive clamped scale; cancel restores pose; reset refused during a gesture; NaN ignored |
| `MeshBuilderTests` | 15 | outward winding and normals for box, rotated box, rounded box, cylinder, frustum, sphere; smoothed normals; UV3 outline channel; rounded box size |
| `ProjectAssetTests` | 8 | catalogue has the 5 required, distinct, resolvable prefabs + thumbnails; validator clean; ≥ 4 components, > 100 triangles, ≥ 2 materials per model; real-world dimensions within 4 cm and pivot on the floor; outline shaders compile + #FFB000 + render order; URP/XR/Android settings; both scenes complete; font has every HUD glyph |

## PlayMode tests (21 + 2 opt-in) — all PASSED

Run in the real `DemoScene`/`MainARScene` (Editor play mode, 640×480 batch screen).

| Test | Expected | Actual |
|---|---|---|
| `Scene_StartsReady_WithEveryControlConnected` | Demo status, Select mode, all ≥ 20 buttons bound at runtime, 5 catalogue items | as expected |
| `Placement_PutsArmedItemOnTheFloorAndSelectsIt` | item at tap point on the rug (y = 0.008), selected, disarmed, facing camera | as expected |
| `Placement_RepeatedTapsDoNotDuplicate` | same-frame and within-cooldown taps ignored; tap after 0.35 s places | 1 → 1 → 2 items |
| `Placement_OutsideTheRoom_ExplainsWhy` | no item, feedback message | as expected |
| `Selection_ShowsYellowOrangeOutlineAndDeselectRestoresMaterials` | outline + mask materials on every renderer, colour #FFB000, shader supported; deselect restores arrays; reselect works | as expected |
| `Move_SurfaceDragFollowsTheFloor` | gizmo visible, item follows floor with grab offset (±3 cm), lock released | as expected |
| `Move_AxisYLiftsWithoutSideways` | +0.5 m height, x/z unchanged | as expected |
| `Move_GrabbingAGizmoHandleUsesThatAxis` | X handle picked, movement only along local X | as expected |
| `Rotate_SnapsToFifteenDegrees` | 36° drag → 30° | as expected |
| `Rotate_WithoutSnapIsContinuous` | 18° drag → 18° | as expected |
| `Scale_IsUniformAndClampedToLimits` | clamps to max 1.3 / min 0.5, uniform, reset → 1 | as expected |
| `TwoFingerPinch_ScalesSelectedItem` | 1.5× finger distance → scale 1.5 | as expected |
| `TwoFingerTwist_RotatesAroundVerticalAxis` | 30° twist → 30° yaw, no tilt, no scale change | as expected |
| `Delete_RemovesItemAndClearsSelection` | selection/outline/gizmo cleared, object destroyed, second delete safe | as expected |
| `TransformLock_BlocksASecondHandler` | drag refused while another owner holds the lock | as expected |
| `ModeChange_DuringDrag_EndsTheGestureCleanly` | lock released, stale updates rejected, no unintended scale | as expected |
| `UiTouch_HasPriorityOverTheScene` | tap on *Move Tool* through the real router places nothing; tap on open floor places 1 | as expected |
| `RouterDrag_MovesSelectedItemThroughRealInputPath` | scripted pointer drag via TouchInputRouter moves item +0.6 m | as expected |
| `HudButtons_DriveTheTools` | every tool, axis chip, snap toggle, catalogue card toggle and delete button performs its action | as expected |
| `SwitchButton_LoadsTheARScene` | MainARScene becomes active | as expected |
| `MainARScene_WithoutARSupport_BlocksInteractionGracefully` | status *Unsupported* (not stuck in *Checking*), Demo button highlighted, taps/drags refused | as expected |
| `DocumentationScreenshots.*` (opt-in) | 6 PNGs rendered through URP incl. HUD | rendered; skipped in normal runs |

## Visual verification (Editor render, not device)

`Documentation/Screenshots/` — 01 select mode, 02 move mode with outline and X/Y/Z arrows, 03 rotate mode
(sofa outline, axis Y, snap on), 04 scale mode, 05 catalogue armed, 06 AR scene without AR support.
Observed: continuous #FFB000 silhouette outline without interior lines; gizmo drawn on top; HUD texts,
icons and thumbnails render; active tool and options highlighted.

## Defects found and fixed

| # | Found by | Defect | Fix |
|---|---|---|---|
| 1 | first compile | `UniversalRenderPipelineAsset.supportsMainLightShadows` is read-only in URP 17.6 | removed the assignment (default already on) |
| 2 | compiler warnings | obsolete `AssetDatabase.ImportPackage`, `FindObjectsByType(…, SortMode)`, `FindFirstObjectByType` | switched to `AssetPackage.Package.Import`, `FindObjectsByType(FindObjectsInactive)`, `FindAnyObjectByType` |
| 3 | validator | `PlacementController.m_Catalog` empty in both scenes: `NewScene` unloaded the saved catalogue asset | reload the catalogue by path after creating the scene |
| 4 | test design trace | an extra pinch update was sent in the frame the pinch started (sample-order dependent) | recogniser skips the update in the start frame |
| 5 | PlayMode test | without an XR subsystem `ARSession` never checks availability → status stuck at “Checking AR support…” | status provider calls `ARSession.CheckAvailability()`; now resolves to *Unsupported* + Demo hint |
| 6 | code review | triangle winding of boxes and icon triangle SDF sign were inverted | corrected; covered by `MeshBuilderTests` |
| 7 | test environment | 2 PlayMode tests tapped “floor” points that the catalogue panel covers on the 640×480 batch screen (UI correctly blocked them) | tests now pick points in the open screen area; UI-priority behaviour itself was correct |
| 8 | repository hygiene | Android CMake intermediates (`.utmp/`) were committed | ignored and untracked |
