# Demo Script (3–5 minutes)

**Setup before the session:** phone charged, APK installed, ARCore services updated, a well-lit room with a
textured floor or rug. Laptop with Unity open on `DemoScene` as a backup (and for projecting).

| Time | Action | What to say |
|---|---|---|
| 0:00–0:30 | Launch *AR Interior Design*. Point at the floor and move slowly. | “The app runs AR Foundation 6.6 with ARCore on Unity 6. The status pill and banner guide the user while ARCore scans.” |
| 0:30–0:50 | Grid appears, status turns green *Tracking · N surfaces*. | “Detected horizontal planes are visualised with a grid; placement only works on them.” |
| 0:50–1:30 | Tap **Sofa** card → tap floor. Tap **Floor Lamp** → tap next to the sofa. | “Each item is a multi-part model in real metres, placed facing me and attached to one AR anchor. Taps are de-duplicated, so one tap = one item.” |
| 1:30–1:50 | Tap the sofa, then empty floor. | “Selection shows the yellow-orange #FFB000 outline – a URP shader that runs on the phone, not an Editor gizmo. Tapping empty space deselects.” |
| 1:50–2:30 | **Move**: drag the sofa along the floor; choose **Y** and lift the lamp; drag the red X arrow. | “Floor moves follow the detected surface; X/Y/Z are axis-constrained moves, also via the arrows. The item is re-anchored once when the drag ends.” |
| 2:30–3:00 | **Rotate**: drag sideways; enable **Snap 15°**, drag again. Twist with two fingers. | “Smooth rotation around the selected axis, or exact 15° steps.” |
| 3:00–3:20 | **Scale**: drag up/down until it stops; pinch; **Reset size**. | “Uniform scale with per-model limits, so it never becomes negative or absurd.” |
| 3:20–3:40 | Try to drag while touching a toolbar button. | “UI touches have priority – a touch that starts on the UI never reaches the scene.” |
| 3:40–4:00 | Select the lamp → **Delete**. | “Delete removes the object, its anchor and the selection; the button disables itself.” |
| 4:00–4:30 | Cover the camera briefly. | “On tracking loss the app blocks editing, cancels the gesture and explains what to do; furniture stays anchored.” |
| 4:30–5:00 | Tap **Demo** (or show the laptop). | “The same code runs in a virtual room for the Editor and phones without ARCore. 68 EditMode and 21 PlayMode tests cover the logic, assets and scenes.” |

**Fallback if AR misbehaves:** switch to the laptop running `DemoScene` and perform steps 0:50–4:00 with the
mouse (left = finger, right-drag = orbit). Mention that device testing is listed as a known limitation.
