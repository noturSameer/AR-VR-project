# Final Delivery Report

Statuses: **PASSED** (executed and passed), **DONE** (implemented; evidence listed), **PARTIAL**, **NOT RUN**.
Device-level behaviour is never marked PASSED: no ARCore phone was available.

## Environment audit (Milestone A)

| Item | Finding |
|---|---|
| Repository | Contained only `CLAUDE.md`; no separate project plan file — CLAUDE.md used as the requirements source |
| Unity | 6000.6.5f1 installed (Supported stream, **not LTS**) — only editor available; LTS deviation recorded |
| Android Build Support | Installed: SDK (build-tools 36.0.0, platforms 34/36/37), NDK r27c, OpenJDK 17.0.18, Gradle 9.3.1 |
| Licence | Unity Personal, batch mode works |
| Device | `adb devices` → none connected |
| Constraint | Project path contains `:` → Unity cannot open it directly; worked through a colon-free symlink |
| Compatibility | AR Foundation 6.2.1 fails to compile with URP 17.6 (seen in another local project) → chose 6.6.2 |

## Requirement checklist

| # | Requirement | Status | Evidence |
|---|---|---|---|
| 1 | Unity LTS compatible with AR Foundation/ARCore | PARTIAL | 6000.6.5f1 (not LTS, only installed editor) + matching AR Foundation/ARCore 6.6.2; compiles and builds |
| 2 | C#, uGUI, Canvas, TextMeshPro, EventSystem | DONE | HUD built with uGUI + TMP; EventSystem + InputSystemUIInputModule |
| 3 | Android/ARCore target, separate AR and Editor demo modes | DONE | MainARScene (AR) and DemoScene (virtual room); both in build settings |
| 4 | Exact versions documented | DONE | README “Versions”, lock file |
| 5 | Package compatibility verified, no guessed APIs | PASSED | APIs checked in package sources; 0 compile errors/warnings |
| 6 | No unnecessary dependencies/permissions | DONE | minimal manifest (Unity’s default extras removed); CAMERA from ARCore; INTERNET auto-added by Unity (documented) |
| 7 | AR session + camera background | DONE / NOT RUN on device | ARSession, ARCameraManager/Background, URP `ARBackgroundRendererFeature` (validated) |
| 8 | Plane detection + visual feedback | DONE / NOT RUN on device | ARPlaneManager (horizontal) + grid/boundary prefab |
| 9 | Raycast placement on surfaces | PASSED (demo) / NOT RUN (AR) | `PlacementController` + `ARPlaneSurfaceProvider`; PlayMode placement tests |
| 10 | Scanning/tracking guidance | PASSED (logic) | `ARSessionStatusProvider.Describe` tests; screenshot 06 |
| 11 | Graceful tracking loss | PASSED (logic) / NOT RUN (device) | gestures cancelled + restored, interaction blocked; status tests |
| 12 | Anchors only where useful, not excessive | DONE / NOT RUN on device | one anchor per item, replaced only after a move; versioned async requests |
| 13 | ≥ 5 distinct furniture models | PASSED | Modern Chair, Dining Table, Sofa, Floor Lamp, Bookshelf |
| 14 | Meaningful geometry, real dimensions, pivot, collider, materials, prefab | PASSED | 4–8 components each; size within 4 cm; floor pivot; BoxCollider = bounds; validator + tests |
| 15 | Separate model and texture files; procedural method documented | DONE | one mesh file per model in `Art/Models`, 6 PNG textures; PROJECT_OVERVIEW/ARCHITECTURE |
| 16 | Select by touch, deselect | PASSED | `Selection_…` PlayMode test |
| 17 | Yellow-orange outline working at runtime in URP/Android | PASSED (Editor runtime) / NOT RUN (device GPU) | URP HLSL stencil + hull, #FFB000; tests + screenshots 02/03 |
| 18 | Surface drag + real X/Y/Z axis handles | PASSED | surface, axis-chip and gizmo-handle move tests |
| 19 | Rotate around selected axis, smooth + 15° snap | PASSED | rotate tests (continuous, snapped, local X) |
| 20 | Uniform, positive, bounded scale | PASSED | scale tests (clamp, NaN, uniform, reset) |
| 21 | Safe delete clearing selection | PASSED | delete test |
| 22 | No simultaneous transform writers | PASSED | `TransformController` lock tests (EditMode + PlayMode) |
| 23 | Single touch selects, drag performs mode action | PASSED | recogniser + interaction tests |
| 24 | Two-finger scale/rotate (optional) | PASSED (simulated) | pinch + twist tests |
| 25 | UI touches have priority | PASSED | recogniser test + `UiTouch_HasPriorityOverTheScene` through real router |
| 26 | No duplicate placement | PASSED | `Placement_RepeatedTapsDoNotDuplicate`, `DuplicateBeganEvent` |
| 27 | Clean mode change / gesture cancellation | PASSED | mode-change and cancel tests |
| 28 | Polished mobile UI titled “AR Interior Design” with catalogue, tools, statuses, guidance | DONE | screenshots 01–06 |
| 29 | Every control has real functionality | PASSED | validator (buttons wired) + `Scene_StartsReady…` + `HudButtons_DriveTheTools` |
| 30 | Modular code, explicit references validated, safe cleanup, no TODO/fake code | DONE | separate assemblies/classes; `Awake` reference checks; event unsubscription; no TODO/empty catch |
| 31 | Git checkpoints | DONE | git history (audit, pre-compile, fixes, tests, docs) |
| 32 | Idempotent setup wizard | PASSED | second run: no duplicates, validation passed |
| 33 | Static checks / tests / compile run and re-run after fixes | PASSED | EditMode 68/68, PlayMode 21/21 (+2 opt-in) |
| 34 | Android build settings + APK only if real | PASSED | `Builds/Android/ARInteriorDesign.apk` 35 441 428 bytes, verified with aapt2/apksigner |
| 35 | Physical device test | NOT RUN | no device |
| 36 | Documentation set | DONE | README, Documentation/*, CHANGELOG |
| 37 | ZIP only after checking contents | DONE | `Delivery/ARInteriorDesign_Source.zip` from `git archive` of the delivery commit; contents listed and checked (no Library/Builds/intermediates); a clean extraction compiles and passes the validator |

## CLAUDE.md final checklist

- [x] At least five distinct furniture models exist.
- [x] Every model has a usable prefab and catalogue entry.
- [x] AR plane detection and placement are implemented (device run: NOT RUN).
- [x] Selection outline is yellow-orange and works at runtime (Editor runtime verified; device GPU NOT RUN).
- [x] Select, Move, Rotate, Scale and Delete perform real actions.
- [x] UI touches do not accidentally interact with the scene.
- [x] Both AR and demo scenes are present.
- [x] Package versions and build settings are documented.
- [x] All available tests and builds have honest results.
- [x] Setup and professor-demo documentation is present.
- [x] ZIP/APK outputs reported only because they were created and verified.

## Next steps

1. Install the APK on an ARCore phone (`adb install -r Builds/Android/ARInteriorDesign.apk`) and run the
   [demo script](DEMO_SCRIPT.md); record results as new rows in the test report.
2. Rename the project folder to remove the colon (or keep using a symlink) before opening it in Unity Hub.
3. Optionally migrate to Unity 6000.3 LTS with AR Foundation/ARCore 6.3.x, then re-run the wizard and tests.
4. For distribution, configure a release keystore.
