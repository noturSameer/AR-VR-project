# Architecture

## Overview

```
                ┌───────────────────────────── UI (uGUI) ─────────────────────────────┐
 touch / mouse  │ ARInteriorHUD ── HudButton ×N, CatalogItemView ×5, SafeAreaFitter    │
 ──────────────►│   (buttons call InteractionController / PlacementController)         │
       │        └──────────────────────────────────────────────────────────────────────┘
       │ EventSystem + InputSystemUIInputModule handles UI pointers
       ▼
 TouchInputRouter ── DevicePointerSource (EnhancedTouch, mouse fallback)
       │  UI raycast at touch-down → UI pointers are ignored for their whole lifetime
       ▼
 GestureRecognizer (tap / drag / two-finger, one gesture at a time)
       ▼
 InteractionController (ISceneGestureHandler) ── mode, axis, snap, messages
   ├─ PlacementController ── FurnitureCatalog → Instantiate prefab → SurfaceProvider.AttachToSurface
   ├─ SelectionManager ───── SelectionOutline (materials appended to renderers)
   ├─ TransformController ── the ONLY writer of furniture transforms (owner lock)
   ├─ AxisGizmo/AxisHandle ─ reports which axis was grabbed (never moves objects)
   ├─ SurfaceProvider ────── ARPlaneSurfaceProvider (AR)  |  PhysicsSurfaceProvider (Demo)
   └─ ExperienceStatusProvider ARSessionStatusProvider (AR) |  DemoStatusProvider (Demo)
```

Both scenes contain the same `AR Interior App` object; only the surface provider and status provider differ.
This keeps the Editor demo mode on exactly the same interaction code as the AR mode.

## Assemblies

| Assembly | Contents | References |
|---|---|---|
| `ARInterior.Runtime` | all runtime code | Input System, AR Foundation, AR Subsystems, XR Core Utils, TextMeshPro, uGUI |
| `ARInterior.Editor` | generators, setup wizard, validator, APK builder (Editor only) | Runtime, ARCore (+Editor), XR Management (+Editor), URP, … |
| `ARInterior.Tests.EditMode` | unit + asset/scene validation tests | Runtime, Editor, NUnit |
| `ARInterior.Tests.PlayMode` | end-to-end scene tests | Runtime, NUnit |

## Component responsibilities

### Core (`Scripts/Runtime/Core`)
* **InteractionTypes** — `InteractionMode` (Select/Move/Rotate/Scale), `TransformAxis`, `MoveConstraint`, `ManipulationKind`.
* **ManipulationMath** — pure maths: 15° snapping, scale clamping, drag→angle/scale conversion, ray–axis
  closest point, ray–floor intersection, camera-facing yaw. Unit tested.
* **ExperienceStatus / ExperienceStatusProvider** — immutable status snapshot (state, headline, guidance,
  surface count) and the base class that publishes changes. `AllowsInteraction` is true only for Ready/Demo.
* **GuidanceComposer** — decides the banner text: tracking problems > transient message > placement hint >
  workflow hint per mode.

### AR (`Scripts/Runtime/AR`)
* **ARSessionStatusProvider** — subscribes to `ARSession.stateChanged` and plane changes, polls the
  not-tracking reason every 0.25 s, and explicitly starts `ARSession.CheckAvailability()` so that a missing
  XR subsystem resolves to *Unsupported* instead of staying in *None*. `Describe()` is a pure mapping.
* **ARPlaneSurfaceProvider** — `ARRaycastManager.Raycast(…, PlaneWithinPolygon)` filtered to
  `HorizontalUp` planes; anchors: `ARAnchorManager.AttachAnchor(plane, pose)` after placement or a surface
  move, `TryAddAnchorAsync(pose)` after an axis move. Exactly one anchor per item; the previous anchor is
  removed (`TryRemoveAnchor`) before a new one is created, and in-flight async requests are versioned so a
  late result for a moved/deleted item is discarded.

### Demo (`Scripts/Runtime/Demo`)
* **PhysicsSurfaceProvider** — `Physics.Raycast` against the *DemoSurface* layer (floor and rug), accepts only
  upward-facing hits.
* **DemoStatusProvider** — constant *Demo* status.
* **DemoCameraController** — right-mouse orbit and scroll zoom (left button is reserved for the tools).

### Furniture (`Scripts/Runtime/Furniture`)
* **FurnitureDefinition** (ScriptableObject) — id, name, description, prefab, thumbnail, dimensions; `IsValid`.
* **FurnitureCatalog** (ScriptableObject) — ordered list; `Validate()` reports empty entries, duplicates, missing prefabs.
* **PlacedFurniture** — prefab root: id, dimensions, selection `BoxCollider`, cached renderers, min/max scale,
  `Destroyed` event, `DestroySelf()` guard used by async code.

### Interaction (`Scripts/Runtime/Interaction`)
* **PointerInput** — `PointerSample`, `IPointerSource`, `DevicePointerSource` (EnhancedTouch; the mouse acts
  as one pointer when no finger is down).
* **TouchInputRouter** — per frame: collect samples, feed the recogniser; `IsOverUI` performs an
  `EventSystem.RaycastAll`. Tests can inject a scripted `IPointerSource`.
* **GestureRecognizer** — state machine Idle → Pending → Dragging / TwoFinger → WaitingForRelease.
  Tap = released within 0.45 s and ≤ ~0.06 inch travel. A second finger ends a drag and starts a pinch;
  after any multi-finger gesture all fingers must lift. Missing pointers are treated as cancelled.
* **InteractionController** — interprets gestures by mode: tap = place (if armed) or select/deselect; drag =
  move/rotate/scale through the TransformController; two fingers = pinch scale + twist yaw. Cancels or commits
  gestures on mode/axis change, deletion, selection change and tracking loss.
* **TransformController** — the single owner lock (`TryBegin/End/Cancel/ForceCancel`). Rejects a second owner,
  non-owner calls and wrong-kind calls, ignores NaN/∞, restores the start pose on cancel.
* **SelectionManager** — current selection, outline on/off, auto-deselect when the item is destroyed.
* **PlacementController** — arm/disarm (toggle), placement on surface hit facing the camera, duplicate guards
  (same frame, 0.3 s cooldown, disarm after place), 25-item limit, removal with anchor release.
* **SurfaceProvider** — abstract surface/anchoring contract shared by AR and demo.

### Rendering (`Scripts/Runtime/Rendering`, `Shaders/`)
* **SelectionOutline** — appends two runtime material instances to each renderer of the selected item and
  restores the original arrays on deselect (no per-frame work).
* **AxisGizmo / AxisHandle** — three arrow handles (trigger capsules on the *Gizmo* layer) that follow the
  selection in Move mode at a constant on-screen size; `TryPickHandle` returns the grabbed axis.

### UI (`Scripts/Runtime/UI`)
* **ARInteriorHUD** — binds every button at runtime and records it in `BoundButtons`; refreshes status pill,
  selection label, tool highlighting, tool options, catalogue armed state and guidance from events.
* **HudButton / CatalogItemView** — visual state of buttons and catalogue cards. **SafeAreaFitter** — notch-safe layout.

### Editor tooling (`Scripts/Editor`)
* **Modeling/** `MeshBuilder`, `FurnitureFactory` (the 5 models), `ProceduralTextures`, `IconPainter`, `ThumbnailRasterizer`.
* **Setup/** `ProjectSetupWizard` (orchestration, batch entry points), `MaterialLibrary`, `FurnitureAssetBuilder`,
  `RenderPipelineSetup`, `PlatformSetup`, `UIBuilder`, `SceneBuilder`, `ProjectValidator`, `AndroidBuilder`,
  `AssetUtility`, `SerializedFields`, `SetupPaths`.

## Data flow examples

**Placement:** catalogue card → `PlacementController.Arm(def)` → banner “Tap a highlighted surface…” → tap →
`GestureRecognizer` (tap) → `InteractionController.OnTap` → `PlacementController.TryPlace` → `SurfaceProvider.TryRaycast`
→ `Instantiate(prefab, hit, yaw facing camera)` → `AttachToSurface` (AR anchor) → `SelectionManager.Select` → outline.

**Move drag:** touch-down (not on UI) → drag threshold → `OnDragBegin` (gizmo handle? → axis; else touched
furniture becomes selection) → `TransformController.TryBegin(owner = InteractionController)` → per-frame
`OnDragUpdate` → surface raycast + grab offset (or ray–axis closest point) → `SetPosition` → finger up →
`End` → re-anchor once.

## Touch handling rules

1. A pointer whose touch-down hits any raycast-target UI graphic is ignored by the scene until it lifts.
2. Only one scene gesture exists at a time; the transform lock additionally guarantees that no other handler
   can change the same Transform while a gesture runs.
3. Tap vs drag is decided by travel (DPI-based) and duration; duplicate `Began` events are merged.
4. Mode changes commit the current gesture; deletion, selection changes and tracking loss cancel it.
5. Application pause and component disable reset the recogniser (active drag is cancelled).

## Placement and anchors

* Planes: horizontal only (`PlaneDetectionMode.Horizontal`, hits filtered to `HorizontalUp`).
* Items face the camera on placement (yaw only) and sit with their floor pivot on the hit point.
* One anchor per item. Anchors are replaced only when a move ends — never per frame.
* While tracking is lost, nothing can be placed or manipulated; anchored items keep their pose.

## Selection outline (URP, runtime)

Two passes appended as extra materials (each furniture renderer has exactly one sub-mesh, enforced by the validator):

1. `ARInterior/SelectionStencilMask` — queue Geometry+50, `ColorMask 0`, `ZTest Always`, writes stencil bit 7
   over the object’s whole silhouette.
2. `ARInterior/SelectionOutline` — queue Transparent+50, inverted hull (`Cull Front`) extruded in clip space by
   a constant pixel width (5 px), using smoothed normals baked into UV3 (falls back to vertex normals), drawn
   only where the stencil bit is **not** set and with `ZTest LEqual`, colour **#FFB000**.

Result: a clean outer silhouette line of constant width, without interior part lines, occluded correctly
by other objects. It is pure URP HLSL (no Editor-only API) and is included in the Android build because the
materials are referenced by the scenes. Verified in rendered screenshots (Editor, Metal) and by tests.

## Transform tools

| Tool | Gesture | Implementation |
|---|---|---|
| Move · Floor | 1-finger drag | Surface raycast under the finger + grab offset; falls back to a horizontal plane at the item’s base so drags never stall at plane edges |
| Move · X/Y/Z | 1-finger drag with chip selected, or drag a gizmo arrow | Closest point between the touch ray and the item’s local axis; screen-projection fallback when the axis is parallel to the view; travel clamped to ±3 m |
| Rotate | 1-finger drag (horizontal for Y/Z, vertical for X) | 360° per screen width around the selected local axis; optional 15° snapping of the accumulated angle |
| Scale | vertical drag / pinch | uniform, ×2 per half screen height; clamped to `[MinScale, MaxScale]` of the item; Reset size → 100 % |
| Rotate (2 fingers) | twist | yaw around local Y |

## Setup wizard (idempotency)

`ProjectSetupWizard.RunFullSetup` writes PNGs only when bytes change, updates materials/meshes/ScriptableObjects
in place (sub-mesh assets are matched by name so prefab references survive), overwrites prefabs at the same
path (GUIDs stay stable) and rebuilds both scenes from an empty scene. The URP renderer feature is added only
if missing (validator requires exactly one). Re-running the wizard produced no duplicates (verified).
