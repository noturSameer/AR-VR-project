# AR Interior Design

Android augmented-reality furniture placement app (Unity + AR Foundation/ARCore), built for a university
project demonstration. Scan a room, detect floor surfaces, place five furniture models, then select, move,
rotate, scale and delete them. The selected object gets a yellow-orange (#FFB000) outline that is rendered
by URP shaders at runtime, not an Editor gizmo.

![Move mode with outline and X/Y/Z handles](Documentation/Screenshots/02_demo_move_mode_outline_gizmo.png)

## Versions (exact, as resolved in `Packages/packages-lock.json`)

| Component | Version |
|---|---|
| Unity Editor | **6000.6.5f1** (Unity 6.6, *Supported* stream — see [Known limitations](Documentation/KNOWN_LIMITATIONS.md)) |
| AR Foundation | 6.6.2 |
| Google ARCore XR Plugin | 6.6.2 |
| XR Plug-in Management | 4.7.0 |
| XR Core Utils (dependency) | 2.6.0 |
| Universal Render Pipeline | 17.6.0 |
| Input System | 1.20.1 |
| uGUI + TextMeshPro | 2.6.0 |
| Unity Test Framework | 1.8.0 |
| Visual Studio Editor (Editor-only IDE integration) | 2.0.26 |

Android tooling used for the build (installed with the Unity Android module): SDK build-tools 36.0.0,
platform 36, NDK r27c, OpenJDK 17.0.18, Gradle 9.3.1.

Why AR Foundation 6.6.2: AR Foundation 6.2.x does not compile against URP 17.6 (Unity 6.6 removed the
URP compatibility-mode render pass APIs it overrides). 6.6.x is the line released for Unity 6.6, and the
project compiles with zero errors and zero warnings in project code.

## Important: project folder name

Unity refuses to open a project whose path contains a colon (`Couldn't set project path`). The delivered
folder is named `AR:VR_Project`, so before opening it in Unity Hub either:

* rename the folder, e.g. to `AR_VR_Project`, **or**
* create a colon-free symbolic link and open that path:
  ```bash
  ln -s "$HOME/Downloads/AR:VR_Project" "$HOME/Downloads/ARInteriorProject"
  ```

All batch-mode commands below were run through such a link.

## Opening the project

1. Install Unity **6000.6.5f1** with **Android Build Support** (OpenJDK, Android SDK & NDK tools).
2. Open the (colon-free) project folder in Unity Hub. Packages resolve automatically.
3. Generated content is already committed. To regenerate everything from scratch use the menu
   **AR Interior → 1. Import TextMeshPro Essentials**, then **AR Interior → 2. Run Full Setup**.
   The setup wizard is idempotent: it updates assets in place and rebuilds both scenes without duplicates.
4. **AR Interior → 3. Validate Project** checks catalogue, prefabs, dimensions, outline shaders, URP, XR,
   Android settings, scenes and button wiring.

## Running in the Editor (DemoScene)

Open `Assets/ARInterior/Scenes/DemoScene.unity` and press Play. A virtual room replaces AR plane detection.

* Left mouse button = finger (tap / drag), right mouse drag = orbit camera, scroll wheel = zoom.
* Everything else (catalogue, tools, outline, gizmo, delete) is the same code as the AR scene.

`MainARScene` can also be played in the Editor; without an AR device it reports **AR not supported** and
highlights the **Demo** button, which loads DemoScene.

## Running on Android (MainARScene)

Requirements: ARCore-supported phone, Android 8.0 (API 26) or newer, ARM64.

**Build in the Editor:** *AR Interior → 4. Build Android APK* (validates first, writes `Builds/Android/ARInteriorDesign.apk`),
or *File → Build Profiles → Android → Build* (scenes 0 = MainARScene, 1 = DemoScene are pre-configured).

**Build from the command line:**

```bash
/Applications/Unity/Hub/Editor/6000.6.5f1/Unity.app/Contents/MacOS/Unity -batchmode -projectPath "$HOME/Downloads/ARInteriorProject" -buildTarget Android -executeMethod ARInterior.EditorTools.Setup.AndroidBuilder.BuildApkBatch -logFile build.log
```

**Install:**

```bash
adb install -r Builds/Android/ARInteriorDesign.apk
```

Player settings applied by the wizard: package `com.university.arinteriordesign`, min SDK 26 (ARCore
requirement for Unity 6000.5+ with OpenGLES3), target SDK = highest installed (36), IL2CPP, ARM64 only,
OpenGLES3 only, linear colour space, portrait, Input System only, ARCore **Optional** (non-AR phones can
still install the app and use the demo scene).

## Tests

```bash
# EditMode (logic, assets, scenes, shaders)
Unity -batchmode -projectPath <project> -buildTarget Android -runTests -testPlatform EditMode -assemblyNames ARInterior.Tests.EditMode -testResults editmode.xml
# PlayMode (end-to-end in DemoScene and MainARScene)
Unity -batchmode -projectPath <project> -buildTarget Android -runTests -testPlatform PlayMode -assemblyNames ARInterior.Tests.PlayMode -testResults playmode.xml
# Optional: regenerate documentation screenshots
Unity -batchmode -projectPath <project> -buildTarget Android -runTests -testPlatform PlayMode -testFilter DocumentationScreenshots -captureScreenshots -testResults shots.xml
```

Results are recorded in [Documentation/TEST_REPORT.md](Documentation/TEST_REPORT.md).

## Repository layout

```
Assets/ARInterior/
  Scripts/Runtime/      AR, Core, Demo, Furniture, Interaction, Rendering, UI  (ARInterior.Runtime.asmdef)
  Scripts/Editor/       Modeling (mesh/texture/thumbnail generators), Setup (wizard, validator, builder)
  Shaders/              SelectionOutline, SelectionStencilMask, UnlitColor, PlaneGrid (URP HLSL)
  Art/                  Generated textures (PNG), materials, model mesh files, UI sprites, thumbnails
  Prefabs/              Furniture prefabs, AR plane visualiser
  Data/                 FurnitureCatalog + one FurnitureDefinition per model
  Scenes/               MainARScene, DemoScene
  Settings/             URP asset + renderer (with ARBackgroundRendererFeature)
  Tests/                EditMode and PlayMode test assemblies
Documentation/          Overview, architecture, user guide, demo script, test report, limitations, delivery report
```

## Documentation

* [Project overview](Documentation/PROJECT_OVERVIEW.md)
* [Architecture](Documentation/ARCHITECTURE.md)
* [User guide](Documentation/USER_GUIDE.md)
* [Demo script (3–5 min)](Documentation/DEMO_SCRIPT.md)
* [Test report](Documentation/TEST_REPORT.md)
* [Known limitations](Documentation/KNOWN_LIMITATIONS.md)
* [Final delivery report](Documentation/FINAL_DELIVERY_REPORT.md)
* [Changelog](CHANGELOG.md)
