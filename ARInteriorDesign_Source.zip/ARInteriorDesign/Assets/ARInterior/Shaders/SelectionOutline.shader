// Yellow-orange selection outline for URP (works on Android GLES3/Vulkan, not an Editor gizmo).
// Inverted hull extruded in clip space so the line keeps a constant pixel width at any distance.
// Smoothed normals are read from UV channel 3 (baked by the model generator) to avoid gaps at hard
// edges; the vertex normal is used when that channel is empty. The stencil test skips pixels already
// covered by the selected object (written by SelectionStencilMask), leaving only the outer silhouette.
Shader "ARInterior/SelectionOutline"
{
    Properties
    {
        _OutlineColor ("Outline Color", Color) = (1, 0.6902, 0, 1)
        _OutlineWidth ("Outline Width (pixels)", Range(0, 16)) = 5
    }

    SubShader
    {
        Tags
        {
            "RenderPipeline" = "UniversalPipeline"
            "RenderType" = "Transparent"
            "Queue" = "Transparent+50"
            "IgnoreProjector" = "True"
        }

        Pass
        {
            Name "SelectionOutline"
            Tags { "LightMode" = "SRPDefaultUnlit" }

            Cull Front
            ZWrite Off
            ZTest LEqual
            Blend SrcAlpha OneMinusSrcAlpha

            Stencil
            {
                Ref 128
                ReadMask 128
                Comp NotEqual
                Pass Keep
            }

            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _OutlineColor;
                float _OutlineWidth;
            CBUFFER_END

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                float3 smoothNormalOS : TEXCOORD3;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            Varyings Vert(Attributes input)
            {
                Varyings output;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);

                float3 normalOS = dot(input.smoothNormalOS, input.smoothNormalOS) > 1e-4
                    ? input.smoothNormalOS
                    : input.normalOS;

                float4 positionCS = TransformObjectToHClip(input.positionOS.xyz);
                float3 normalWS = TransformObjectToWorldNormal(normalOS);
                float2 normalCS = TransformWorldToHClipDir(normalWS).xy;
                float len = length(normalCS);
                if (len > 1e-5)
                {
                    float2 pixelToClip = 2.0 / max(_ScreenParams.xy, float2(1.0, 1.0));
                    positionCS.xy += (normalCS / len) * _OutlineWidth * pixelToClip * positionCS.w;
                }

                output.positionCS = positionCS;
                return output;
            }

            half4 Frag(Varyings input) : SV_Target
            {
                return _OutlineColor;
            }
            ENDHLSL
        }
    }

    Fallback Off
}
