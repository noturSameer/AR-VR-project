// Semi-transparent visualisation of detected AR planes: a soft fill plus a world-space grid with
// 25 cm cells, so the user can see which surfaces are ready for placement.
Shader "ARInterior/PlaneGrid"
{
    Properties
    {
        _FillColor ("Fill Color", Color) = (1, 0.6902, 0, 0.10)
        _LineColor ("Line Color", Color) = (1, 1, 1, 0.55)
        _CellSize ("Cell Size (m)", Float) = 0.25
        _LineWidth ("Line Width (pixels)", Range(0.5, 4)) = 1.2
    }

    SubShader
    {
        Tags
        {
            "RenderPipeline" = "UniversalPipeline"
            "RenderType" = "Transparent"
            "Queue" = "Transparent-10"
            "IgnoreProjector" = "True"
        }

        Pass
        {
            Name "PlaneGrid"
            Tags { "LightMode" = "SRPDefaultUnlit" }

            Cull Off
            ZWrite Off
            ZTest LEqual
            Blend SrcAlpha OneMinusSrcAlpha

            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _FillColor;
                half4 _LineColor;
                float _CellSize;
                float _LineWidth;
            CBUFFER_END

            struct Attributes
            {
                float4 positionOS : POSITION;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float3 positionWS : TEXCOORD0;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            Varyings Vert(Attributes input)
            {
                Varyings output;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);
                output.positionWS = TransformObjectToWorld(input.positionOS.xyz);
                output.positionCS = TransformWorldToHClip(output.positionWS);
                return output;
            }

            half4 Frag(Varyings input) : SV_Target
            {
                float2 cell = input.positionWS.xz / max(_CellSize, 0.01);
                float2 width = max(fwidth(cell), 1e-4) * _LineWidth;
                float2 distanceToLine = abs(frac(cell - 0.5) - 0.5) / width;
                float lineMask = 1.0 - saturate(min(distanceToLine.x, distanceToLine.y));
                half4 color = lerp(_FillColor, _LineColor, lineMask);
                return color;
            }
            ENDHLSL
        }
    }

    Fallback Off
}
