// Flat vertex-colour × tint shader for the move gizmo (drawn on top with ZTest Always) and the
// AR plane boundary lines (normal depth test). _ZTest uses UnityEngine.Rendering.CompareFunction values.
Shader "ARInterior/UnlitColor"
{
    Properties
    {
        _Color ("Color", Color) = (1, 1, 1, 1)
        [Enum(UnityEngine.Rendering.CompareFunction)] _ZTest ("Depth Test", Float) = 4
        [Enum(Off, 0, On, 1)] _ZWrite ("Depth Write", Float) = 0
    }

    SubShader
    {
        Tags
        {
            "RenderPipeline" = "UniversalPipeline"
            "RenderType" = "Transparent"
            "Queue" = "Transparent+100"
            "IgnoreProjector" = "True"
        }

        Pass
        {
            Name "UnlitColor"
            Tags { "LightMode" = "SRPDefaultUnlit" }

            Cull Back
            ZWrite [_ZWrite]
            ZTest [_ZTest]
            Blend SrcAlpha OneMinusSrcAlpha

            HLSLPROGRAM
            #pragma vertex Vert
            #pragma fragment Frag
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _Color;
            CBUFFER_END

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS : NORMAL;
                half4 color : COLOR;
                UNITY_VERTEX_INPUT_INSTANCE_ID
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                half4 color : COLOR;
                half shade : TEXCOORD0;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            Varyings Vert(Attributes input)
            {
                Varyings output;
                UNITY_SETUP_INSTANCE_ID(input);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(output);
                output.positionCS = TransformObjectToHClip(input.positionOS.xyz);
                output.color = input.color * _Color;
                // Cheap fixed-direction shading so 3D handles read as solid shapes.
                float3 normalWS = TransformObjectToWorldNormal(input.normalOS);
                output.shade = (half)(0.75 + 0.25 * saturate(dot(normalWS, normalize(float3(0.3, 0.8, 0.5)))));
                return output;
            }

            half4 Frag(Varyings input) : SV_Target
            {
                return half4(input.color.rgb * input.shade, input.color.a);
            }
            ENDHLSL
        }
    }

    Fallback Off
}
