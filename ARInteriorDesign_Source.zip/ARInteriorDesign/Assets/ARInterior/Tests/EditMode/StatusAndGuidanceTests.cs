using ARInterior.AR;
using ARInterior.Core;
using NUnit.Framework;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

namespace ARInterior.Tests
{
    public class StatusAndGuidanceTests
    {
        [Test]
        public void Describe_Unsupported_BlocksInteractionAndPointsToDemo()
        {
            var status = ARSessionStatusProvider.Describe(ARSessionState.Unsupported, NotTrackingReason.None, 0, false);
            Assert.AreEqual(ExperienceState.Unsupported, status.State);
            Assert.IsFalse(status.AllowsInteraction);
            StringAssert.Contains("Demo", status.Guidance);
        }

        [Test]
        public void Describe_TrackingWithoutPlanes_AsksUserToScan()
        {
            var status = ARSessionStatusProvider.Describe(ARSessionState.SessionTracking, NotTrackingReason.None, 0, true);
            Assert.AreEqual(ExperienceState.Scanning, status.State);
            Assert.IsFalse(status.AllowsInteraction);
            StringAssert.Contains("floor", status.Guidance);
        }

        [Test]
        public void Describe_TrackingWithPlanes_IsReady()
        {
            var status = ARSessionStatusProvider.Describe(ARSessionState.SessionTracking, NotTrackingReason.None, 2, true);
            Assert.AreEqual(ExperienceState.Ready, status.State);
            Assert.IsTrue(status.AllowsInteraction);
            Assert.AreEqual("Tracking · 2 surfaces", status.Headline);
        }

        [Test]
        public void Describe_LostTracking_ExplainsReason()
        {
            var status = ARSessionStatusProvider.Describe(ARSessionState.SessionInitializing, NotTrackingReason.InsufficientLight, 3, true);
            Assert.AreEqual(ExperienceState.TrackingLimited, status.State);
            Assert.IsFalse(status.AllowsInteraction);
            StringAssert.Contains("dark", status.Guidance);
        }

        [Test]
        public void Describe_InstallingServices()
        {
            var status = ARSessionStatusProvider.Describe(ARSessionState.Installing, NotTrackingReason.None, 0, false);
            Assert.AreEqual(ExperienceState.Installing, status.State);
        }

        [Test]
        public void Guidance_TrackingProblemsTakePriority()
        {
            var status = new ExperienceStatus(ExperienceState.TrackingLimited, "Tracking lost", "Move slowly", 1);
            var text = GuidanceComposer.Compose(status, "Sofa", true, 3, InteractionMode.Move, "message");
            Assert.AreEqual("Move slowly", text);
        }

        [Test]
        public void Guidance_ArmedItemExplainsPlacement()
        {
            var status = new ExperienceStatus(ExperienceState.Ready, "Tracking", string.Empty, 1);
            StringAssert.Contains("place the Sofa", GuidanceComposer.Compose(status, "Sofa", false, 0, InteractionMode.Select, null));
            var demo = new ExperienceStatus(ExperienceState.Demo, "Demo", string.Empty, 1);
            StringAssert.Contains("floor", GuidanceComposer.Compose(demo, "Sofa", false, 0, InteractionMode.Select, null));
        }

        [Test]
        public void Guidance_GuidesThroughTheWorkflow()
        {
            var status = new ExperienceStatus(ExperienceState.Ready, "Tracking", string.Empty, 1);
            StringAssert.Contains("catalogue", GuidanceComposer.Compose(status, null, false, 0, InteractionMode.Select, null));
            StringAssert.Contains("select", GuidanceComposer.Compose(status, null, false, 2, InteractionMode.Select, null));
            StringAssert.Contains("rotate", GuidanceComposer.Compose(status, null, true, 2, InteractionMode.Rotate, null));
            Assert.AreEqual("Deleted", GuidanceComposer.Compose(status, null, true, 2, InteractionMode.Rotate, "Deleted"));
        }
    }
}
