using System.Collections.Generic;
using ARInterior.Interaction;
using NUnit.Framework;
using UnityEngine;

namespace ARInterior.Tests
{
    public class GestureRecognizerTests
    {
        sealed class RecordingHandler : ISceneGestureHandler
        {
            public readonly List<string> Events = new List<string>();
            public bool AcceptDrag = true;
            public bool AcceptTwoFinger = true;
            public bool KeepDragAlive = true;

            public void OnTap(Vector2 screenPosition) => Events.Add("tap");

            public bool OnDragBegin(Vector2 startPosition, Vector2 currentPosition)
            {
                Events.Add("dragBegin");
                return AcceptDrag;
            }

            public bool OnDragUpdate(Vector2 screenPosition)
            {
                Events.Add("dragUpdate");
                return KeepDragAlive;
            }

            public void OnDragEnd() => Events.Add("dragEnd");
            public void OnDragCancel() => Events.Add("dragCancel");

            public bool OnTwoFingerBegin(Vector2 first, Vector2 second)
            {
                Events.Add("twoBegin");
                return AcceptTwoFinger;
            }

            public bool OnTwoFingerUpdate(Vector2 first, Vector2 second)
            {
                Events.Add("twoUpdate");
                return true;
            }

            public void OnTwoFingerEnd() => Events.Add("twoEnd");
        }

        RecordingHandler m_Handler;
        GestureRecognizer m_Recognizer;
        bool m_OverUI;
        float m_Time;

        [SetUp]
        public void SetUp()
        {
            m_Handler = new RecordingHandler();
            m_OverUI = false;
            m_Time = 0f;
            m_Recognizer = new GestureRecognizer(m_Handler, _ => m_OverUI) { DragThresholdPixels = 10f, TapMaxDuration = 0.4f };
        }

        void Frame(params PointerSample[] samples)
        {
            m_Time += 0.016f;
            m_Recognizer.Process(samples, m_Time);
        }

        static PointerSample S(int id, float x, float y, PointerPhase phase) => new PointerSample(id, new Vector2(x, y), phase);

        [Test]
        public void QuickTouch_IsReportedAsSingleTap()
        {
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 101, 100, PointerPhase.Stationary));
            Frame(S(1, 101, 100, PointerPhase.Ended));
            CollectionAssert.AreEqual(new[] { "tap" }, m_Handler.Events);
            Assert.AreEqual(GestureRecognizer.State.Idle, m_Recognizer.CurrentState);
        }

        [Test]
        public void TouchStartingOnUI_NeverReachesTheScene()
        {
            m_OverUI = true;
            Frame(S(1, 100, 100, PointerPhase.Began));
            m_OverUI = false; // even if the finger then slides off the UI
            Frame(S(1, 300, 100, PointerPhase.Moved));
            Frame(S(1, 300, 100, PointerPhase.Ended));
            CollectionAssert.IsEmpty(m_Handler.Events);
        }

        [Test]
        public void DuplicateBeganEvent_ProducesOnlyOneTap()
        {
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 100, 100, PointerPhase.Ended));
            CollectionAssert.AreEqual(new[] { "tap" }, m_Handler.Events);
        }

        [Test]
        public void LongPress_IsNotATap()
        {
            Frame(S(1, 100, 100, PointerPhase.Began));
            m_Time += 1f;
            Frame(S(1, 100, 100, PointerPhase.Ended));
            CollectionAssert.IsEmpty(m_Handler.Events);
        }

        [Test]
        public void Drag_BeginsAfterThreshold_UpdatesAndEnds()
        {
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 105, 100, PointerPhase.Moved));
            Assert.AreEqual(GestureRecognizer.State.Pending, m_Recognizer.CurrentState);
            Frame(S(1, 140, 100, PointerPhase.Moved));
            Frame(S(1, 160, 100, PointerPhase.Moved));
            Frame(S(1, 160, 100, PointerPhase.Ended));
            CollectionAssert.AreEqual(new[] { "dragBegin", "dragUpdate", "dragUpdate", "dragEnd" }, m_Handler.Events);
        }

        [Test]
        public void RejectedDrag_IsIgnoredUntilRelease()
        {
            m_Handler.AcceptDrag = false;
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 200, 100, PointerPhase.Moved));
            Frame(S(1, 260, 100, PointerPhase.Moved));
            Frame(S(1, 260, 100, PointerPhase.Ended));
            CollectionAssert.AreEqual(new[] { "dragBegin" }, m_Handler.Events);
            Assert.AreEqual(GestureRecognizer.State.Idle, m_Recognizer.CurrentState);
        }

        [Test]
        public void CancelledTouch_CancelsDrag()
        {
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 200, 100, PointerPhase.Moved));
            Frame(S(1, 200, 100, PointerPhase.Canceled));
            CollectionAssert.AreEqual(new[] { "dragBegin", "dragUpdate", "dragCancel" }, m_Handler.Events);
        }

        [Test]
        public void VanishedPointer_IsTreatedAsCancelled()
        {
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 200, 100, PointerPhase.Moved));
            Frame(); // the device stopped reporting the finger
            CollectionAssert.AreEqual(new[] { "dragBegin", "dragUpdate", "dragCancel" }, m_Handler.Events);
            Assert.AreEqual(GestureRecognizer.State.Idle, m_Recognizer.CurrentState);
        }

        [Test]
        public void SecondFinger_EndsDragAndStartsPinch_ThenWaitsForAllFingers()
        {
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 200, 100, PointerPhase.Moved));
            Frame(S(1, 200, 100, PointerPhase.Stationary), S(2, 400, 100, PointerPhase.Began));
            Frame(S(1, 190, 100, PointerPhase.Moved), S(2, 420, 100, PointerPhase.Moved));
            Frame(S(1, 190, 100, PointerPhase.Stationary), S(2, 420, 100, PointerPhase.Ended));
            // The remaining finger must not start a new drag or tap.
            Frame(S(1, 400, 100, PointerPhase.Moved));
            Frame(S(1, 400, 100, PointerPhase.Ended));
            CollectionAssert.AreEqual(
                new[] { "dragBegin", "dragUpdate", "dragEnd", "twoBegin", "twoUpdate", "twoEnd" },
                m_Handler.Events);
            Assert.AreEqual(GestureRecognizer.State.Idle, m_Recognizer.CurrentState);
        }

        [Test]
        public void DragCancelledElsewhere_StopsUpdates()
        {
            m_Handler.KeepDragAlive = false;
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 200, 100, PointerPhase.Moved));
            Frame(S(1, 260, 100, PointerPhase.Moved));
            Frame(S(1, 260, 100, PointerPhase.Ended));
            CollectionAssert.AreEqual(new[] { "dragBegin", "dragUpdate" }, m_Handler.Events);
        }

        [Test]
        public void Reset_CancelsActiveDrag()
        {
            Frame(S(1, 100, 100, PointerPhase.Began));
            Frame(S(1, 200, 100, PointerPhase.Moved));
            m_Recognizer.Reset();
            CollectionAssert.AreEqual(new[] { "dragBegin", "dragUpdate", "dragCancel" }, m_Handler.Events);
            Assert.AreEqual(GestureRecognizer.State.Idle, m_Recognizer.CurrentState);
        }
    }
}
