using System.Collections.Generic;
using ARInterior.EditorTools.Modeling;
using NUnit.Framework;
using UnityEngine;

namespace ARInterior.Tests
{
    public class MeshBuilderTests
    {
        static IEnumerable<TestCaseData> ConvexShapes()
        {
            var box = new MeshBuilder();
            box.AddBox(Vector3.zero, new Vector3(1f, 2f, 3f));
            yield return new TestCaseData(box).SetName("Box");

            var rotatedBox = new MeshBuilder();
            rotatedBox.AddBox(Vector3.zero, new Vector3(1f, 0.5f, 2f), Quaternion.Euler(20f, 35f, -10f));
            yield return new TestCaseData(rotatedBox).SetName("RotatedBox");

            var rounded = new MeshBuilder();
            rounded.AddRoundedBox(Vector3.zero, new Vector3(1f, 0.4f, 0.8f), 0.1f, 4);
            yield return new TestCaseData(rounded).SetName("RoundedBox");

            var cylinder = new MeshBuilder();
            cylinder.AddCylinder(new Vector3(0f, -0.5f, 0f), 0.3f, 1f, 16);
            yield return new TestCaseData(cylinder).SetName("Cylinder");

            var cone = new MeshBuilder();
            cone.AddFrustum(new Vector3(0f, -0.5f, 0f), 0.4f, 0.1f, 1f, 20, true, true, Quaternion.identity);
            yield return new TestCaseData(cone).SetName("Frustum");

            var sphere = new MeshBuilder();
            sphere.AddSphere(Vector3.zero, 0.5f, 16, 10);
            yield return new TestCaseData(sphere).SetName("Sphere");
        }

        [TestCaseSource(nameof(ConvexShapes))]
        public void Triangles_FaceOutwards(MeshBuilder builder)
        {
            var center = builder.CalculateBounds().center;
            var vertices = builder.Vertices;
            var triangles = builder.Triangles;
            var checkedTriangles = 0;
            for (var i = 0; i < triangles.Count; i += 3)
            {
                var a = vertices[triangles[i]];
                var b = vertices[triangles[i + 1]];
                var c = vertices[triangles[i + 2]];
                var normal = Vector3.Cross(b - a, c - a);
                if (normal.sqrMagnitude < 1e-12f)
                    continue; // degenerate sliver at a pole or seam
                var centroid = (a + b + c) / 3f;
                Assert.Greater(Vector3.Dot(normal, centroid - center), 0f, $"Triangle {i / 3} faces inwards (Unity front faces are clockwise)");
                checkedTriangles++;
            }

            Assert.Greater(checkedTriangles, 0);
        }

        [TestCaseSource(nameof(ConvexShapes))]
        public void VertexNormals_PointAwayFromCentre(MeshBuilder builder)
        {
            var center = builder.CalculateBounds().center;
            for (var i = 0; i < builder.VertexCount; i++)
            {
                var offset = builder.Vertices[i] - center;
                if (offset.sqrMagnitude < 1e-8f)
                    continue;
                Assert.GreaterOrEqual(Vector3.Dot(builder.Normals[i], offset), -1e-4f, $"Normal {i} points inwards");
            }
        }

        [Test]
        public void SmoothedNormals_MergeHardEdges()
        {
            var box = new MeshBuilder();
            box.AddBox(Vector3.zero, Vector3.one);
            var smoothed = box.ComputeSmoothedNormals();
            Assert.AreEqual(box.VertexCount, smoothed.Count);
            for (var i = 0; i < smoothed.Count; i++)
            {
                Assert.AreEqual(1f, smoothed[i].magnitude, 1e-4f);
                // A cube corner's averaged normal points along the diagonal.
                var expected = box.Vertices[i].normalized;
                Assert.Greater(Vector3.Dot(smoothed[i], expected), 0.999f);
            }
        }

        [Test]
        public void ToMesh_WritesOutlineNormalsChannel()
        {
            var builder = new MeshBuilder();
            builder.AddRoundedBox(Vector3.zero, Vector3.one, 0.1f, 3);
            var mesh = builder.ToMesh("Test");
            try
            {
                var uv3 = new List<Vector3>();
                mesh.GetUVs(3, uv3);
                Assert.AreEqual(mesh.vertexCount, uv3.Count, "UV3 must hold smoothed normals for the outline shader");
                Assert.AreEqual(1, mesh.subMeshCount);
                Assert.Greater(mesh.bounds.size.x, 0.99f);
            }
            finally
            {
                Object.DestroyImmediate(mesh);
            }
        }

        [Test]
        public void RoundedBox_KeepsRequestedSize()
        {
            var builder = new MeshBuilder();
            builder.AddRoundedBox(new Vector3(0f, 0.5f, 0f), new Vector3(2f, 1f, 0.5f), 0.1f, 4);
            var size = builder.CalculateBounds().size;
            Assert.AreEqual(2f, size.x, 1e-3f);
            Assert.AreEqual(1f, size.y, 1e-3f);
            Assert.AreEqual(0.5f, size.z, 1e-3f);
        }
    }
}
