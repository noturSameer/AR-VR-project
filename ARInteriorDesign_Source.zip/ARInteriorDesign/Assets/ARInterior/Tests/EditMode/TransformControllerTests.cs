using System;
using ARInterior.Core;
using ARInterior.Furniture;
using ARInterior.Interaction;
using NUnit.Framework;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ARInterior.Tests
{
    public class TransformControllerTests
    {
        GameObject m_ControllerObject;
        TransformController m_Controller;
        PlacedFurniture m_Item;
        readonly object m_OwnerA = new object();
        readonly object m_OwnerB = new object();

        [SetUp]
        public void SetUp()
        {
            m_ControllerObject = new GameObject("Transform Controller");
            m_Controller = m_ControllerObject.AddComponent<TransformController>();
            var itemObject = new GameObject("Item");
            var collider = itemObject.AddComponent<BoxCollider>();
            m_Item = itemObject.AddComponent<PlacedFurniture>();
            m_Item.Configure("test", "Test Item", Vector3.one, collider, Array.Empty<Renderer>(), 0.5f, 2f);
        }

        [TearDown]
        public void TearDown()
        {
            Object.DestroyImmediate(m_Item.gameObject);
            Object.DestroyImmediate(m_ControllerObject);
        }

        [Test]
        public void Lock_RejectsSecondOwner()
        {
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Move, m_OwnerA));
            Assert.IsFalse(m_Controller.TryBegin(m_Item, ManipulationKind.Rotate, m_OwnerB));
            Assert.IsFalse(m_Controller.TryBegin(m_Item, ManipulationKind.Move, m_OwnerA), "Re-entrant begin must also be refused");

            m_Controller.SetPosition(m_OwnerB, new Vector3(5f, 0f, 0f));
            Assert.AreEqual(Vector3.zero, m_Item.transform.position, "A non-owner must not move the object");

            m_Controller.SetPosition(m_OwnerA, new Vector3(1f, 0f, 2f));
            Assert.AreEqual(new Vector3(1f, 0f, 2f), m_Item.transform.position);

            m_Controller.End(m_OwnerA);
            Assert.IsFalse(m_Controller.IsManipulating);
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Rotate, m_OwnerB));
        }

        [Test]
        public void Operations_RespectManipulationKind()
        {
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Scale, m_OwnerA));
            m_Controller.SetPosition(m_OwnerA, Vector3.one);
            m_Controller.RotateBy(m_OwnerA, 45f);
            Assert.AreEqual(Vector3.zero, m_Item.transform.position);
            Assert.AreEqual(Quaternion.identity, m_Item.transform.rotation);
        }

        [Test]
        public void Rotate_WithoutSnap_IsContinuous()
        {
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Rotate, m_OwnerA, TransformAxis.Y));
            m_Controller.RotateBy(m_OwnerA, 10f);
            m_Controller.RotateBy(m_OwnerA, 2.5f);
            Assert.AreEqual(12.5f, m_Item.transform.eulerAngles.y, 1e-3f);
        }

        [Test]
        public void Rotate_WithSnap_UsesFifteenDegreeSteps()
        {
            m_Controller.SnapRotation = true;
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Rotate, m_OwnerA, TransformAxis.Y));
            m_Controller.RotateBy(m_OwnerA, 6f);
            Assert.AreEqual(0f, Mathf.DeltaAngle(0f, m_Item.transform.eulerAngles.y), 1e-3f);
            m_Controller.RotateBy(m_OwnerA, 4f); // 10° accumulated → 15°
            Assert.AreEqual(15f, m_Item.transform.eulerAngles.y, 1e-3f);
            m_Controller.RotateBy(m_OwnerA, 26f); // 36° accumulated → 30°
            Assert.AreEqual(30f, m_Item.transform.eulerAngles.y, 1e-3f);
        }

        [Test]
        public void Rotate_UsesSelectedLocalAxis()
        {
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Rotate, m_OwnerA, TransformAxis.X));
            m_Controller.RotateBy(m_OwnerA, 90f);
            Assert.AreEqual(0f, Vector3.Distance(m_Item.transform.up, Vector3.forward), 1e-4f);
        }

        [Test]
        public void Scale_IsUniformPositiveAndClamped()
        {
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Scale, m_OwnerA));
            m_Controller.ScaleFromStart(m_OwnerA, 1.5f);
            Assert.AreEqual(new Vector3(1.5f, 1.5f, 1.5f), m_Item.transform.localScale);
            m_Controller.ScaleFromStart(m_OwnerA, 100f);
            Assert.AreEqual(2f, m_Item.transform.localScale.x, 1e-5f);
            m_Controller.ScaleFromStart(m_OwnerA, -5f);
            Assert.AreEqual(0.5f, m_Item.transform.localScale.x, 1e-5f);
            Assert.AreEqual(m_Item.transform.localScale.x, m_Item.transform.localScale.z, 1e-6f);
        }

        [Test]
        public void Cancel_RestoresStartPose()
        {
            m_Item.transform.position = new Vector3(1f, 0f, 1f);
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Move, m_OwnerA));
            m_Controller.SetPosition(m_OwnerA, new Vector3(3f, 0f, 3f));
            m_Controller.Cancel(m_OwnerA, true);
            Assert.AreEqual(new Vector3(1f, 0f, 1f), m_Item.transform.position);
            Assert.IsFalse(m_Controller.IsManipulating);
        }

        [Test]
        public void ResetScale_IsRefusedDuringGesture()
        {
            m_Item.transform.localScale = Vector3.one * 1.8f;
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Move, m_OwnerA));
            Assert.IsFalse(m_Controller.TryResetScale(m_Item));
            m_Controller.ForceCancel(false);
            Assert.IsTrue(m_Controller.TryResetScale(m_Item));
            Assert.AreEqual(Vector3.one, m_Item.transform.localScale);
        }

        [Test]
        public void NonFiniteInput_IsIgnored()
        {
            Assert.IsTrue(m_Controller.TryBegin(m_Item, ManipulationKind.Move, m_OwnerA));
            m_Controller.SetPosition(m_OwnerA, new Vector3(float.NaN, 0f, 0f));
            Assert.AreEqual(Vector3.zero, m_Item.transform.position);
        }
    }
}
