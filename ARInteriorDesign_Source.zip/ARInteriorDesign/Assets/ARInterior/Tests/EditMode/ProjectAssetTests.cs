using System.Collections.Generic;
using System.Linq;
using ARInterior.EditorTools.Modeling;
using ARInterior.EditorTools.Setup;
using ARInterior.Furniture;
using ARInterior.Rendering;
using NUnit.Framework;
using TMPro;
using UnityEditor;
using UnityEngine;

namespace ARInterior.Tests
{
    /// <summary>Checks the generated project content (requires the setup wizard to have run).</summary>
    public class ProjectAssetTests
    {
        static FurnitureCatalog LoadCatalog()
        {
            var catalog = AssetDatabase.LoadAssetAtPath<FurnitureCatalog>(SetupPaths.Catalog);
            Assert.IsNotNull(catalog, "Run 'AR Interior/2. Run Full Setup' first");
            return catalog;
        }

        [Test]
        public void Catalogue_HasFiveDistinctResolvableModels()
        {
            var catalog = LoadCatalog();
            CollectionAssert.IsEmpty(catalog.Validate());
            Assert.GreaterOrEqual(catalog.Items.Count, 5);
            var expected = new[] { "Modern Chair", "Dining Table", "Sofa", "Floor Lamp", "Bookshelf" };
            CollectionAssert.AreEquivalent(expected, catalog.Items.Select(i => i.DisplayName).ToArray());
            Assert.AreEqual(catalog.Items.Count, catalog.Items.Select(i => i.Prefab).Distinct().Count(), "Each entry needs its own prefab");
            foreach (var item in catalog.Items)
            {
                Assert.IsNotNull(item.Prefab, item.Id);
                Assert.IsTrue(AssetDatabase.Contains(item.Prefab), $"{item.Id} prefab must be a project asset");
                Assert.IsNotNull(item.Thumbnail, $"{item.Id} thumbnail");
            }
        }

        [Test]
        public void FurniturePrefabs_PassStructuralValidation()
        {
            var problems = new List<string>();
            ProjectValidator.ValidateCatalogue(problems);
            CollectionAssert.IsEmpty(problems, string.Join("\n", problems));
        }

        [Test]
        public void FurnitureModels_HaveMeaningfulGeometry()
        {
            foreach (var item in LoadCatalog().Items)
            {
                var prefab = item.Prefab;
                Assert.GreaterOrEqual(prefab.Renderers.Length, 4, $"{item.Id} should be built from several components");
                var triangles = prefab.Renderers.Sum(r => r.GetComponent<MeshFilter>().sharedMesh.triangles.Length / 3);
                Assert.Greater(triangles, 100, $"{item.Id} is too simple to be a furniture model");
                var materials = prefab.Renderers.Select(r => r.sharedMaterial).Distinct().Count();
                Assert.GreaterOrEqual(materials, 2, $"{item.Id} should use more than one material");
            }
        }

        [Test]
        public void FurnitureModels_UseRealWorldDimensions()
        {
            var expected = new Dictionary<string, Vector3>
            {
                { FurnitureFactory.ModernChairId, new Vector3(0.48f, 0.82f, 0.52f) },
                { FurnitureFactory.DiningTableId, new Vector3(1.60f, 0.75f, 0.90f) },
                { FurnitureFactory.SofaId, new Vector3(2.00f, 0.85f, 0.90f) },
                { FurnitureFactory.FloorLampId, new Vector3(0.44f, 1.65f, 0.44f) },
                { FurnitureFactory.BookshelfId, new Vector3(0.80f, 1.80f, 0.30f) }
            };
            foreach (var model in FurnitureFactory.CreateAll())
            {
                var bounds = model.CalculateBounds();
                var target = expected[model.Id];
                Assert.AreEqual(target.x, bounds.size.x, 0.04f, $"{model.Id} width");
                Assert.AreEqual(target.y, bounds.size.y, 0.04f, $"{model.Id} height");
                Assert.AreEqual(target.z, bounds.size.z, 0.04f, $"{model.Id} depth");
                Assert.AreEqual(0f, bounds.min.y, 0.005f, $"{model.Id} pivot must be on the floor");
            }
        }

        [Test]
        public void OutlineShadersCompile_AndColourIsYellowOrange()
        {
            foreach (var name in new[] { SetupPaths.OutlineShader, SetupPaths.MaskShader, SetupPaths.UnlitColorShader, SetupPaths.PlaneGridShader })
            {
                var shader = Shader.Find(name);
                Assert.IsNotNull(shader, name);
                Assert.IsFalse(ShaderUtil.ShaderHasError(shader), $"{name} has compile errors");
                Assert.IsTrue(shader.isSupported, $"{name} is not supported on the current graphics API");
            }

            var outline = AssetDatabase.LoadAssetAtPath<Material>(SetupPaths.OutlineMaterial);
            Assert.IsNotNull(outline);
            var color = (Color32)outline.GetColor("_OutlineColor");
            Assert.AreEqual(new Color32(0xFF, 0xB0, 0x00, 0xFF), color);
            Assert.AreEqual((Color32)SelectionOutline.DefaultColor, color);
            Assert.Greater(outline.renderQueue, 2500, "Outline must render after opaque geometry (and its stencil mask)");
            var mask = AssetDatabase.LoadAssetAtPath<Material>(SetupPaths.MaskMaterial);
            Assert.Less(mask.renderQueue, outline.renderQueue);
        }

        [Test]
        public void RenderingAndPlatform_AreConfiguredForARCore()
        {
            var problems = new List<string>();
            ProjectValidator.ValidateRendering(problems);
            ProjectValidator.ValidatePlatform(problems);
            CollectionAssert.IsEmpty(problems, string.Join("\n", problems));
        }

        [Test]
        public void Scenes_AreCompleteWithoutMissingReferences()
        {
            var problems = new List<string>();
            ProjectValidator.ValidateScenes(problems);
            CollectionAssert.IsEmpty(problems, string.Join("\n", problems));
        }

        [Test]
        public void Font_ContainsEveryCharacterUsedByTheHud()
        {
            var font = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(SetupPaths.TmpFont);
            Assert.IsNotNull(font);
            const string characters = "AR Interior Design ×·—…°“”% 0123456789";
            var ok = font.HasCharacters(characters, out uint[] missing, true, true);
            var missingText = missing == null ? string.Empty : string.Join(", ", missing.Select(c => $"U+{c:X4}"));
            Assert.IsTrue(ok, "Missing glyphs: " + missingText);
        }
    }
}
