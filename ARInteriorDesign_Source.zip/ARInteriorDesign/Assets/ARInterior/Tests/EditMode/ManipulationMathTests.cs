using ARInterior.Core;
using NUnit.Framework;
using UnityEngine;

namespace ARInterior.Tests
{
    public class ManipulationMathTests
    {
        [TestCase(0f, 0f)]
        [TestCase(7f, 0f)]
        [TestCase(8f, 15f)]
        [TestCase(22f, 15f)]
        [TestCase(23f, 30f)]
        [TestCase(-22f, -15f)]
        [TestCase(181f, 180f)]
        public void SnapAngle_RoundsToFifteenDegreeSteps(float input, float expected)
        {
            Assert.AreEqual(expected, ManipulationMath.SnapAngle(input, 15f), 1e-4f);
        }

        [Test]
        public void SnapAngle_WithNonPositiveStep_ReturnsInput()
        {
            Assert.AreEqual(13.3f, ManipulationMath.SnapAngle(13.3f, 0f), 1e-5f);
        }

        [Test]
        public void ClampScale_KeepsScalePositiveAndWithinLimits()
        {
            Assert.AreEqual(0.5f, ManipulationMath.ClampScale(-3f, 0.5f, 2f), 1e-5f);
            Assert.AreEqual(0.5f, ManipulationMath.ClampScale(0f, 0.5f, 2f), 1e-5f);
            Assert.AreEqual(2f, ManipulationMath.ClampScale(10f, 0.5f, 2f), 1e-5f);
            Assert.AreEqual(1.3f, ManipulationMath.ClampScale(1.3f, 0.5f, 2f), 1e-5f);
            Assert.AreEqual(0.5f, ManipulationMath.ClampScale(float.NaN, 0.5f, 2f), 1e-5f);
            Assert.Greater(ManipulationMath.ClampScale(5f, -1f, -2f), 0f, "Invalid limits must still give a positive scale");
        }

        [Test]
        public void ScaleFactorFromDrag_DoublesAndHalves()
        {
            Assert.AreEqual(1f, ManipulationMath.ScaleFactorFromDrag(0f, 500f), 1e-5f);
            Assert.AreEqual(2f, ManipulationMath.ScaleFactorFromDrag(500f, 500f), 1e-5f);
            Assert.AreEqual(0.5f, ManipulationMath.ScaleFactorFromDrag(-500f, 500f), 1e-5f);
        }

        [Test]
        public void DegreesFromDrag_FullScreenWidthIsConfiguredAngle()
        {
            Assert.AreEqual(360f, ManipulationMath.DegreesFromDrag(1080f, 1080f, 360f), 1e-4f);
            Assert.AreEqual(0f, ManipulationMath.DegreesFromDrag(100f, 0f, 360f), 1e-6f);
        }

        [Test]
        public void TwistDegrees_DetectsQuarterTurn()
        {
            var twist = ManipulationMath.TwistDegrees(Vector2.zero, Vector2.right, Vector2.zero, Vector2.up);
            Assert.AreEqual(90f, twist, 1e-3f);
        }

        [Test]
        public void PinchRatio_IgnoresDegenerateStart()
        {
            Assert.AreEqual(2f, ManipulationMath.PinchRatio(100f, 200f), 1e-5f);
            Assert.AreEqual(1f, ManipulationMath.PinchRatio(0f, 200f), 1e-5f);
        }

        [Test]
        public void TryClosestPointOnAxis_FindsIntersection()
        {
            var ray = new Ray(new Vector3(2f, 5f, 0f), Vector3.down);
            Assert.IsTrue(ManipulationMath.TryClosestPointOnAxis(ray, Vector3.zero, Vector3.right, out var t));
            Assert.AreEqual(2f, t, 1e-4f);
        }

        [Test]
        public void TryClosestPointOnAxis_RejectsParallelRay()
        {
            var ray = new Ray(new Vector3(0f, 1f, 0f), Vector3.right);
            Assert.IsFalse(ManipulationMath.TryClosestPointOnAxis(ray, Vector3.zero, Vector3.right, out _));
        }

        [Test]
        public void TryIntersectHorizontalPlane_HitsFloor()
        {
            var ray = new Ray(new Vector3(1f, 2f, 1f), new Vector3(0f, -1f, 1f).normalized);
            Assert.IsTrue(ManipulationMath.TryIntersectHorizontalPlane(ray, 0f, out var point));
            Assert.AreEqual(0f, point.y, 1e-4f);
            Assert.AreEqual(3f, point.z, 1e-4f);
            Assert.IsFalse(ManipulationMath.TryIntersectHorizontalPlane(new Ray(Vector3.one, Vector3.up), 0f, out _));
        }

        [Test]
        public void FacingViewer_PointsFrontTowardsCameraOnTheFloorPlane()
        {
            var rotation = ManipulationMath.FacingViewer(Vector3.zero, new Vector3(0f, 1.6f, 3f));
            var forward = rotation * Vector3.forward;
            Assert.AreEqual(0f, forward.y, 1e-5f, "Placement rotation must be yaw-only");
            Assert.Greater(forward.z, 0.99f);
        }
    }
}
