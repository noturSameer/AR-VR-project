using System.Collections;
using System.IO;
using System.Linq;
using ARInterior.Core;
using ARInterior.Interaction;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace ARInterior.Tests
{
    /// <summary>
    /// Renders portrait 1080×1920 screenshots (3D scene + HUD) into Documentation/Screenshots for visual QA of
    /// the outline, gizmo and layout. Runs only when Unity is started with -captureScreenshots, otherwise the
    /// tests report as skipped (Unity's command-line runner does not honour NUnit's [Explicit]).
    /// </summary>
    public class DocumentationScreenshots
    {
        [SetUp]
        public void RequireOptIn()
        {
            if (!System.Environment.GetCommandLineArgs().Contains("-captureScreenshots"))
                Assert.Ignore("Screenshot capture is opt-in: start Unity with -captureScreenshots.");
        }

        const int Width = 1080;
        const int Height = 1920;

        static string OutputFolder => Path.GetFullPath(Path.Combine(Application.dataPath, "..", "Documentation", "Screenshots"));

        static IEnumerator Capture(string fileName)
        {
            var interaction = Object.FindAnyObjectByType<InteractionController>();
            var camera = interaction.ViewCamera;
            var canvas = Object.FindObjectsByType<Canvas>(FindObjectsInactive.Exclude).First(c => c.isRootCanvas);
            var target = new RenderTexture(Width, Height, 24, RenderTextureFormat.ARGB32) { antiAliasing = 4 };
            target.Create();
            var previousMode = canvas.renderMode;
            try
            {
                camera.targetTexture = target;
                canvas.renderMode = RenderMode.ScreenSpaceCamera;
                canvas.worldCamera = camera;
                canvas.planeDistance = 1f;
                yield return null;
                Canvas.ForceUpdateCanvases();
                camera.Render();

                var previousActive = RenderTexture.active;
                RenderTexture.active = target;
                var texture = new Texture2D(Width, Height, TextureFormat.RGB24, false);
                texture.ReadPixels(new Rect(0, 0, Width, Height), 0, 0);
                texture.Apply();
                RenderTexture.active = previousActive;

                Directory.CreateDirectory(OutputFolder);
                File.WriteAllBytes(Path.Combine(OutputFolder, fileName), texture.EncodeToPNG());
                Object.Destroy(texture);
            }
            finally
            {
                camera.targetTexture = null;
                canvas.renderMode = previousMode;
                target.Release();
                Object.Destroy(target);
            }
        }

        [UnityTest]
        public IEnumerator CaptureDemoScene()
        {
            yield return SceneManager.LoadSceneAsync("DemoScene", LoadSceneMode.Single);
            yield return null;
            var interaction = Object.FindAnyObjectByType<InteractionController>();
            var placement = interaction.Placement;

            void Place(string id, Vector3 position, float yaw)
            {
                placement.Arm(placement.Catalog.FindById(id));
                var item = placement.PlaceAt(placement.ArmedItem, new SurfaceHit(new Pose(position, Quaternion.identity), null, 1f));
                item.transform.rotation = Quaternion.Euler(0f, yaw, 0f);
            }

            // A small living/dining corner: sofa against the back wall, bookshelf on the left wall.
            Place("sofa", new Vector3(-0.4f, 0f, -2.5f), 0f);
            Place("floor-lamp", new Vector3(1.05f, 0f, -2.6f), 0f);
            Place("bookshelf", new Vector3(-2.82f, 0f, -0.9f), 90f);
            Place("dining-table", new Vector3(0.3f, 0.008f, 0.55f), 0f);
            Place("modern-chair", new Vector3(0.3f, 0.008f, 1.2f), 180f);

            yield return Capture("01_demo_select_mode.png");

            var chair = placement.PlacedItems.Last();
            interaction.Selection.Select(chair);
            interaction.SetMode(InteractionMode.Move);
            yield return Capture("02_demo_move_mode_outline_gizmo.png");

            var sofa = placement.PlacedItems.First();
            interaction.Selection.Select(sofa);
            interaction.SetMode(InteractionMode.Rotate);
            interaction.SetSnapRotation(true);
            yield return Capture("03_demo_rotate_mode.png");

            interaction.SetMode(InteractionMode.Scale);
            yield return Capture("04_demo_scale_mode.png");

            interaction.Selection.Deselect();
            interaction.SetMode(InteractionMode.Select);
            placement.Arm(placement.Catalog.FindById("bookshelf"));
            yield return Capture("05_demo_catalogue_armed.png");
            Assert.IsTrue(File.Exists(Path.Combine(OutputFolder, "05_demo_catalogue_armed.png")));
        }

        [UnityTest]
        public IEnumerator CaptureARSceneWithoutARSupport()
        {
            yield return SceneManager.LoadSceneAsync("MainARScene", LoadSceneMode.Single);
            var status = Object.FindAnyObjectByType<InteractionController>().StatusProvider;
            var timeout = Time.realtimeSinceStartup + 5f;
            while (status.Current.State == ExperienceState.Initializing && Time.realtimeSinceStartup < timeout)
                yield return null;
            yield return Capture("06_ar_scene_unsupported_in_editor.png");
            Assert.IsTrue(File.Exists(Path.Combine(OutputFolder, "06_ar_scene_unsupported_in_editor.png")));
        }
    }
}
