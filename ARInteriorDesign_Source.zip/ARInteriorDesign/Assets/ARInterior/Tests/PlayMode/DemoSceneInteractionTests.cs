using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ARInterior.Core;
using ARInterior.Furniture;
using ARInterior.Interaction;
using ARInterior.Rendering;
using ARInterior.UI;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using UnityEngine.TestTools;
using UnityEngine.UI;

namespace ARInterior.Tests
{
    /// <summary>
    /// End-to-end checks in DemoScene: the real scene, prefabs, outline materials, HUD and input routing.
    /// Gestures are injected either through the InteractionController's gesture API or, for UI-priority
    /// tests, through a scripted pointer source fed into the real TouchInputRouter.
    /// </summary>
    public class DemoSceneInteractionTests
    {
        sealed class ScriptedPointerSource : IPointerSource
        {
            readonly Queue<PointerSample[]> m_Frames = new Queue<PointerSample[]>();

            public void Enqueue(params PointerSample[] frame) => m_Frames.Enqueue(frame);
            public bool IsEmpty => m_Frames.Count == 0;

            public void Collect(List<PointerSample> results)
            {
                results.Clear();
                if (m_Frames.Count > 0)
                    results.AddRange(m_Frames.Dequeue());
            }
        }

        InteractionController m_Interaction;
        PlacementController m_Placement;
        SelectionManager m_Selection;
        TransformController m_Transformer;
        SelectionOutline m_Outline;
        TouchInputRouter m_Router;
        ARInteriorHUD m_Hud;
        Camera m_Camera;

        [UnitySetUp]
        public IEnumerator LoadDemoScene()
        {
            yield return SceneManager.LoadSceneAsync("DemoScene", LoadSceneMode.Single);
            yield return null;
            m_Interaction = Object.FindAnyObjectByType<InteractionController>();
            m_Placement = m_Interaction.Placement;
            m_Selection = m_Interaction.Selection;
            m_Transformer = m_Interaction.Transformer;
            m_Outline = m_Selection.Outline;
            m_Router = Object.FindAnyObjectByType<TouchInputRouter>();
            m_Hud = Object.FindAnyObjectByType<ARInteriorHUD>();
            m_Camera = m_Interaction.ViewCamera;
            Assert.Greater(m_Camera.pixelWidth, 0, "Camera needs a valid viewport for screen-space tests");
        }

        Vector2 ScreenOf(Vector3 world) => m_Camera.WorldToScreenPoint(world);

        /// <summary>Floor point under a screen position given as a fraction of the screen (open area, away from the HUD).</summary>
        Vector3 FloorUnderScreen(float u, float v)
        {
            var ray = m_Camera.ScreenPointToRay(new Vector2(Screen.width * u, Screen.height * v));
            Assert.IsTrue(Physics.Raycast(ray, out var hit, 100f, LayerMask.GetMask("DemoSurface")), "No floor under that screen point");
            return hit.point;
        }

        static string DescribeUiHits(Vector2 position)
        {
            var eventSystem = EventSystem.current;
            var hits = new List<RaycastResult>();
            eventSystem.RaycastAll(new PointerEventData(eventSystem) { position = position }, hits);
            return $"screen {Screen.width}x{Screen.height}, point {position}, UI hits: " +
                   string.Join(", ", hits.Select(h => h.gameObject.name));
        }

        FurnitureDefinition Definition(string id) => m_Placement.Catalog.FindById(id);

        PlacedFurniture PlaceAt(string id, Vector3 floorPoint)
        {
            m_Placement.Arm(Definition(id));
            Assert.IsTrue(m_Placement.IsArmed);
            var before = m_Placement.PlacedCount;
            m_Interaction.OnTap(ScreenOf(floorPoint));
            Assert.AreEqual(before + 1, m_Placement.PlacedCount, m_Interaction.ActiveMessage);
            return m_Placement.PlacedItems.Last();
        }

        static IEnumerator NextPlacementWindow()
        {
            // Placement has a 0.3 s duplicate-protection cooldown.
            yield return new WaitForSecondsRealtime(0.35f);
        }

        [Test]
        public void Scene_StartsReady_WithEveryControlConnected()
        {
            Assert.AreEqual(ExperienceState.Demo, m_Interaction.StatusProvider.Current.State);
            Assert.IsTrue(m_Interaction.StatusProvider.Current.AllowsInteraction);
            Assert.AreEqual(InteractionMode.Select, m_Interaction.Mode);
            var buttons = m_Hud.GetComponentsInChildren<Button>(true);
            Assert.GreaterOrEqual(buttons.Length, 20);
            foreach (var button in buttons)
                Assert.IsTrue(m_Hud.BoundButtons.Contains(button), $"Button '{button.name}' has no runtime action");
            Assert.AreEqual(5, m_Placement.Catalog.Items.Count);
        }

        [Test]
        public void Placement_PutsArmedItemOnTheFloorAndSelectsIt()
        {
            var target = new Vector3(0.5f, 0f, 0.6f);
            var chair = PlaceAt("modern-chair", target);
            Assert.AreEqual(0f, Vector3.Distance(new Vector3(target.x, 0f, target.z), new Vector3(chair.transform.position.x, 0f, chair.transform.position.z)), 0.02f);
            Assert.AreEqual(0.008f, chair.transform.position.y, 0.002f, "The chair stands on the rug surface");
            Assert.AreSame(chair, m_Selection.Selected);
            Assert.IsFalse(m_Placement.IsArmed, "Placement disarms to prevent duplicates");
            var forward = chair.transform.forward;
            var toCamera = m_Camera.transform.position - chair.transform.position;
            toCamera.y = 0f;
            Assert.Greater(Vector3.Dot(forward, toCamera.normalized), 0.99f, "New furniture faces the viewer");
        }

        [UnityTest]
        public IEnumerator Placement_RepeatedTapsDoNotDuplicate()
        {
            m_Placement.Arm(Definition("sofa"));
            var screen = ScreenOf(new Vector3(-0.5f, 0f, -0.5f));
            m_Interaction.OnTap(screen);
            m_Placement.Arm(Definition("sofa"));
            m_Interaction.OnTap(screen); // same frame: suppressed by the duplicate guard
            Assert.AreEqual(1, m_Placement.PlacedCount);
            yield return null;
            m_Interaction.OnTap(screen); // within cooldown and still armed
            Assert.AreEqual(1, m_Placement.PlacedCount);
            yield return NextPlacementWindow();
            m_Interaction.OnTap(screen);
            Assert.AreEqual(2, m_Placement.PlacedCount, "After the cooldown an intentional tap places again");
        }

        [Test]
        public void Placement_OutsideTheRoom_ExplainsWhy()
        {
            m_Placement.Arm(Definition("floor-lamp"));
            m_Interaction.OnTap(new Vector2(2f, m_Camera.pixelHeight - 2f)); // top-left corner: background, not floor
            Assert.AreEqual(0, m_Placement.PlacedCount);
            Assert.IsNotNull(m_Interaction.ActiveMessage);
        }

        [Test]
        public void Selection_ShowsYellowOrangeOutlineAndDeselectRestoresMaterials()
        {
            var lamp = PlaceAt("floor-lamp", new Vector3(1.2f, 0f, -1f));
            var originals = lamp.Renderers.Select(r => r.sharedMaterials.Length).ToArray();
            foreach (var r in lamp.Renderers)
            {
                Assert.IsTrue(m_Outline.IsOutlined(r));
                Assert.Contains(m_Outline.OutlineMaterialInstance, r.sharedMaterials);
                Assert.Contains(m_Outline.MaskMaterialInstance, r.sharedMaterials);
            }

            Assert.AreEqual(new Color32(0xFF, 0xB0, 0x00, 0xFF), (Color32)m_Outline.OutlineMaterialInstance.GetColor("_OutlineColor"));
            Assert.IsTrue(m_Outline.OutlineMaterialInstance.shader.isSupported);

            // Tap empty floor → deselect.
            m_Interaction.OnTap(ScreenOf(new Vector3(-1.5f, 0f, 1.5f)));
            Assert.IsNull(m_Selection.Selected);
            for (var i = 0; i < lamp.Renderers.Length; i++)
            {
                Assert.AreEqual(originals[i] - 2, lamp.Renderers[i].sharedMaterials.Length);
                Assert.IsFalse(m_Outline.IsOutlined(lamp.Renderers[i]));
            }

            // Tap the lamp → select again.
            m_Interaction.OnTap(ScreenOf(lamp.transform.position + Vector3.up * 1.0f));
            Assert.AreSame(lamp, m_Selection.Selected);
        }

        [Test]
        public void Move_SurfaceDragFollowsTheFloor()
        {
            var table = PlaceAt("dining-table", new Vector3(0f, 0f, -1.2f));
            m_Interaction.SetMode(InteractionMode.Move);
            Assert.IsTrue(m_Interaction.MoveGizmo.IsVisible, "Move mode shows the X/Y/Z handles");
            var start = ScreenOf(table.transform.position + new Vector3(0.6f, 0f, 0f));
            Assert.IsTrue(m_Interaction.OnDragBegin(start, start));
            Assert.IsTrue(m_Interaction.OnDragUpdate(ScreenOf(new Vector3(-0.4f, 0f, -0.2f) + new Vector3(0.6f, 0f, 0f))));
            m_Interaction.OnDragEnd();
            Assert.AreEqual(-0.4f, table.transform.position.x, 0.03f);
            Assert.AreEqual(-0.2f, table.transform.position.z, 0.03f);
            Assert.AreEqual(0f, table.transform.position.y, 0.01f, "Surface move keeps the item on the floor");
            Assert.IsFalse(m_Transformer.IsManipulating);
        }

        [Test]
        public void Move_AxisYLiftsWithoutSideways()
        {
            var chair = PlaceAt("modern-chair", new Vector3(-1f, 0f, -1f));
            m_Interaction.SetMode(InteractionMode.Move);
            m_Interaction.SetMoveConstraint(MoveConstraint.AxisY);
            // Points on the vertical axis above the horizontal handles; grabbing the Y handle is equivalent.
            var start = ScreenOf(chair.transform.position + Vector3.up * 1.2f);
            var end = ScreenOf(chair.transform.position + Vector3.up * 1.7f);
            Assert.IsTrue(m_Interaction.OnDragBegin(start, start));
            m_Interaction.OnDragUpdate(end);
            m_Interaction.OnDragEnd();
            Assert.AreEqual(0.5f, chair.transform.position.y, 0.05f);
            Assert.AreEqual(-1f, chair.transform.position.x, 0.01f);
            Assert.AreEqual(-1f, chair.transform.position.z, 0.01f);
        }

        [Test]
        public void Move_GrabbingAGizmoHandleUsesThatAxis()
        {
            var lamp = PlaceAt("floor-lamp", new Vector3(0.8f, 0f, 0.8f));
            m_Interaction.SetMode(InteractionMode.Move);
            var gizmo = m_Interaction.MoveGizmo;
            Assert.IsTrue(gizmo.IsVisible);
            var handle = gizmo.Handles.First(h => h.Axis == TransformAxis.X);
            var grab = ScreenOf(handle.transform.TransformPoint(new Vector3(0f, 0.6f, 0f)));
            Assert.IsTrue(gizmo.TryPickHandle(grab, out var axis));
            Assert.AreEqual(TransformAxis.X, axis);
            var startPosition = lamp.transform.position;
            Assert.IsTrue(m_Interaction.OnDragBegin(grab, grab));
            m_Interaction.OnDragUpdate(grab + new Vector2(60f, 120f)); // partly off-axis drag
            m_Interaction.OnDragEnd();
            Assert.AreEqual(startPosition.y, lamp.transform.position.y, 1e-3f, "An X-handle drag must not change height");
            var localMove = lamp.transform.InverseTransformDirection(lamp.transform.position - startPosition);
            Assert.Greater(Mathf.Abs(localMove.x), 0.01f, "The lamp moved along X");
            Assert.AreEqual(0f, localMove.y, 1e-3f);
            Assert.AreEqual(0f, localMove.z, 1e-3f, "Movement stays on the local X axis");
        }

        [Test]
        public void Rotate_SnapsToFifteenDegrees()
        {
            var sofa = PlaceAt("sofa", new Vector3(0f, 0f, 0f));
            var startYaw = sofa.transform.eulerAngles.y;
            m_Interaction.SetMode(InteractionMode.Rotate);
            m_Interaction.SetSnapRotation(true);
            var start = ScreenOf(sofa.transform.position + Vector3.up * 0.4f);
            Assert.IsTrue(m_Interaction.OnDragBegin(start, start));
            m_Interaction.OnDragUpdate(start + new Vector2(Screen.width * 0.1f, 0f)); // 36° → 30° snapped
            m_Interaction.OnDragEnd();
            var delta = Mathf.DeltaAngle(startYaw, sofa.transform.eulerAngles.y);
            Assert.AreEqual(0f, Mathf.Repeat(delta + 0.01f, 15f), 0.05f, $"Rotation delta {delta} is not a multiple of 15°");
            Assert.AreEqual(30f, Mathf.Abs(delta), 0.05f);
        }

        [Test]
        public void Rotate_WithoutSnapIsContinuous()
        {
            var sofa = PlaceAt("sofa", new Vector3(0f, 0f, 0f));
            var startYaw = sofa.transform.eulerAngles.y;
            m_Interaction.SetMode(InteractionMode.Rotate);
            var start = ScreenOf(sofa.transform.position + Vector3.up * 0.4f);
            Assert.IsTrue(m_Interaction.OnDragBegin(start, start));
            m_Interaction.OnDragUpdate(start + new Vector2(Screen.width * 0.05f, 0f)); // 18°
            m_Interaction.OnDragEnd();
            Assert.AreEqual(18f, Mathf.Abs(Mathf.DeltaAngle(startYaw, sofa.transform.eulerAngles.y)), 0.1f);
        }

        [Test]
        public void Scale_IsUniformAndClampedToLimits()
        {
            var shelf = PlaceAt("bookshelf", new Vector3(-1.5f, 0f, -2f));
            m_Interaction.SetMode(InteractionMode.Scale);
            var start = ScreenOf(shelf.transform.position + Vector3.up * 0.9f);
            Assert.IsTrue(m_Interaction.OnDragBegin(start, start));
            m_Interaction.OnDragUpdate(start + new Vector2(0f, Screen.height * 2f));
            Assert.AreEqual(shelf.MaxScale, shelf.transform.localScale.x, 1e-4f);
            m_Interaction.OnDragUpdate(start - new Vector2(0f, Screen.height * 4f));
            Assert.AreEqual(shelf.MinScale, shelf.transform.localScale.x, 1e-4f);
            Assert.Greater(shelf.transform.localScale.x, 0f);
            m_Interaction.OnDragEnd();
            var s = shelf.transform.localScale;
            Assert.AreEqual(s.x, s.y, 1e-6f);
            Assert.AreEqual(s.x, s.z, 1e-6f);

            m_Interaction.ResetSelectedScale();
            Assert.AreEqual(1f, shelf.transform.localScale.x, 1e-6f);
        }

        [Test]
        public void TwoFingerPinch_ScalesSelectedItem()
        {
            var chair = PlaceAt("modern-chair", new Vector3(0.3f, 0f, 0.3f));
            var center = ScreenOf(chair.transform.position);
            Assert.IsTrue(m_Interaction.OnTwoFingerBegin(center - new Vector2(50f, 0f), center + new Vector2(50f, 0f)));
            m_Interaction.OnTwoFingerUpdate(center - new Vector2(75f, 0f), center + new Vector2(75f, 0f));
            m_Interaction.OnTwoFingerEnd();
            Assert.AreEqual(1.5f, chair.transform.localScale.x, 1e-3f);
        }

        [Test]
        public void TwoFingerTwist_RotatesAroundVerticalAxis()
        {
            var chair = PlaceAt("modern-chair", new Vector3(0.3f, 0f, 0.3f));
            var startYaw = chair.transform.eulerAngles.y;
            var startUp = chair.transform.up;
            var center = ScreenOf(chair.transform.position);
            var offset = new Vector2(80f, 0f);
            Assert.IsTrue(m_Interaction.OnTwoFingerBegin(center - offset, center + offset));
            var twisted = (Vector2)(Quaternion.Euler(0f, 0f, 30f) * offset);
            m_Interaction.OnTwoFingerUpdate(center - twisted, center + twisted);
            m_Interaction.OnTwoFingerEnd();
            Assert.AreEqual(30f, Mathf.Abs(Mathf.DeltaAngle(startYaw, chair.transform.eulerAngles.y)), 0.1f);
            Assert.Greater(Vector3.Dot(startUp, chair.transform.up), 0.9999f, "Twist must not tilt the furniture");
            Assert.AreEqual(1f, chair.transform.localScale.x, 1e-3f, "Pure twist keeps the size");
        }

        [UnityTest]
        public IEnumerator Delete_RemovesItemAndClearsSelection()
        {
            var lamp = PlaceAt("floor-lamp", new Vector3(1f, 0f, 1f));
            m_Interaction.SetMode(InteractionMode.Move);
            m_Interaction.DeleteSelected();
            Assert.IsNull(m_Selection.Selected);
            Assert.IsNull(m_Outline.Current);
            Assert.AreEqual(0, m_Placement.PlacedCount);
            Assert.IsFalse(m_Interaction.MoveGizmo.IsVisible);
            yield return null;
            Assert.IsTrue(lamp == null, "The deleted object is destroyed");
            m_Interaction.DeleteSelected(); // nothing selected: must be safe
            Assert.IsNotNull(m_Interaction.ActiveMessage);
        }

        [Test]
        public void TransformLock_BlocksASecondHandler()
        {
            var chair = PlaceAt("modern-chair", new Vector3(0f, 0f, 0.5f));
            var otherHandler = new object();
            Assert.IsTrue(m_Transformer.TryBegin(chair, ManipulationKind.Move, otherHandler));
            m_Interaction.SetMode(InteractionMode.Rotate);
            var p = ScreenOf(chair.transform.position);
            Assert.IsFalse(m_Interaction.OnDragBegin(p, p), "Touch must not start while another handler owns the transform");
            m_Transformer.End(otherHandler);
            Assert.IsTrue(m_Interaction.OnDragBegin(p, p));
            m_Interaction.OnDragEnd();
        }

        [Test]
        public void ModeChange_DuringDrag_EndsTheGestureCleanly()
        {
            var chair = PlaceAt("modern-chair", new Vector3(0f, 0f, 0.5f));
            m_Interaction.SetMode(InteractionMode.Move);
            var p = ScreenOf(chair.transform.position);
            Assert.IsTrue(m_Interaction.OnDragBegin(p, p));
            Assert.IsTrue(m_Transformer.IsManipulating);
            m_Interaction.SetMode(InteractionMode.Scale);
            Assert.IsFalse(m_Transformer.IsManipulating);
            Assert.IsFalse(m_Interaction.OnDragUpdate(p + new Vector2(0f, 100f)), "Stale drag updates are rejected");
            Assert.AreEqual(1f, chair.transform.localScale.x, 1e-6f);
        }

        [UnityTest]
        public IEnumerator UiTouch_HasPriorityOverTheScene()
        {
            var source = new ScriptedPointerSource();
            m_Router.SetPointerSource(source);
            m_Placement.Arm(Definition("modern-chair"));

            // A tap on the Move tool button: handled by the UI only, nothing is placed.
            var moveButton = m_Hud.GetComponentsInChildren<Button>(true).First(b => b.name == "Move Tool");
            var buttonScreen = RectTransformUtility.WorldToScreenPoint(null, moveButton.transform.position);
            Assert.IsTrue(m_Router.IsOverUI(buttonScreen), "The button must be hit by the UI raycast");
            source.Enqueue(new PointerSample(1, buttonScreen, PointerPhase.Began));
            source.Enqueue(new PointerSample(1, buttonScreen, PointerPhase.Ended));
            yield return null;
            yield return null;
            yield return null;
            Assert.AreEqual(0, m_Placement.PlacedCount, "A UI touch must not place furniture");

            // The same tap on open floor reaches the scene.
            var floor = new Vector2(Screen.width * 0.42f, Screen.height * 0.6f);
            Assert.IsFalse(m_Router.IsOverUI(floor), DescribeUiHits(floor));
            source.Enqueue(new PointerSample(2, floor, PointerPhase.Began));
            source.Enqueue(new PointerSample(2, floor, PointerPhase.Ended));
            yield return null;
            yield return null;
            yield return null;
            Assert.AreEqual(1, m_Placement.PlacedCount);
        }

        [UnityTest]
        public IEnumerator RouterDrag_MovesSelectedItemThroughRealInputPath()
        {
            var chair = PlaceAt("modern-chair", FloorUnderScreen(0.35f, 0.6f));
            var startPosition = chair.transform.position;
            m_Interaction.SetMode(InteractionMode.Move);
            var source = new ScriptedPointerSource();
            m_Router.SetPointerSource(source);
            // Grab the floor beside the chair (away from the gizmo handles) and slide 0.6 m along +X.
            var grabPoint = startPosition + new Vector3(0.35f, 0f, 0f);
            var from = ScreenOf(grabPoint);
            var to = ScreenOf(grabPoint + new Vector3(0.6f, 0f, 0f));
            Assert.IsFalse(m_Router.IsOverUI(from), DescribeUiHits(from));
            source.Enqueue(new PointerSample(7, from, PointerPhase.Began));
            for (var i = 1; i <= 5; i++)
                source.Enqueue(new PointerSample(7, Vector2.Lerp(from, to, i / 5f), PointerPhase.Moved));
            source.Enqueue(new PointerSample(7, to, PointerPhase.Ended));
            while (!source.IsEmpty)
                yield return null;
            yield return null;
            Assert.AreEqual(startPosition.x + 0.6f, chair.transform.position.x, 0.04f);
            Assert.AreEqual(startPosition.z, chair.transform.position.z, 0.04f);
            Assert.IsFalse(m_Transformer.IsManipulating);
        }

        [Test]
        public void HudButtons_DriveTheTools()
        {
            Button Find(string name) => m_Hud.GetComponentsInChildren<Button>(true).First(b => b.name == name);

            Find("Rotate Tool").onClick.Invoke();
            Assert.AreEqual(InteractionMode.Rotate, m_Interaction.Mode);
            Find("Rotate X").onClick.Invoke();
            Assert.AreEqual(TransformAxis.X, m_Interaction.RotationAxis);
            Find("Snap Toggle").onClick.Invoke();
            Assert.IsTrue(m_Interaction.SnapRotation);
            Find("Snap Toggle").onClick.Invoke();
            Assert.IsFalse(m_Interaction.SnapRotation);

            Find("Move Tool").onClick.Invoke();
            Assert.AreEqual(InteractionMode.Move, m_Interaction.Mode);
            Find("Move Z").onClick.Invoke();
            Assert.AreEqual(MoveConstraint.AxisZ, m_Interaction.MoveConstraint);
            Find("Move Floor").onClick.Invoke();
            Assert.AreEqual(MoveConstraint.Surface, m_Interaction.MoveConstraint);

            Find("Scale Tool").onClick.Invoke();
            Assert.AreEqual(InteractionMode.Scale, m_Interaction.Mode);
            Find("Select Tool").onClick.Invoke();
            Assert.AreEqual(InteractionMode.Select, m_Interaction.Mode);

            Find("Card Bookshelf").onClick.Invoke();
            Assert.AreEqual("bookshelf", m_Placement.ArmedItem.Id);
            Find("Card Bookshelf").onClick.Invoke();
            Assert.IsFalse(m_Placement.IsArmed, "Tapping the armed card again cancels placement");

            var shelf = PlaceAt("bookshelf", new Vector3(-1f, 0f, -2f));
            Assert.IsTrue(Find("Delete Tool").interactable);
            Find("Delete Tool").onClick.Invoke();
            Assert.AreEqual(0, m_Placement.PlacedCount);
            Assert.IsFalse(Find("Delete Tool").interactable, "Delete is disabled without a selection");
            Assert.IsTrue(shelf.IsBeingDestroyed);
        }

        [UnityTest]
        public IEnumerator SwitchButton_LoadsTheARScene()
        {
            var button = m_Hud.GetComponentsInChildren<Button>(true).First(b => b.name == "Switch Scene Button");
            button.onClick.Invoke();
            var timeout = Time.realtimeSinceStartup + 10f;
            while (SceneManager.GetActiveScene().name != "MainARScene" && Time.realtimeSinceStartup < timeout)
                yield return null;
            Assert.AreEqual("MainARScene", SceneManager.GetActiveScene().name);
        }
    }
}
