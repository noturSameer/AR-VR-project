using System.Collections;
using System.Linq;
using ARInterior.Core;
using ARInterior.Interaction;
using ARInterior.UI;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace ARInterior.Tests
{
    /// <summary>
    /// MainARScene in the Editor has no ARCore device, so it must degrade gracefully: load without errors,
    /// report that AR is unavailable and refuse scene interaction instead of placing furniture blindly.
    /// </summary>
    public class MainARSceneTests
    {
        [UnityTest]
        public IEnumerator MainARScene_WithoutARSupport_BlocksInteractionGracefully()
        {
            yield return SceneManager.LoadSceneAsync("MainARScene", LoadSceneMode.Single);
            var interaction = Object.FindAnyObjectByType<InteractionController>();
            Assert.IsNotNull(interaction);
            Assert.IsNotNull(Object.FindAnyObjectByType<ARInteriorHUD>());
            var status = interaction.StatusProvider;
            var timeout = Time.realtimeSinceStartup + 5f;
            while (status.Current.State == ExperienceState.Initializing && Time.realtimeSinceStartup < timeout)
                yield return null;

            Debug.Log($"[ARInterior] MainARScene status in the Editor: {status.Current.State} – {status.Current.Headline}");
            Assert.IsFalse(status.IsDemo);
            Assert.AreEqual(ExperienceState.Unsupported, status.Current.State, "No AR subsystem must resolve to Unsupported, not hang in 'Checking'");
            Assert.IsFalse(status.Current.AllowsInteraction, "Without tracking the scene must not accept placement");
            var switchButton = Object.FindAnyObjectByType<ARInteriorHUD>().GetComponentsInChildren<HudButton>(true)
                .First(b => b.name == "Switch Scene Button");
            Assert.IsTrue(switchButton.IsActive, "The Demo button is highlighted when AR is unsupported");

            interaction.Placement.Arm(interaction.Placement.Catalog.Items[0]);
            interaction.OnTap(new Vector2(Screen.width * 0.5f, Screen.height * 0.5f));
            Assert.AreEqual(0, interaction.Placement.PlacedCount);
            interaction.SetMode(InteractionMode.Move);
            Assert.IsFalse(interaction.OnDragBegin(Vector2.one * 100f, Vector2.one * 200f));
        }
    }
}
