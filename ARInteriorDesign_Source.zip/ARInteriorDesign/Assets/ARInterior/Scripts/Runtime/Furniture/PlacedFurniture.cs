using System;
using UnityEngine;

namespace ARInterior.Furniture
{
    /// <summary>
    /// Root component of every furniture prefab. Pivot is the centre of the footprint on the floor,
    /// the model's front faces +Z. Holds the cached renderers used by the selection outline and the
    /// scale limits enforced by the transform tools.
    /// </summary>
    [DisallowMultipleComponent]
    public sealed class PlacedFurniture : MonoBehaviour
    {
        [SerializeField] string m_FurnitureId = string.Empty;
        [SerializeField] string m_DisplayName = string.Empty;
        [SerializeField] Vector3 m_Dimensions = Vector3.one;
        [SerializeField] BoxCollider m_SelectionCollider;
        [SerializeField] Renderer[] m_Renderers = Array.Empty<Renderer>();
        [SerializeField, Min(0.05f)] float m_MinScale = 0.5f;
        [SerializeField, Min(0.05f)] float m_MaxScale = 2f;

        bool m_IsBeingDestroyed;

        /// <summary>Raised from OnDestroy so selection and registries can drop their references.</summary>
        public event Action<PlacedFurniture> Destroyed;

        public string FurnitureId => m_FurnitureId;
        public string DisplayName => string.IsNullOrEmpty(m_DisplayName) ? name : m_DisplayName;
        public Vector3 Dimensions => m_Dimensions;
        public BoxCollider SelectionCollider => m_SelectionCollider;
        public Renderer[] Renderers => m_Renderers;
        public float MinScale => m_MinScale;
        public float MaxScale => Mathf.Max(m_MinScale, m_MaxScale);
        public float UniformScale => transform.localScale.x;
        public bool IsBeingDestroyed => m_IsBeingDestroyed;

        /// <summary>Authoring entry point used by the setup wizard.</summary>
        public void Configure(string id, string displayName, Vector3 dimensions, BoxCollider selectionCollider,
            Renderer[] renderers, float minScale, float maxScale)
        {
            m_FurnitureId = id;
            m_DisplayName = displayName;
            m_Dimensions = dimensions;
            m_SelectionCollider = selectionCollider;
            m_Renderers = renderers ?? Array.Empty<Renderer>();
            m_MinScale = minScale;
            m_MaxScale = maxScale;
        }

        void Awake()
        {
            if (m_Renderers == null || m_Renderers.Length == 0)
                m_Renderers = GetComponentsInChildren<Renderer>(true);
            if (m_SelectionCollider == null)
                m_SelectionCollider = GetComponent<BoxCollider>();
        }

        /// <summary>World-space bounds of all renderers (used to place the move gizmo).</summary>
        public Bounds CalculateWorldBounds()
        {
            var hasBounds = false;
            var bounds = new Bounds(transform.position, Vector3.zero);
            foreach (var r in m_Renderers)
            {
                if (r == null)
                    continue;
                if (!hasBounds)
                {
                    bounds = r.bounds;
                    hasBounds = true;
                }
                else
                {
                    bounds.Encapsulate(r.bounds);
                }
            }

            return bounds;
        }

        /// <summary>Marks the object so in-flight async work (anchors) can bail out, then destroys it.</summary>
        public void DestroySelf()
        {
            if (m_IsBeingDestroyed)
                return;
            m_IsBeingDestroyed = true;
            Destroy(gameObject);
        }

        void OnDestroy()
        {
            m_IsBeingDestroyed = true;
            Destroyed?.Invoke(this);
            Destroyed = null;
        }
    }
}
