using System.Collections.Generic;
using UnityEngine;

namespace ARInterior.Furniture
{
    /// <summary>Ordered list of furniture shown in the catalogue bar.</summary>
    [CreateAssetMenu(menuName = "AR Interior/Furniture Catalog", fileName = "FurnitureCatalog")]
    public sealed class FurnitureCatalog : ScriptableObject
    {
        [SerializeField] List<FurnitureDefinition> m_Items = new List<FurnitureDefinition>();

        public IReadOnlyList<FurnitureDefinition> Items => m_Items;

        public void SetItems(IEnumerable<FurnitureDefinition> items)
        {
            m_Items.Clear();
            m_Items.AddRange(items);
        }

        public FurnitureDefinition FindById(string id)
        {
            foreach (var item in m_Items)
            {
                if (item != null && item.Id == id)
                    return item;
            }

            return null;
        }

        /// <summary>Collects every configuration problem (null entries, duplicate ids, missing prefabs).</summary>
        public List<string> Validate()
        {
            var problems = new List<string>();
            var ids = new HashSet<string>();
            for (var i = 0; i < m_Items.Count; i++)
            {
                var item = m_Items[i];
                if (item == null)
                {
                    problems.Add($"Catalogue entry {i} is empty");
                    continue;
                }

                if (!item.IsValid(out var problem))
                    problems.Add(problem);

                if (!ids.Add(item.Id))
                    problems.Add($"Duplicate furniture id '{item.Id}'");
            }

            return problems;
        }
    }
}
