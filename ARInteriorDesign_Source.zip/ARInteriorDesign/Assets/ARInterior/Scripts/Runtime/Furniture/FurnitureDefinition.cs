using UnityEngine;

namespace ARInterior.Furniture
{
    /// <summary>Catalogue entry: everything the UI and placement logic need to know about one furniture model.</summary>
    [CreateAssetMenu(menuName = "AR Interior/Furniture Definition", fileName = "FurnitureDefinition")]
    public sealed class FurnitureDefinition : ScriptableObject
    {
        [SerializeField] string m_Id = string.Empty;
        [SerializeField] string m_DisplayName = string.Empty;
        [SerializeField, TextArea] string m_Description = string.Empty;
        [SerializeField] PlacedFurniture m_Prefab;
        [SerializeField] Sprite m_Thumbnail;
        [Tooltip("Nominal width (X), height (Y) and depth (Z) in metres at scale 1.")]
        [SerializeField] Vector3 m_Dimensions = Vector3.one;

        public string Id => m_Id;
        public string DisplayName => m_DisplayName;
        public string Description => m_Description;
        public PlacedFurniture Prefab => m_Prefab;
        public Sprite Thumbnail => m_Thumbnail;
        public Vector3 Dimensions => m_Dimensions;

        public string DimensionsLabel =>
            $"{m_Dimensions.x:0.00} × {m_Dimensions.z:0.00} × {m_Dimensions.y:0.00} m";

        /// <summary>Authoring entry point used by the setup wizard.</summary>
        public void Configure(string id, string displayName, string description, PlacedFurniture prefab,
            Sprite thumbnail, Vector3 dimensions)
        {
            m_Id = id;
            m_DisplayName = displayName;
            m_Description = description;
            m_Prefab = prefab;
            m_Thumbnail = thumbnail;
            m_Dimensions = dimensions;
        }

        public bool IsValid(out string problem)
        {
            if (string.IsNullOrWhiteSpace(m_Id))
            {
                problem = $"{name}: missing id";
                return false;
            }

            if (string.IsNullOrWhiteSpace(m_DisplayName))
            {
                problem = $"{m_Id}: missing display name";
                return false;
            }

            if (m_Prefab == null)
            {
                problem = $"{m_Id}: prefab is not assigned";
                return false;
            }

            if (m_Dimensions.x <= 0f || m_Dimensions.y <= 0f || m_Dimensions.z <= 0f)
            {
                problem = $"{m_Id}: dimensions must be positive";
                return false;
            }

            problem = null;
            return true;
        }
    }
}
