using UnityEngine;

namespace ARInterior.UI
{
    /// <summary>Keeps the HUD inside the device safe area (notches, rounded corners, gesture bars).</summary>
    [RequireComponent(typeof(RectTransform))]
    public sealed class SafeAreaFitter : MonoBehaviour
    {
        RectTransform m_RectTransform;
        Rect m_AppliedSafeArea;
        Vector2Int m_AppliedScreenSize;

        void Awake()
        {
            m_RectTransform = (RectTransform)transform;
            Apply();
        }

        void Update()
        {
            if (Screen.safeArea != m_AppliedSafeArea || Screen.width != m_AppliedScreenSize.x ||
                Screen.height != m_AppliedScreenSize.y)
            {
                Apply();
            }
        }

        void Apply()
        {
            var safeArea = Screen.safeArea;
            m_AppliedSafeArea = safeArea;
            m_AppliedScreenSize = new Vector2Int(Screen.width, Screen.height);
            if (Screen.width <= 0 || Screen.height <= 0)
                return;

            var min = safeArea.position;
            var max = safeArea.position + safeArea.size;
            min.x /= Screen.width;
            min.y /= Screen.height;
            max.x /= Screen.width;
            max.y /= Screen.height;
            m_RectTransform.anchorMin = min;
            m_RectTransform.anchorMax = max;
            m_RectTransform.offsetMin = Vector2.zero;
            m_RectTransform.offsetMax = Vector2.zero;
        }
    }
}
