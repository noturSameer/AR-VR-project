using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ARInterior.UI
{
    /// <summary>Visual state (active / idle / disabled) for a HUD button with an optional icon and label.</summary>
    public sealed class HudButton : MonoBehaviour
    {
        [SerializeField] Button m_Button;
        [SerializeField] Image m_Background;
        [SerializeField] Image m_Icon;
        [SerializeField] TMP_Text m_Label;
        [SerializeField] Color m_IdleColor = new Color(1f, 1f, 1f, 0.1f);
        [SerializeField] Color m_ActiveColor = new Color32(0xFF, 0xB0, 0x00, 0xFF);
        [SerializeField] Color m_IdleContentColor = Color.white;
        [SerializeField] Color m_ActiveContentColor = new Color32(0x1B, 0x1D, 0x22, 0xFF);

        bool m_Active;

        public Button Button => m_Button;
        public TMP_Text Label => m_Label;
        public bool IsActive => m_Active;

        public void Configure(Button button, Image background, Image icon, TMP_Text label, Color idleColor,
            Color activeColor, Color idleContentColor, Color activeContentColor)
        {
            m_Button = button;
            m_Background = background;
            m_Icon = icon;
            m_Label = label;
            m_IdleColor = idleColor;
            m_ActiveColor = activeColor;
            m_IdleContentColor = idleContentColor;
            m_ActiveContentColor = activeContentColor;
            Apply();
        }

        void Awake() => Apply();

        public void SetActive(bool active)
        {
            if (active == m_Active)
                return;
            m_Active = active;
            Apply();
        }

        public void SetInteractable(bool interactable)
        {
            if (m_Button == null || m_Button.interactable == interactable)
                return;
            m_Button.interactable = interactable;
            Apply();
        }

        public void SetLabel(string text)
        {
            if (m_Label != null)
                m_Label.text = text;
        }

        void Apply()
        {
            var interactable = m_Button == null || m_Button.interactable;
            var content = m_Active ? m_ActiveContentColor : m_IdleContentColor;
            if (!interactable)
                content.a *= 0.35f;
            if (m_Background != null)
                m_Background.color = m_Active ? m_ActiveColor : m_IdleColor;
            if (m_Icon != null)
                m_Icon.color = content;
            if (m_Label != null)
                m_Label.color = content;
        }
    }
}
