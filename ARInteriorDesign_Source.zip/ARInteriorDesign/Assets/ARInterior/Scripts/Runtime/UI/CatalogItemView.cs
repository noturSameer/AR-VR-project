using ARInterior.Furniture;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace ARInterior.UI
{
    /// <summary>One card in the furniture catalogue bar.</summary>
    public sealed class CatalogItemView : MonoBehaviour
    {
        [SerializeField] FurnitureDefinition m_Definition;
        [SerializeField] Button m_Button;
        [SerializeField] Image m_Background;
        [SerializeField] Image m_Thumbnail;
        [SerializeField] TMP_Text m_NameLabel;
        [SerializeField] TMP_Text m_DimensionsLabel;
        [SerializeField] Color m_IdleColor = new Color(1f, 1f, 1f, 0.12f);
        [SerializeField] Color m_ArmedColor = new Color32(0xFF, 0xB0, 0x00, 0xFF);
        [SerializeField] Color m_IdleTextColor = Color.white;
        [SerializeField] Color m_ArmedTextColor = new Color32(0x1B, 0x1D, 0x22, 0xFF);

        public FurnitureDefinition Definition => m_Definition;
        public Button Button => m_Button;

        public void Configure(FurnitureDefinition definition, Button button, Image background, Image thumbnail,
            TMP_Text nameLabel, TMP_Text dimensionsLabel)
        {
            m_Definition = definition;
            m_Button = button;
            m_Background = background;
            m_Thumbnail = thumbnail;
            m_NameLabel = nameLabel;
            m_DimensionsLabel = dimensionsLabel;
            Refresh();
        }

        void Awake() => Refresh();

        void Refresh()
        {
            if (m_Definition == null)
                return;
            if (m_NameLabel != null)
                m_NameLabel.text = m_Definition.DisplayName;
            if (m_DimensionsLabel != null)
                m_DimensionsLabel.text = m_Definition.DimensionsLabel;
            if (m_Thumbnail != null && m_Definition.Thumbnail != null)
                m_Thumbnail.sprite = m_Definition.Thumbnail;
            SetArmed(false);
        }

        public void SetArmed(bool armed)
        {
            if (m_Background != null)
                m_Background.color = armed ? m_ArmedColor : m_IdleColor;
            if (m_NameLabel != null)
                m_NameLabel.color = armed ? m_ArmedTextColor : m_IdleTextColor;
            if (m_DimensionsLabel != null)
            {
                var c = armed ? m_ArmedTextColor : m_IdleTextColor;
                c.a = 0.75f;
                m_DimensionsLabel.color = c;
            }
        }
    }
}
