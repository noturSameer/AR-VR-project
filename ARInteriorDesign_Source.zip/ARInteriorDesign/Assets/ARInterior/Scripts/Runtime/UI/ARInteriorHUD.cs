using System.Collections.Generic;
using ARInterior.Core;
using ARInterior.Furniture;
using ARInterior.Interaction;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace ARInterior.UI
{
    /// <summary>
    /// Binds the mobile HUD to the interaction systems. Every button is wired here at runtime and recorded
    /// in <see cref="BoundButtons"/> so automated tests can prove no control is decorative.
    /// </summary>
    public sealed class ARInteriorHUD : MonoBehaviour
    {
        static readonly Color k_Ready = new Color32(0x34, 0xC7, 0x59, 0xFF);
        static readonly Color k_Busy = new Color32(0xFF, 0xB0, 0x00, 0xFF);
        static readonly Color k_Limited = new Color32(0xFF, 0x8C, 0x00, 0xFF);
        static readonly Color k_Error = new Color32(0xFF, 0x45, 0x3A, 0xFF);

        [Header("Systems")]
        [SerializeField] InteractionController m_Interaction;

        [Header("Status")]
        [SerializeField] TMP_Text m_StatusLabel;
        [SerializeField] Image m_StatusDot;
        [SerializeField] TMP_Text m_SelectionLabel;
        [SerializeField] GameObject m_GuidancePanel;
        [SerializeField] TMP_Text m_GuidanceLabel;

        [Header("Tools")]
        [SerializeField] HudButton m_SelectTool;
        [SerializeField] HudButton m_MoveTool;
        [SerializeField] HudButton m_RotateTool;
        [SerializeField] HudButton m_ScaleTool;
        [SerializeField] HudButton m_DeleteTool;

        [Header("Tool options")]
        [SerializeField] GameObject m_MoveOptions;
        [Tooltip("Indexed by MoveConstraint: Surface, X, Y, Z.")]
        [SerializeField] HudButton[] m_MoveConstraintButtons = new HudButton[0];
        [SerializeField] GameObject m_RotateOptions;
        [Tooltip("Indexed by TransformAxis: X, Y, Z.")]
        [SerializeField] HudButton[] m_RotationAxisButtons = new HudButton[0];
        [SerializeField] HudButton m_SnapButton;
        [SerializeField] GameObject m_ScaleOptions;
        [SerializeField] TMP_Text m_ScaleLabel;
        [SerializeField] HudButton m_ResetScaleButton;

        [Header("Catalogue")]
        [SerializeField] CatalogItemView[] m_CatalogItems = new CatalogItemView[0];

        [Header("Scene switching")]
        [SerializeField] HudButton m_SwitchSceneButton;
        [SerializeField] string m_AlternateSceneName = string.Empty;

        readonly HashSet<Button> m_BoundButtons = new HashSet<Button>();
        SelectionManager m_Selection;
        PlacementController m_Placement;
        TransformController m_Transformer;
        ExperienceStatusProvider m_Status;
        bool m_IsValid;
        bool m_GuidanceShowsMessage;
        bool m_IsLoadingScene;

        /// <summary>Every button that received a runtime listener from this HUD.</summary>
        public IReadOnlyCollection<Button> BoundButtons => m_BoundButtons;

        public string AlternateSceneName => m_AlternateSceneName;

        void Awake()
        {
            if (m_Interaction == null)
            {
                Debug.LogError($"{nameof(ARInteriorHUD)} on '{name}' has no InteractionController.", this);
                return;
            }

            m_Selection = m_Interaction.Selection;
            m_Placement = m_Interaction.Placement;
            m_Transformer = m_Interaction.Transformer;
            m_Status = m_Interaction.StatusProvider;
            m_IsValid = m_Selection != null && m_Placement != null && m_Transformer != null && m_Status != null;
            if (!m_IsValid)
            {
                Debug.LogError($"{nameof(ARInteriorHUD)}: the InteractionController is not fully configured.", this);
                return;
            }

            BindButtons();
        }

        void OnEnable()
        {
            if (!m_IsValid)
                return;
            m_Status.StatusChanged += OnStatusChanged;
            m_Selection.SelectionChanged += OnSelectionChanged;
            m_Placement.ArmedItemChanged += OnArmedItemChanged;
            m_Placement.ItemPlaced += OnPlacedItemsChanged;
            m_Placement.ItemRemoved += OnPlacedItemsChanged;
            m_Interaction.ModeChanged += OnModeChanged;
            m_Interaction.SettingsChanged += RefreshTools;
            m_Interaction.MessageShown += OnMessageShown;
            m_Transformer.TransformChanged += OnTransformChanged;
            RefreshAll();
        }

        void OnDisable()
        {
            if (!m_IsValid)
                return;
            m_Status.StatusChanged -= OnStatusChanged;
            m_Selection.SelectionChanged -= OnSelectionChanged;
            m_Placement.ArmedItemChanged -= OnArmedItemChanged;
            m_Placement.ItemPlaced -= OnPlacedItemsChanged;
            m_Placement.ItemRemoved -= OnPlacedItemsChanged;
            m_Interaction.ModeChanged -= OnModeChanged;
            m_Interaction.SettingsChanged -= RefreshTools;
            m_Interaction.MessageShown -= OnMessageShown;
            m_Transformer.TransformChanged -= OnTransformChanged;
        }

        void OnDestroy()
        {
            foreach (var button in m_BoundButtons)
            {
                if (button != null)
                    button.onClick.RemoveAllListeners();
            }

            m_BoundButtons.Clear();
        }

        void Update()
        {
            // Only work done per frame: drop an expired feedback message from the banner.
            if (m_GuidanceShowsMessage && m_Interaction.ActiveMessage == null)
                RefreshGuidance();
        }

        // ------------------------------------------------------------------ binding

        void BindButtons()
        {
            Bind(m_SelectTool, () => m_Interaction.SetMode(InteractionMode.Select));
            Bind(m_MoveTool, () => m_Interaction.SetMode(InteractionMode.Move));
            Bind(m_RotateTool, () => m_Interaction.SetMode(InteractionMode.Rotate));
            Bind(m_ScaleTool, () => m_Interaction.SetMode(InteractionMode.Scale));
            Bind(m_DeleteTool, m_Interaction.DeleteSelected);

            for (var i = 0; i < m_MoveConstraintButtons.Length; i++)
            {
                var constraint = (MoveConstraint)i;
                Bind(m_MoveConstraintButtons[i], () => m_Interaction.SetMoveConstraint(constraint));
            }

            for (var i = 0; i < m_RotationAxisButtons.Length; i++)
            {
                var axis = (TransformAxis)i;
                Bind(m_RotationAxisButtons[i], () => m_Interaction.SetRotationAxis(axis));
            }

            Bind(m_SnapButton, () => m_Interaction.SetSnapRotation(!m_Interaction.SnapRotation));
            Bind(m_ResetScaleButton, m_Interaction.ResetSelectedScale);
            Bind(m_SwitchSceneButton, SwitchScene);

            foreach (var item in m_CatalogItems)
            {
                if (item == null || item.Button == null)
                    continue;
                var definition = item.Definition;
                item.Button.onClick.AddListener(() => OnCatalogItemClicked(definition));
                m_BoundButtons.Add(item.Button);
            }
        }

        void Bind(HudButton hudButton, UnityEngine.Events.UnityAction action)
        {
            if (hudButton == null || hudButton.Button == null)
            {
                Debug.LogWarning($"{nameof(ARInteriorHUD)}: a HUD button reference is missing.", this);
                return;
            }

            hudButton.Button.onClick.AddListener(action);
            m_BoundButtons.Add(hudButton.Button);
        }

        void OnCatalogItemClicked(FurnitureDefinition definition)
        {
            if (definition == null)
                return;
            m_Placement.Arm(definition);
            if (m_Placement.IsArmed && m_Selection.HasSelection)
                m_Selection.Deselect();
        }

        void SwitchScene()
        {
            if (m_IsLoadingScene)
                return;
            if (string.IsNullOrEmpty(m_AlternateSceneName) || !Application.CanStreamedLevelBeLoaded(m_AlternateSceneName))
            {
                m_Interaction.ShowMessage("The other scene is not included in this build");
                return;
            }

            m_IsLoadingScene = true;
            SceneManager.LoadSceneAsync(m_AlternateSceneName, LoadSceneMode.Single);
        }

        // ------------------------------------------------------------------ event handlers

        void OnStatusChanged(ExperienceStatus status)
        {
            RefreshStatus();
            RefreshGuidance();
        }

        void OnSelectionChanged(PlacedFurniture selected)
        {
            RefreshSelection();
            RefreshTools();
            RefreshGuidance();
        }

        void OnArmedItemChanged(FurnitureDefinition armed)
        {
            RefreshCatalog();
            RefreshGuidance();
        }

        void OnPlacedItemsChanged(PlacedFurniture item) => RefreshGuidance();

        void OnModeChanged(InteractionMode mode)
        {
            RefreshTools();
            RefreshGuidance();
        }

        void OnMessageShown(string message) => RefreshGuidance();

        void OnTransformChanged(PlacedFurniture item)
        {
            if (item == m_Selection.Selected)
                RefreshSelection();
        }

        // ------------------------------------------------------------------ refresh

        void RefreshAll()
        {
            RefreshStatus();
            RefreshSelection();
            RefreshTools();
            RefreshCatalog();
            RefreshGuidance();
        }

        void RefreshStatus()
        {
            var status = m_Status.Current;
            if (m_StatusLabel != null)
                m_StatusLabel.text = status.Headline;
            if (m_StatusDot != null)
                m_StatusDot.color = StatusColor(status.State);
            if (m_SwitchSceneButton != null)
                m_SwitchSceneButton.SetActive(status.State == ExperienceState.Unsupported);
        }

        void RefreshSelection()
        {
            var selected = m_Selection.Selected;
            var scaleText = selected != null ? $"{selected.UniformScale * 100f:0}%" : "—";
            if (m_SelectionLabel != null)
                m_SelectionLabel.text = selected != null
                    ? $"Selected: {selected.DisplayName} · {scaleText}"
                    : "Nothing selected";
            if (m_ScaleLabel != null)
                m_ScaleLabel.text = $"Size {scaleText}";
        }

        void RefreshTools()
        {
            var mode = m_Interaction.Mode;
            m_SelectTool?.SetActive(mode == InteractionMode.Select);
            m_MoveTool?.SetActive(mode == InteractionMode.Move);
            m_RotateTool?.SetActive(mode == InteractionMode.Rotate);
            m_ScaleTool?.SetActive(mode == InteractionMode.Scale);

            var hasSelection = m_Selection.HasSelection;
            m_DeleteTool?.SetInteractable(hasSelection);
            m_ResetScaleButton?.SetInteractable(hasSelection);

            if (m_MoveOptions != null)
                m_MoveOptions.SetActive(mode == InteractionMode.Move);
            if (m_RotateOptions != null)
                m_RotateOptions.SetActive(mode == InteractionMode.Rotate);
            if (m_ScaleOptions != null)
                m_ScaleOptions.SetActive(mode == InteractionMode.Scale);

            for (var i = 0; i < m_MoveConstraintButtons.Length; i++)
                m_MoveConstraintButtons[i]?.SetActive((int)m_Interaction.MoveConstraint == i);
            for (var i = 0; i < m_RotationAxisButtons.Length; i++)
                m_RotationAxisButtons[i]?.SetActive((int)m_Interaction.RotationAxis == i);

            if (m_SnapButton != null)
            {
                var snap = m_Interaction.SnapRotation;
                m_SnapButton.SetActive(snap);
                m_SnapButton.SetLabel(snap ? "Snap 15° On" : "Snap 15° Off");
            }
        }

        void RefreshCatalog()
        {
            var armed = m_Placement.ArmedItem;
            foreach (var item in m_CatalogItems)
            {
                if (item != null)
                    item.SetArmed(armed != null && item.Definition == armed);
            }
        }

        void RefreshGuidance()
        {
            var message = m_Interaction.ActiveMessage;
            m_GuidanceShowsMessage = message != null;
            var text = GuidanceComposer.Compose(m_Status.Current, m_Placement.ArmedItem?.DisplayName,
                m_Selection.HasSelection, m_Placement.PlacedCount, m_Interaction.Mode, message);
            if (m_GuidanceLabel != null)
                m_GuidanceLabel.text = text;
            if (m_GuidancePanel != null)
                m_GuidancePanel.SetActive(!string.IsNullOrEmpty(text));
        }

        static Color StatusColor(ExperienceState state)
        {
            switch (state)
            {
                case ExperienceState.Ready:
                case ExperienceState.Demo:
                    return k_Ready;
                case ExperienceState.TrackingLimited:
                    return k_Limited;
                case ExperienceState.Unsupported:
                    return k_Error;
                default:
                    return k_Busy;
            }
        }
    }
}
