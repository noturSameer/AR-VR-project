using System;
using System.Collections.Generic;
using ARInterior.Furniture;
using ARInterior.Interaction;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

namespace ARInterior.AR
{
    /// <summary>
    /// AR-mode surfaces: raycasts against detected horizontal planes and keeps each placed item on
    /// exactly one anchor. An anchor is created when an item is placed and replaced only when a move
    /// finishes, so anchors never accumulate.
    /// </summary>
    public sealed class ARPlaneSurfaceProvider : SurfaceProvider
    {
        [SerializeField] ARRaycastManager m_RaycastManager;
        [SerializeField] ARPlaneManager m_PlaneManager;
        [SerializeField] ARAnchorManager m_AnchorManager;
        [Tooltip("Attach placed furniture to AR anchors for stability. Disable to keep items in session space.")]
        [SerializeField] bool m_UseAnchors = true;

        static readonly List<ARRaycastHit> s_Hits = new List<ARRaycastHit>();

        readonly Dictionary<PlacedFurniture, ARAnchor> m_Anchors = new Dictionary<PlacedFurniture, ARAnchor>();
        readonly Dictionary<PlacedFurniture, int> m_RequestVersions = new Dictionary<PlacedFurniture, int>();

        public override bool HasSurfaces => m_PlaneManager != null && m_PlaneManager.trackables.count > 0;
        public int AnchorCount => m_Anchors.Count;

        public void Configure(ARRaycastManager raycastManager, ARPlaneManager planeManager, ARAnchorManager anchorManager)
        {
            m_RaycastManager = raycastManager;
            m_PlaneManager = planeManager;
            m_AnchorManager = anchorManager;
        }

        void Awake()
        {
            if (m_RaycastManager == null || m_PlaneManager == null)
                Debug.LogError($"{nameof(ARPlaneSurfaceProvider)} on '{name}' needs an ARRaycastManager and an ARPlaneManager.", this);
        }

        public override bool TryRaycast(Vector2 screenPosition, out SurfaceHit hit)
        {
            hit = default;
            if (m_RaycastManager == null || !m_RaycastManager.isActiveAndEnabled || m_RaycastManager.subsystem == null)
                return false;

            if (!m_RaycastManager.Raycast(screenPosition, s_Hits, TrackableType.PlaneWithinPolygon))
                return false;

            foreach (var candidate in s_Hits)
            {
                var plane = candidate.trackable as ARPlane;
                // Furniture stands on floors and table tops only.
                if (plane != null && plane.alignment != PlaneAlignment.HorizontalUp)
                    continue;
                hit = new SurfaceHit(candidate.pose, plane, candidate.distance);
                return true;
            }

            return false;
        }

        public override void AttachToSurface(PlacedFurniture item, Component surface)
        {
            if (item == null || item.IsBeingDestroyed)
                return;

            DetachAnchor(item);
            if (!CanUseAnchors)
                return;

            if (surface is ARPlane plane && plane.trackingState != TrackingState.None)
            {
                var pose = new Pose(item.transform.position, item.transform.rotation);
                var anchor = m_AnchorManager.AttachAnchor(plane, pose);
                if (anchor != null)
                {
                    Adopt(item, anchor);
                    return;
                }
            }

            RequestWorldAnchor(item);
        }

        public override void AttachInPlace(PlacedFurniture item)
        {
            if (item == null || item.IsBeingDestroyed)
                return;
            DetachAnchor(item);
            if (CanUseAnchors)
                RequestWorldAnchor(item);
        }

        public override void Release(PlacedFurniture item)
        {
            DetachAnchor(item);
            m_RequestVersions.Remove(item);
        }

        bool CanUseAnchors =>
            m_UseAnchors && m_AnchorManager != null && m_AnchorManager.isActiveAndEnabled &&
            m_AnchorManager.subsystem != null;

        void Adopt(PlacedFurniture item, ARAnchor anchor)
        {
            item.transform.SetParent(anchor.transform, true);
            m_Anchors[item] = anchor;
        }

        /// <summary>Moves the item back under the placed-objects root and removes its anchor, if any.</summary>
        void DetachAnchor(PlacedFurniture item)
        {
            // Invalidate any anchor request that is still in flight for this item.
            m_RequestVersions.TryGetValue(item, out var version);
            m_RequestVersions[item] = version + 1;

            if (item != null)
                ParentToRoot(item);

            if (!m_Anchors.TryGetValue(item, out var anchor))
                return;
            m_Anchors.Remove(item);
            RemoveAnchor(anchor);
        }

        void RemoveAnchor(ARAnchor anchor)
        {
            if (anchor == null)
                return;
            if (CanUseAnchors && m_AnchorManager.TryRemoveAnchor(anchor))
                return;
            Destroy(anchor.gameObject);
        }

        async void RequestWorldAnchor(PlacedFurniture item)
        {
            m_RequestVersions.TryGetValue(item, out var version);
            var pose = new Pose(item.transform.position, item.transform.rotation);
            try
            {
                var result = await m_AnchorManager.TryAddAnchorAsync(pose);
                if (!result.status.IsSuccess() || result.value == null)
                {
                    Debug.LogWarning($"Could not create an AR anchor for '{(item != null ? item.name : "item")}' ({result.status}). It stays in session space.", this);
                    return;
                }

                var anchor = result.value;
                var stillWanted = this != null && item != null && !item.IsBeingDestroyed &&
                                  m_RequestVersions.TryGetValue(item, out var current) && current == version &&
                                  !m_Anchors.ContainsKey(item);
                if (!stillWanted)
                {
                    RemoveAnchor(anchor);
                    return;
                }

                Adopt(item, anchor);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception, this);
            }
        }

        void OnDestroy()
        {
            m_Anchors.Clear();
            m_RequestVersions.Clear();
        }
    }
}
