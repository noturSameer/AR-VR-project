using System.Collections;
using ARInterior.Core;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

namespace ARInterior.AR
{
    /// <summary>
    /// Translates the AR session state, the not-tracking reason and the number of detected planes into
    /// the status pill text and scanning guidance. Polls at a low rate because the not-tracking reason
    /// has no change event.
    /// </summary>
    public sealed class ARSessionStatusProvider : ExperienceStatusProvider
    {
        [SerializeField] ARPlaneManager m_PlaneManager;
        [SerializeField, Range(0.05f, 2f)] float m_PollInterval = 0.25f;

        float m_NextPoll;
        bool m_HasTrackedBefore;

        public override bool IsDemo => false;

        public void Configure(ARPlaneManager planeManager) => m_PlaneManager = planeManager;

        void OnEnable()
        {
            ARSession.stateChanged += OnSessionStateChanged;
            if (m_PlaneManager != null)
                m_PlaneManager.trackablesChanged.AddListener(OnPlanesChanged);
            Evaluate();
        }

        IEnumerator Start()
        {
            // ARSession only checks availability when an XR subsystem exists. Without one (Editor, devices
            // without ARCore) the state would stay None forever, so trigger the check explicitly; it resolves
            // to Unsupported and the HUD can offer the demo scene.
            if (ARSession.state == ARSessionState.None)
                yield return ARSession.CheckAvailability();
            Evaluate();
        }

        void OnDisable()
        {
            ARSession.stateChanged -= OnSessionStateChanged;
            if (m_PlaneManager != null)
                m_PlaneManager.trackablesChanged.RemoveListener(OnPlanesChanged);
        }

        void Update()
        {
            if (Time.unscaledTime < m_NextPoll)
                return;
            m_NextPoll = Time.unscaledTime + m_PollInterval;
            Evaluate();
        }

        void OnSessionStateChanged(ARSessionStateChangedEventArgs args) => Evaluate();

        void OnPlanesChanged(ARTrackablesChangedEventArgs<ARPlane> args) => Evaluate();

        void Evaluate()
        {
            var state = ARSession.state;
            if (state == ARSessionState.SessionTracking)
                m_HasTrackedBefore = true;
            var planes = m_PlaneManager != null ? m_PlaneManager.trackables.count : 0;
            Publish(Describe(state, ARSession.notTrackingReason, planes, m_HasTrackedBefore));
        }

        /// <summary>Pure mapping from AR Foundation state to user-facing status (unit tested).</summary>
        public static ExperienceStatus Describe(ARSessionState state, NotTrackingReason reason, int planeCount,
            bool hasTrackedBefore)
        {
            switch (state)
            {
                case ARSessionState.None:
                case ARSessionState.CheckingAvailability:
                    return new ExperienceStatus(ExperienceState.Initializing, "Checking AR support…",
                        "Starting the camera, please wait", planeCount);
                case ARSessionState.Unsupported:
                    return new ExperienceStatus(ExperienceState.Unsupported, "AR not supported",
                        "This device cannot run ARCore. Tap “Demo” to try the furniture tools in a virtual room.",
                        planeCount);
                case ARSessionState.NeedsInstall:
                case ARSessionState.Installing:
                    return new ExperienceStatus(ExperienceState.Installing, "Installing AR services…",
                        "Google Play Services for AR is being installed or updated", planeCount);
                case ARSessionState.Ready:
                case ARSessionState.SessionInitializing:
                    if (hasTrackedBefore)
                        return new ExperienceStatus(ExperienceState.TrackingLimited, "Tracking lost",
                            DescribeReason(reason, true), planeCount);
                    return new ExperienceStatus(ExperienceState.Scanning, "Initialising tracking…",
                        DescribeReason(reason, false), planeCount);
                case ARSessionState.SessionTracking:
                    if (planeCount == 0)
                        return new ExperienceStatus(ExperienceState.Scanning, "Scanning for surfaces",
                            "Point the camera at the floor and move the phone slowly from side to side",
                            planeCount);
                    return new ExperienceStatus(ExperienceState.Ready,
                        planeCount == 1 ? "Tracking · 1 surface" : $"Tracking · {planeCount} surfaces",
                        string.Empty, planeCount);
                default:
                    return new ExperienceStatus(ExperienceState.Initializing, "Starting AR…", string.Empty, planeCount);
            }
        }

        static string DescribeReason(NotTrackingReason reason, bool lost)
        {
            switch (reason)
            {
                case NotTrackingReason.InsufficientLight:
                    return "Too dark — turn on more lights";
                case NotTrackingReason.InsufficientFeatures:
                    return "Point at textured surfaces such as a rug, a table or a patterned floor";
                case NotTrackingReason.ExcessiveMotion:
                    return "Moving too fast — move the phone more slowly";
                case NotTrackingReason.Relocalizing:
                    return "Restoring tracking — point back at the area you scanned";
                case NotTrackingReason.CameraUnavailable:
                    return "Camera unavailable — close other apps that use the camera";
                case NotTrackingReason.Unsupported:
                    return "Tracking is not supported on this device";
                default:
                    return lost
                        ? "Hold still and point back at the scanned area; your furniture is kept"
                        : "Move your phone slowly to scan the room";
            }
        }
    }
}
