using ARInterior.Core;
using ARInterior.Furniture;
using UnityEngine;

namespace ARInterior.Rendering
{
    /// <summary>
    /// X/Y/Z move handles that follow the selected object in Move mode. The gizmo never changes the
    /// furniture itself: it only reports which axis was grabbed, and the interaction controller performs
    /// the move through the TransformController lock.
    /// </summary>
    public sealed class AxisGizmo : MonoBehaviour
    {
        [SerializeField] Camera m_Camera;
        [SerializeField] AxisHandle[] m_Handles = new AxisHandle[0];
        [SerializeField] LayerMask m_HandleMask;
        [Tooltip("Gizmo size as a fraction of the camera distance, so it keeps a constant on-screen size.")]
        [SerializeField, Range(0.02f, 0.5f)] float m_ScreenScale = 0.16f;
        [SerializeField, Min(0.05f)] float m_MinWorldSize = 0.25f;
        [SerializeField, Min(1f)] float m_MaxPickDistance = 60f;

        PlacedFurniture m_Target;

        public PlacedFurniture Target => m_Target;
        public bool IsVisible => m_Target != null && gameObject.activeSelf;
        public AxisHandle[] Handles => m_Handles;

        public void Configure(Camera viewCamera, AxisHandle[] handles, LayerMask handleMask)
        {
            m_Camera = viewCamera;
            m_Handles = handles;
            m_HandleMask = handleMask;
        }

        public void Show(PlacedFurniture target)
        {
            if (target == null || target.IsBeingDestroyed)
            {
                Hide();
                return;
            }

            m_Target = target;
            if (!gameObject.activeSelf)
                gameObject.SetActive(true);
            Follow();
        }

        public void Hide()
        {
            m_Target = null;
            Highlight(null);
            if (gameObject.activeSelf)
                gameObject.SetActive(false);
        }

        public void Highlight(TransformAxis? axis)
        {
            foreach (var handle in m_Handles)
            {
                if (handle != null)
                    handle.SetHighlighted(axis.HasValue && handle.Axis == axis.Value);
            }
        }

        public bool TryPickHandle(Vector2 screenPosition, out TransformAxis axis)
        {
            axis = TransformAxis.Y;
            if (!IsVisible || m_Camera == null)
                return false;

            Follow();
            Physics.SyncTransforms();
            var ray = m_Camera.ScreenPointToRay(screenPosition);
            if (!Physics.Raycast(ray, out var hit, m_MaxPickDistance, m_HandleMask, QueryTriggerInteraction.Collide))
                return false;

            var handle = hit.collider.GetComponentInParent<AxisHandle>();
            if (handle == null)
                return false;
            axis = handle.Axis;
            return true;
        }

        void LateUpdate()
        {
            if (m_Target == null || m_Target.IsBeingDestroyed)
            {
                Hide();
                return;
            }

            Follow();
        }

        void Follow()
        {
            if (m_Target == null)
                return;

            var targetTransform = m_Target.transform;
            var bounds = m_Target.CalculateWorldBounds();
            var position = new Vector3(targetTransform.position.x, bounds.center.y, targetTransform.position.z);
            transform.SetPositionAndRotation(position, targetTransform.rotation);

            var size = m_MinWorldSize;
            if (m_Camera != null)
                size = Mathf.Max(m_MinWorldSize, Vector3.Distance(m_Camera.transform.position, position) * m_ScreenScale);
            transform.localScale = Vector3.one * size;
        }
    }
}
