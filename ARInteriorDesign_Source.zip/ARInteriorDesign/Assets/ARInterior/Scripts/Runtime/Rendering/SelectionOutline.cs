using System;
using System.Collections.Generic;
using ARInterior.Furniture;
using UnityEngine;

namespace ARInterior.Rendering
{
    /// <summary>
    /// Runtime selection outline that works in URP on Android (not an Editor gizmo).
    /// Two extra materials are appended to every renderer of the selected object:
    /// a stencil mask (opaque queue) that marks the object's silhouette, and an inverted-hull outline
    /// (transparent queue) that is extruded in screen space and only drawn outside the marked silhouette.
    /// The original material arrays are restored on deselection; no per-frame work is done.
    /// </summary>
    public sealed class SelectionOutline : MonoBehaviour
    {
        /// <summary>#FFB000 — the yellow-orange selection colour required by the specification.</summary>
        public static readonly Color DefaultColor = new Color32(0xFF, 0xB0, 0x00, 0xFF);

        static readonly int k_OutlineColorId = Shader.PropertyToID("_OutlineColor");
        static readonly int k_OutlineWidthId = Shader.PropertyToID("_OutlineWidth");

        [SerializeField] Material m_OutlineMaterial;
        [SerializeField] Material m_MaskMaterial;
        [SerializeField] Color m_Color = DefaultColor;
        [SerializeField, Range(1f, 16f)] float m_WidthPixels = 5f;

        readonly Dictionary<Renderer, Material[]> m_OriginalMaterials = new Dictionary<Renderer, Material[]>();
        Material m_OutlineInstance;
        Material m_MaskInstance;
        PlacedFurniture m_Current;

        public PlacedFurniture Current => m_Current;
        public Color Color => m_Color;
        public float WidthPixels => m_WidthPixels;
        public Material OutlineMaterialInstance => m_OutlineInstance;
        public Material MaskMaterialInstance => m_MaskInstance;

        public void Configure(Material outlineMaterial, Material maskMaterial, Color color, float widthPixels)
        {
            m_OutlineMaterial = outlineMaterial;
            m_MaskMaterial = maskMaterial;
            m_Color = color;
            m_WidthPixels = widthPixels;
        }

        void Awake()
        {
            EnsureMaterials();
        }

        bool EnsureMaterials()
        {
            if (m_OutlineInstance != null && m_MaskInstance != null)
                return true;

            if (m_OutlineMaterial == null || m_MaskMaterial == null)
            {
                Debug.LogError($"{nameof(SelectionOutline)} on '{name}' is missing its outline or mask material.", this);
                return false;
            }

            // Runtime copies so colour/width changes never modify the material assets.
            m_OutlineInstance = new Material(m_OutlineMaterial) { name = m_OutlineMaterial.name + " (Runtime)" };
            m_MaskInstance = new Material(m_MaskMaterial) { name = m_MaskMaterial.name + " (Runtime)" };
            ApplyMaterialProperties();
            return true;
        }

        void ApplyMaterialProperties()
        {
            if (m_OutlineInstance == null)
                return;
            m_OutlineInstance.SetColor(k_OutlineColorId, m_Color);
            m_OutlineInstance.SetFloat(k_OutlineWidthId, m_WidthPixels);
        }

        public void SetColor(Color color)
        {
            m_Color = color;
            ApplyMaterialProperties();
        }

        public void Show(PlacedFurniture item)
        {
            Clear();
            if (item == null || item.IsBeingDestroyed || !EnsureMaterials())
                return;

            foreach (var r in item.Renderers)
            {
                if (r == null || m_OriginalMaterials.ContainsKey(r))
                    continue;
                var original = r.sharedMaterials;
                var combined = new Material[original.Length + 2];
                Array.Copy(original, combined, original.Length);
                combined[original.Length] = m_MaskInstance;
                combined[original.Length + 1] = m_OutlineInstance;
                m_OriginalMaterials.Add(r, original);
                r.sharedMaterials = combined;
            }

            m_Current = item;
        }

        public void Clear()
        {
            foreach (var pair in m_OriginalMaterials)
            {
                if (pair.Key != null)
                    pair.Key.sharedMaterials = pair.Value;
            }

            m_OriginalMaterials.Clear();
            m_Current = null;
        }

        /// <summary>True while <paramref name="r"/> renders with the outline appended.</summary>
        public bool IsOutlined(Renderer r) => r != null && m_OriginalMaterials.ContainsKey(r);

        void OnDestroy()
        {
            Clear();
            if (m_OutlineInstance != null)
                Destroy(m_OutlineInstance);
            if (m_MaskInstance != null)
                Destroy(m_MaskInstance);
        }
    }
}
