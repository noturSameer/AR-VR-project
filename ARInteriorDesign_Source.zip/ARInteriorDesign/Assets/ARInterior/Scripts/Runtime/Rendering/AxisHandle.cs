using ARInterior.Core;
using UnityEngine;

namespace ARInterior.Rendering
{
    /// <summary>One draggable arrow of the move gizmo. The collider is a trigger on the gizmo layer.</summary>
    public sealed class AxisHandle : MonoBehaviour
    {
        static readonly int k_ColorId = Shader.PropertyToID("_Color");

        [SerializeField] TransformAxis m_Axis;
        [SerializeField] Renderer m_Renderer;
        [SerializeField] Color m_Color = Color.white;
        [SerializeField] Color m_HighlightColor = new Color32(0xFF, 0xB0, 0x00, 0xFF);

        MaterialPropertyBlock m_Block;
        bool m_Highlighted;
        bool m_Initialised;

        public TransformAxis Axis => m_Axis;
        public bool IsHighlighted => m_Highlighted;

        public void Configure(TransformAxis axis, Renderer handleRenderer, Color color, Color highlightColor)
        {
            m_Axis = axis;
            m_Renderer = handleRenderer;
            m_Color = color;
            m_HighlightColor = highlightColor;
        }

        void Awake()
        {
            ApplyColor();
        }

        public void SetHighlighted(bool highlighted)
        {
            if (m_Initialised && highlighted == m_Highlighted)
                return;
            m_Highlighted = highlighted;
            ApplyColor();
        }

        void ApplyColor()
        {
            if (m_Renderer == null)
                return;
            m_Block ??= new MaterialPropertyBlock();
            m_Renderer.GetPropertyBlock(m_Block);
            m_Block.SetColor(k_ColorId, m_Highlighted ? m_HighlightColor : m_Color);
            m_Renderer.SetPropertyBlock(m_Block);
            m_Initialised = true;
        }
    }
}
