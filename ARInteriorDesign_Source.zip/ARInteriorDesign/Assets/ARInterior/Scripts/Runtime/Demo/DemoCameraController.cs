using UnityEngine;
using UnityEngine.InputSystem;

namespace ARInterior.Demo
{
    /// <summary>
    /// Orbit camera for the demo room: right mouse button drag orbits, the scroll wheel zooms.
    /// The left button is reserved for the same tap/drag tools as touch input.
    /// </summary>
    public sealed class DemoCameraController : MonoBehaviour
    {
        [SerializeField] Vector3 m_Target = new Vector3(0f, 0.6f, 0f);
        [SerializeField] float m_Distance = 5f;
        [SerializeField] float m_Yaw = 200f;
        [SerializeField] float m_Pitch = 35f;
        [SerializeField] Vector2 m_DistanceLimits = new Vector2(1.5f, 10f);
        [SerializeField] Vector2 m_PitchLimits = new Vector2(10f, 80f);
        [SerializeField, Min(0.01f)] float m_OrbitSensitivity = 0.25f;

        void Start() => Apply();

        void Update()
        {
            var mouse = Mouse.current;
            if (mouse == null)
                return;

            var changed = false;
            if (mouse.rightButton.isPressed)
            {
                var delta = mouse.delta.ReadValue();
                if (delta.sqrMagnitude > 0f)
                {
                    m_Yaw += delta.x * m_OrbitSensitivity;
                    m_Pitch = Mathf.Clamp(m_Pitch - delta.y * m_OrbitSensitivity, m_PitchLimits.x, m_PitchLimits.y);
                    changed = true;
                }
            }

            var scroll = mouse.scroll.ReadValue().y;
            if (Mathf.Abs(scroll) > 0.01f)
            {
                m_Distance = Mathf.Clamp(m_Distance * (scroll > 0f ? 0.9f : 1.1f), m_DistanceLimits.x, m_DistanceLimits.y);
                changed = true;
            }

            if (changed)
                Apply();
        }

        void Apply()
        {
            var rotation = Quaternion.Euler(m_Pitch, m_Yaw, 0f);
            transform.SetPositionAndRotation(m_Target - rotation * Vector3.forward * m_Distance, rotation);
        }
    }
}
