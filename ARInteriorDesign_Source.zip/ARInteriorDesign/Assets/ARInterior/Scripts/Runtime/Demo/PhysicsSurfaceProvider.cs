using ARInterior.Interaction;
using UnityEngine;

namespace ARInterior.Demo
{
    /// <summary>Demo-mode surfaces: upward-facing colliders of the virtual room on the configured layers.</summary>
    public sealed class PhysicsSurfaceProvider : SurfaceProvider
    {
        [SerializeField] Camera m_Camera;
        [SerializeField] LayerMask m_SurfaceMask;
        [SerializeField, Min(1f)] float m_MaxDistance = 50f;
        [Tooltip("Minimum dot product between the hit normal and world up for a hit to count as floor.")]
        [SerializeField, Range(0f, 1f)] float m_MinUpDot = 0.7f;

        public override bool HasSurfaces => true;

        public void Configure(Camera viewCamera, LayerMask surfaceMask)
        {
            m_Camera = viewCamera;
            m_SurfaceMask = surfaceMask;
        }

        public override bool TryRaycast(Vector2 screenPosition, out SurfaceHit hit)
        {
            hit = default;
            if (m_Camera == null)
                return false;

            var ray = m_Camera.ScreenPointToRay(screenPosition);
            if (!Physics.Raycast(ray, out var physicsHit, m_MaxDistance, m_SurfaceMask, QueryTriggerInteraction.Ignore))
                return false;
            if (Vector3.Dot(physicsHit.normal, Vector3.up) < m_MinUpDot)
                return false;

            hit = new SurfaceHit(new Pose(physicsHit.point, Quaternion.identity), physicsHit.collider, physicsHit.distance);
            return true;
        }

        void Awake()
        {
            if (m_Camera == null)
                Debug.LogError($"{nameof(PhysicsSurfaceProvider)} on '{name}' has no camera assigned.", this);
        }
    }
}
