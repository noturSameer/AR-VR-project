using ARInterior.Core;

namespace ARInterior.Demo
{
    /// <summary>Status for the virtual demo room: always ready, no camera or AR services involved.</summary>
    public sealed class DemoStatusProvider : ExperienceStatusProvider
    {
        public override bool IsDemo => true;

        void OnEnable()
        {
            Publish(new ExperienceStatus(ExperienceState.Demo, "Demo mode · virtual room",
                "No camera needed — the virtual floor acts as the detected surface", 1));
        }
    }
}
