namespace ARInterior.Core
{
    /// <summary>
    /// Chooses the single most useful hint for the guidance banner. Pure logic so the priorities
    /// (tracking problems first, then placement, then tool tips) are unit-testable.
    /// </summary>
    public static class GuidanceComposer
    {
        public static string Compose(
            ExperienceStatus status,
            string armedItemName,
            bool hasSelection,
            int placedCount,
            InteractionMode mode,
            string transientMessage)
        {
            if (!status.AllowsInteraction)
                return string.IsNullOrEmpty(status.Guidance) ? status.Headline : status.Guidance;

            if (!string.IsNullOrEmpty(transientMessage))
                return transientMessage;

            if (!string.IsNullOrEmpty(armedItemName))
                return status.State == ExperienceState.Demo
                    ? $"Tap the floor to place the {armedItemName}"
                    : $"Tap a highlighted surface to place the {armedItemName}";

            if (placedCount == 0)
                return "Choose a piece of furniture from the catalogue below";

            if (!hasSelection)
                return "Tap a piece of furniture to select it";

            switch (mode)
            {
                case InteractionMode.Move:
                    return "Drag to slide it along the floor, or drag an axis arrow";
                case InteractionMode.Rotate:
                    return "Drag sideways to rotate around the chosen axis";
                case InteractionMode.Scale:
                    return "Drag up to enlarge, down to shrink (or pinch)";
                default:
                    return "Pick Move, Rotate or Scale, then drag";
            }
        }
    }
}
