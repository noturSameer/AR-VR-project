using System;
using UnityEngine;

namespace ARInterior.Core
{
    public enum ExperienceState
    {
        Initializing = 0,
        Unsupported = 1,
        Installing = 2,
        Scanning = 3,
        Ready = 4,
        TrackingLimited = 5,
        Demo = 6
    }

    /// <summary>Snapshot of the AR (or demo) session state shown in the status pill and guidance banner.</summary>
    public readonly struct ExperienceStatus : IEquatable<ExperienceStatus>
    {
        public ExperienceStatus(ExperienceState state, string headline, string guidance, int surfaceCount)
        {
            State = state;
            Headline = headline ?? string.Empty;
            Guidance = guidance ?? string.Empty;
            SurfaceCount = surfaceCount;
        }

        public ExperienceState State { get; }
        public string Headline { get; }
        public string Guidance { get; }
        public int SurfaceCount { get; }

        /// <summary>Scene interaction (placing, manipulating) is only allowed with stable tracking.</summary>
        public bool AllowsInteraction => State == ExperienceState.Ready || State == ExperienceState.Demo;

        public bool Equals(ExperienceStatus other) =>
            State == other.State && Headline == other.Headline && Guidance == other.Guidance &&
            SurfaceCount == other.SurfaceCount;

        public override bool Equals(object obj) => obj is ExperienceStatus other && Equals(other);

        public override int GetHashCode() => HashCode.Combine((int)State, Headline, Guidance, SurfaceCount);

        public override string ToString() => $"{State}: {Headline}";
    }

    /// <summary>
    /// Base class for the component that reports whether the experience is ready for interaction.
    /// The AR scene uses the AR session monitor, the demo scene a constant "demo" provider.
    /// </summary>
    public abstract class ExperienceStatusProvider : MonoBehaviour
    {
        ExperienceStatus m_Current = new ExperienceStatus(ExperienceState.Initializing, "Starting…", string.Empty, 0);
        bool m_HasPublished;

        public event Action<ExperienceStatus> StatusChanged;

        public ExperienceStatus Current => m_Current;

        /// <summary>True when the scene has an alternative mode the user can switch to (AR ↔ demo).</summary>
        public abstract bool IsDemo { get; }

        protected void Publish(ExperienceStatus status)
        {
            if (m_HasPublished && status.Equals(m_Current))
                return;
            m_HasPublished = true;
            m_Current = status;
            StatusChanged?.Invoke(status);
        }
    }
}
