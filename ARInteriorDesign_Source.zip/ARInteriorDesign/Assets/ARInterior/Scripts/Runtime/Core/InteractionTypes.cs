namespace ARInterior.Core
{
    /// <summary>What a single-finger drag does to the selected furniture.</summary>
    public enum InteractionMode
    {
        Select = 0,
        Move = 1,
        Rotate = 2,
        Scale = 3
    }

    /// <summary>Local axis of the selected object used by rotation and axis-constrained moves.</summary>
    public enum TransformAxis
    {
        X = 0,
        Y = 1,
        Z = 2
    }

    /// <summary>How a move drag is constrained.</summary>
    public enum MoveConstraint
    {
        /// <summary>Slide along the detected surface under the finger.</summary>
        Surface = 0,
        AxisX = 1,
        AxisY = 2,
        AxisZ = 3
    }

    /// <summary>The kind of manipulation currently holding the transform lock.</summary>
    public enum ManipulationKind
    {
        None = 0,
        Move = 1,
        Rotate = 2,
        Scale = 3,
        TwoFinger = 4
    }

    public static class MoveConstraintExtensions
    {
        public static bool TryGetAxis(this MoveConstraint constraint, out TransformAxis axis)
        {
            switch (constraint)
            {
                case MoveConstraint.AxisX:
                    axis = TransformAxis.X;
                    return true;
                case MoveConstraint.AxisY:
                    axis = TransformAxis.Y;
                    return true;
                case MoveConstraint.AxisZ:
                    axis = TransformAxis.Z;
                    return true;
                default:
                    axis = TransformAxis.Y;
                    return false;
            }
        }

        public static MoveConstraint ToMoveConstraint(this TransformAxis axis)
        {
            switch (axis)
            {
                case TransformAxis.X:
                    return MoveConstraint.AxisX;
                case TransformAxis.Z:
                    return MoveConstraint.AxisZ;
                default:
                    return MoveConstraint.AxisY;
            }
        }
    }
}
