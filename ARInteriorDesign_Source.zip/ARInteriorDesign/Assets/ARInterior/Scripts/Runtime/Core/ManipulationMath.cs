using UnityEngine;

namespace ARInterior.Core
{
    /// <summary>
    /// Pure, side-effect free maths used by the transform tools. Kept separate so it can be unit tested
    /// without a scene.
    /// </summary>
    public static class ManipulationMath
    {
        public const float DefaultSnapStep = 15f;

        /// <summary>Rounds an angle (degrees) to the nearest multiple of <paramref name="step"/>.</summary>
        public static float SnapAngle(float angle, float step)
        {
            if (step <= 0f)
                return angle;
            return Mathf.Round(angle / step) * step;
        }

        /// <summary>Clamps a uniform scale so it is always positive and inside [min, max].</summary>
        public static float ClampScale(float value, float min, float max)
        {
            var safeMin = Mathf.Max(0.01f, min);
            var safeMax = Mathf.Max(safeMin, max);
            if (float.IsNaN(value) || float.IsInfinity(value))
                return safeMin;
            return Mathf.Clamp(value, safeMin, safeMax);
        }

        /// <summary>
        /// Converts a vertical drag into a multiplicative scale factor. Dragging up by
        /// <paramref name="pixelsPerDoubling"/> doubles the size, dragging down by the same amount halves it.
        /// </summary>
        public static float ScaleFactorFromDrag(float dragPixels, float pixelsPerDoubling)
        {
            if (pixelsPerDoubling <= 0f)
                return 1f;
            return Mathf.Pow(2f, dragPixels / pixelsPerDoubling);
        }

        /// <summary>Converts a horizontal drag into degrees, where a full screen width equals <paramref name="degreesPerScreenWidth"/>.</summary>
        public static float DegreesFromDrag(float dragPixels, float screenWidthPixels, float degreesPerScreenWidth)
        {
            if (screenWidthPixels <= 0f)
                return 0f;
            return dragPixels / screenWidthPixels * degreesPerScreenWidth;
        }

        /// <summary>Signed rotation (degrees, counter-clockwise positive) between two finger segments.</summary>
        public static float TwistDegrees(Vector2 previousA, Vector2 previousB, Vector2 currentA, Vector2 currentB)
        {
            var previous = previousB - previousA;
            var current = currentB - currentA;
            if (previous.sqrMagnitude < 1e-4f || current.sqrMagnitude < 1e-4f)
                return 0f;
            return Vector2.SignedAngle(previous, current);
        }

        /// <summary>Ratio of the current finger distance to the starting finger distance.</summary>
        public static float PinchRatio(float startDistance, float currentDistance)
        {
            if (startDistance < 1f)
                return 1f;
            return Mathf.Max(0.01f, currentDistance / startDistance);
        }

        /// <summary>
        /// Finds the parameter <paramref name="t"/> of the point on the line (origin + dir * t) that is closest to the ray.
        /// Returns false when the ray is (nearly) parallel to the axis, in which case the result is unreliable.
        /// </summary>
        public static bool TryClosestPointOnAxis(Ray ray, Vector3 axisOrigin, Vector3 axisDirection, out float t)
        {
            t = 0f;
            var d = axisDirection.normalized;
            var v = ray.direction.normalized;
            var w = axisOrigin - ray.origin;
            var dv = Vector3.Dot(d, v);
            var denominator = 1f - dv * dv;
            if (denominator < 1e-3f)
                return false;
            // Minimises |axisOrigin + d*t - (ray.origin + v*s)|.
            t = (dv * Vector3.Dot(w, v) - Vector3.Dot(w, d)) / denominator;
            return !float.IsNaN(t) && !float.IsInfinity(t);
        }

        /// <summary>Intersects a ray with a horizontal plane at the given height.</summary>
        public static bool TryIntersectHorizontalPlane(Ray ray, float height, out Vector3 point)
        {
            var plane = new Plane(Vector3.up, new Vector3(0f, height, 0f));
            if (plane.Raycast(ray, out var distance) && distance > 0f)
            {
                point = ray.GetPoint(distance);
                return true;
            }

            point = default;
            return false;
        }

        /// <summary>Yaw-only rotation that makes the object's forward (+Z) face the viewer.</summary>
        public static Quaternion FacingViewer(Vector3 objectPosition, Vector3 viewerPosition)
        {
            var toViewer = viewerPosition - objectPosition;
            toViewer.y = 0f;
            if (toViewer.sqrMagnitude < 1e-6f)
                return Quaternion.identity;
            return Quaternion.LookRotation(toViewer.normalized, Vector3.up);
        }

        public static Vector3 AxisDirection(Transform target, TransformAxis axis)
        {
            switch (axis)
            {
                case TransformAxis.X:
                    return target.right;
                case TransformAxis.Z:
                    return target.forward;
                default:
                    return target.up;
            }
        }

        public static Vector3 LocalAxisVector(TransformAxis axis)
        {
            switch (axis)
            {
                case TransformAxis.X:
                    return Vector3.right;
                case TransformAxis.Z:
                    return Vector3.forward;
                default:
                    return Vector3.up;
            }
        }
    }
}
