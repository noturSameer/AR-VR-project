using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.EnhancedTouch;
using EnhancedTouch = UnityEngine.InputSystem.EnhancedTouch.Touch;
using InputTouchPhase = UnityEngine.InputSystem.TouchPhase;

namespace ARInterior.Interaction
{
    public enum PointerPhase
    {
        Began,
        Moved,
        Stationary,
        Ended,
        Canceled
    }

    /// <summary>One pointer (finger or mouse) in one frame.</summary>
    public readonly struct PointerSample
    {
        public PointerSample(int id, Vector2 position, PointerPhase phase)
        {
            Id = id;
            Position = position;
            Phase = phase;
        }

        public int Id { get; }
        public Vector2 Position { get; }
        public PointerPhase Phase { get; }

        public override string ToString() => $"#{Id} {Phase} {Position}";
    }

    /// <summary>
    /// Supplies every active pointer once per frame. Pointers that are still down must be reported
    /// every frame (Moved or Stationary); a pointer that disappears is treated as cancelled.
    /// </summary>
    public interface IPointerSource
    {
        void Collect(List<PointerSample> results);
    }

    /// <summary>
    /// Reads touches through the Input System's EnhancedTouch API. When no finger is down, the mouse's
    /// left button acts as a single pointer so the same code path works in the Editor and demo mode.
    /// </summary>
    public sealed class DevicePointerSource : IPointerSource, IDisposable
    {
        public const int MousePointerId = -100;

        bool m_MouseDown;
        bool m_Disposed;

        public DevicePointerSource()
        {
            EnhancedTouchSupport.Enable();
        }

        public void Collect(List<PointerSample> results)
        {
            results.Clear();
            if (m_Disposed)
                return;

            var touches = EnhancedTouch.activeTouches;
            if (touches.Count > 0)
            {
                if (m_MouseDown)
                {
                    m_MouseDown = false;
                    results.Add(new PointerSample(MousePointerId, Vector2.zero, PointerPhase.Canceled));
                }

                for (var i = 0; i < touches.Count; i++)
                {
                    var touch = touches[i];
                    if (TryMapPhase(touch.phase, out var phase))
                        results.Add(new PointerSample(touch.touchId, touch.screenPosition, phase));
                }

                return;
            }

            var mouse = Mouse.current;
            if (mouse == null)
            {
                if (m_MouseDown)
                {
                    m_MouseDown = false;
                    results.Add(new PointerSample(MousePointerId, Vector2.zero, PointerPhase.Canceled));
                }

                return;
            }

            var position = mouse.position.ReadValue();
            var button = mouse.leftButton;
            if (!m_MouseDown && button.wasPressedThisFrame)
            {
                m_MouseDown = true;
                results.Add(new PointerSample(MousePointerId, position, PointerPhase.Began));
            }
            else if (m_MouseDown && button.isPressed)
            {
                results.Add(new PointerSample(MousePointerId, position, PointerPhase.Moved));
            }
            else if (m_MouseDown)
            {
                m_MouseDown = false;
                results.Add(new PointerSample(MousePointerId, position, PointerPhase.Ended));
            }
        }

        static bool TryMapPhase(InputTouchPhase phase, out PointerPhase mapped)
        {
            switch (phase)
            {
                case InputTouchPhase.Began:
                    mapped = PointerPhase.Began;
                    return true;
                case InputTouchPhase.Moved:
                    mapped = PointerPhase.Moved;
                    return true;
                case InputTouchPhase.Stationary:
                    mapped = PointerPhase.Stationary;
                    return true;
                case InputTouchPhase.Ended:
                    mapped = PointerPhase.Ended;
                    return true;
                case InputTouchPhase.Canceled:
                    mapped = PointerPhase.Canceled;
                    return true;
                default:
                    mapped = PointerPhase.Stationary;
                    return false;
            }
        }

        public void Dispose()
        {
            if (m_Disposed)
                return;
            m_Disposed = true;
            EnhancedTouchSupport.Disable();
        }
    }
}
