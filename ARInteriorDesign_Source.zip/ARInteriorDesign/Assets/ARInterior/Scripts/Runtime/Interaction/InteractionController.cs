using System;
using ARInterior.Core;
using ARInterior.Furniture;
using ARInterior.Rendering;
using UnityEngine;

namespace ARInterior.Interaction
{
    /// <summary>
    /// Central coordinator of the editing tools. Receives recognised gestures, decides what they mean in
    /// the active mode (place, select, move, rotate, scale) and performs the change through the
    /// <see cref="TransformController"/> lock. UI buttons call the public methods of this class.
    /// </summary>
    public sealed class InteractionController : MonoBehaviour, ISceneGestureHandler
    {
        [Header("Scene references")]
        [SerializeField] Camera m_Camera;
        [SerializeField] SurfaceProvider m_SurfaceProvider;
        [SerializeField] ExperienceStatusProvider m_StatusProvider;
        [SerializeField] SelectionManager m_Selection;
        [SerializeField] TransformController m_Transformer;
        [SerializeField] PlacementController m_Placement;
        [SerializeField] AxisGizmo m_MoveGizmo;
        [SerializeField] LayerMask m_FurnitureMask;

        [Header("Tuning")]
        [SerializeField, Min(10f)] float m_RotationDegreesPerScreenWidth = 360f;
        [Tooltip("Vertical drag, as a fraction of the screen height, that doubles (or halves) the size.")]
        [SerializeField, Range(0.1f, 2f)] float m_ScaleDoublingScreenFraction = 0.5f;
        [SerializeField, Min(0.1f)] float m_MaxAxisTravel = 3f;
        [SerializeField, Min(1f)] float m_MaxPickDistance = 30f;
        [SerializeField, Min(0.5f)] float m_MessageDuration = 2.5f;

        struct DragState
        {
            public bool Active;
            public PlacedFurniture Target;
            public ManipulationKind Kind;
            public Vector2 StartScreen;
            public Vector2 LastScreen;
            public Vector3 GrabOffset;
            public bool AxisMode;
            public TransformAxis Axis;
            public Vector3 AxisOrigin;
            public Vector3 AxisDirection;
            public bool AxisStartValid;
            public float AxisStartT;
            public Component LastSurface;
            public bool HasSurfaceHit;
            public float TwoFingerStartDistance;
            public Vector2 LastFirst;
            public Vector2 LastSecond;
        }

        InteractionMode m_Mode = InteractionMode.Select;
        TransformAxis m_RotationAxis = TransformAxis.Y;
        MoveConstraint m_MoveConstraint = MoveConstraint.Surface;
        DragState m_Drag;
        string m_Message;
        float m_MessageUntil;
        bool m_IsValid;

        public event Action<InteractionMode> ModeChanged;
        public event Action SettingsChanged;
        public event Action<string> MessageShown;

        public InteractionMode Mode => m_Mode;
        public TransformAxis RotationAxis => m_RotationAxis;
        public MoveConstraint MoveConstraint => m_MoveConstraint;
        public bool SnapRotation => m_Transformer != null && m_Transformer.SnapRotation;
        public bool IsGestureActive => m_Drag.Active && m_Transformer != null && m_Transformer.IsOwner(this);
        public Camera ViewCamera => m_Camera;
        public SelectionManager Selection => m_Selection;
        public PlacementController Placement => m_Placement;
        public TransformController Transformer => m_Transformer;
        public ExperienceStatusProvider StatusProvider => m_StatusProvider;
        public AxisGizmo MoveGizmo => m_MoveGizmo;

        /// <summary>Short feedback message (e.g. "No surface there"), or null once it has expired.</summary>
        public string ActiveMessage => Time.unscaledTime < m_MessageUntil ? m_Message : null;

        bool CanInteract => m_IsValid && m_StatusProvider.Current.AllowsInteraction;

        void Awake()
        {
            m_IsValid = m_Camera != null && m_SurfaceProvider != null && m_StatusProvider != null &&
                        m_Selection != null && m_Transformer != null && m_Placement != null;
            if (!m_IsValid)
                Debug.LogError($"{nameof(InteractionController)} on '{name}' is missing required references.", this);
        }

        void OnEnable()
        {
            if (!m_IsValid)
                return;
            m_StatusProvider.StatusChanged += OnStatusChanged;
            m_Selection.SelectionChanged += OnSelectionChanged;
            RefreshGizmo();
        }

        void OnDisable()
        {
            if (!m_IsValid)
                return;
            CancelActiveGesture(true);
            m_StatusProvider.StatusChanged -= OnStatusChanged;
            m_Selection.SelectionChanged -= OnSelectionChanged;
        }

        // ------------------------------------------------------------------ UI commands

        public void SetMode(InteractionMode mode)
        {
            if (mode == m_Mode)
                return;
            // Finish (commit) whatever the finger was doing before switching tools.
            EndActiveGesture();
            m_Mode = mode;
            RefreshGizmo();
            ModeChanged?.Invoke(mode);
        }

        public void SetRotationAxis(TransformAxis axis)
        {
            if (axis == m_RotationAxis)
                return;
            EndActiveGesture();
            m_RotationAxis = axis;
            SettingsChanged?.Invoke();
        }

        public void SetMoveConstraint(MoveConstraint constraint)
        {
            if (constraint == m_MoveConstraint)
                return;
            EndActiveGesture();
            m_MoveConstraint = constraint;
            RefreshGizmo();
            SettingsChanged?.Invoke();
        }

        public void SetSnapRotation(bool enabled)
        {
            if (m_Transformer == null || m_Transformer.SnapRotation == enabled)
                return;
            m_Transformer.SnapRotation = enabled;
            SettingsChanged?.Invoke();
        }

        public void DeleteSelected()
        {
            if (!m_IsValid)
                return;
            var target = m_Selection.Selected;
            if (target == null)
            {
                ShowMessage("Select a piece of furniture to delete");
                return;
            }

            CancelActiveGesture(false);
            m_Transformer.ForceCancel(false);
            m_Selection.Deselect();
            m_Placement.Remove(target);
            ShowMessage($"{target.DisplayName} deleted");
        }

        public void ResetSelectedScale()
        {
            if (!m_IsValid)
                return;
            var target = m_Selection.Selected;
            if (target == null)
            {
                ShowMessage("Select a piece of furniture first");
                return;
            }

            EndActiveGesture();
            m_Transformer.TryResetScale(target);
        }

        public void ShowMessage(string message)
        {
            m_Message = message;
            m_MessageUntil = Time.unscaledTime + m_MessageDuration;
            MessageShown?.Invoke(message);
        }

        // ------------------------------------------------------------------ gestures

        public void OnTap(Vector2 screenPosition)
        {
            if (!CanInteract)
                return;

            if (m_Placement.IsArmed)
            {
                if (m_Placement.TryPlace(screenPosition, out var placed))
                    m_Selection.Select(placed);
                else if (!string.IsNullOrEmpty(m_Placement.LastFailureReason))
                    ShowMessage(m_Placement.LastFailureReason);
                return;
            }

            var picked = PickFurniture(screenPosition);
            if (picked != null)
                m_Selection.Select(picked);
            else
                m_Selection.Deselect();
        }

        public bool OnDragBegin(Vector2 startPosition, Vector2 currentPosition)
        {
            if (!CanInteract || m_Mode == InteractionMode.Select || m_Placement.IsArmed)
                return false;

            TransformAxis? handleAxis = null;
            if (m_Mode == InteractionMode.Move && m_MoveGizmo != null &&
                m_MoveGizmo.TryPickHandle(startPosition, out var grabbedAxis))
            {
                handleAxis = grabbedAxis;
            }
            else
            {
                var touched = PickFurniture(startPosition);
                if (touched != null && touched != m_Selection.Selected)
                    m_Selection.Select(touched);
            }

            var target = m_Selection.Selected;
            if (target == null)
            {
                ShowMessage("Tap a piece of furniture to select it first");
                return false;
            }

            var kind = ToManipulationKind(m_Mode);
            if (!m_Transformer.TryBegin(target, kind, this, m_RotationAxis))
                return false;

            m_Drag = new DragState
            {
                Active = true,
                Target = target,
                Kind = kind,
                StartScreen = startPosition,
                LastScreen = startPosition
            };

            if (kind == ManipulationKind.Move)
                PrepareMove(target, startPosition, handleAxis);

            return true;
        }

        public bool OnDragUpdate(Vector2 screenPosition)
        {
            if (!IsGestureActive || m_Drag.Target == null || m_Drag.Target.IsBeingDestroyed)
            {
                ClearDrag();
                return false;
            }

            if (!CanInteract)
            {
                CancelActiveGesture(true);
                return false;
            }

            switch (m_Drag.Kind)
            {
                case ManipulationKind.Move:
                    UpdateMove(screenPosition);
                    break;
                case ManipulationKind.Rotate:
                    UpdateRotate(screenPosition);
                    break;
                case ManipulationKind.Scale:
                    UpdateScale(screenPosition);
                    break;
            }

            m_Drag.LastScreen = screenPosition;
            return true;
        }

        public void OnDragEnd() => EndActiveGesture();

        public void OnDragCancel() => CancelActiveGesture(true);

        public bool OnTwoFingerBegin(Vector2 first, Vector2 second)
        {
            if (!CanInteract || m_Placement.IsArmed)
                return false;

            var target = m_Selection.Selected;
            if (target == null)
            {
                target = PickFurniture((first + second) * 0.5f);
                if (target != null)
                    m_Selection.Select(target);
            }

            if (target == null || !m_Transformer.TryBegin(target, ManipulationKind.TwoFinger, this, TransformAxis.Y))
                return false;

            m_Drag = new DragState
            {
                Active = true,
                Target = target,
                Kind = ManipulationKind.TwoFinger,
                TwoFingerStartDistance = Vector2.Distance(first, second),
                LastFirst = first,
                LastSecond = second
            };
            return true;
        }

        public bool OnTwoFingerUpdate(Vector2 first, Vector2 second)
        {
            if (!IsGestureActive || m_Drag.Kind != ManipulationKind.TwoFinger || m_Drag.Target == null)
            {
                ClearDrag();
                return false;
            }

            if (!CanInteract)
            {
                CancelActiveGesture(true);
                return false;
            }

            var ratio = ManipulationMath.PinchRatio(m_Drag.TwoFingerStartDistance, Vector2.Distance(first, second));
            m_Transformer.ScaleFromStart(this, ratio);

            // A counter-clockwise twist on screen turns the object counter-clockwise seen from above (negative yaw in Unity).
            var twist = ManipulationMath.TwistDegrees(m_Drag.LastFirst, m_Drag.LastSecond, first, second);
            m_Transformer.RotateBy(this, -twist);

            m_Drag.LastFirst = first;
            m_Drag.LastSecond = second;
            return true;
        }

        public void OnTwoFingerEnd() => EndActiveGesture();

        // ------------------------------------------------------------------ move / rotate / scale

        void PrepareMove(PlacedFurniture target, Vector2 startPosition, TransformAxis? handleAxis)
        {
            var constraint = handleAxis.HasValue ? handleAxis.Value.ToMoveConstraint() : m_MoveConstraint;
            if (constraint.TryGetAxis(out var axis))
            {
                m_Drag.AxisMode = true;
                m_Drag.Axis = axis;
                m_Drag.AxisOrigin = target.transform.position;
                m_Drag.AxisDirection = ManipulationMath.AxisDirection(target.transform, axis);
                m_Drag.AxisStartValid = ManipulationMath.TryClosestPointOnAxis(
                    m_Camera.ScreenPointToRay(startPosition), m_Drag.AxisOrigin, m_Drag.AxisDirection,
                    out m_Drag.AxisStartT);
                if (m_MoveGizmo != null)
                    m_MoveGizmo.Highlight(axis);
                return;
            }

            m_Drag.AxisMode = false;
            m_Drag.GrabOffset = Vector3.zero;
            if (TryGetDragPoint(startPosition, target, out var point, out var surface))
            {
                var offset = target.transform.position - point;
                offset.y = 0f;
                m_Drag.GrabOffset = offset;
                m_Drag.LastSurface = surface;
                m_Drag.HasSurfaceHit = surface != null;
            }
        }

        void UpdateMove(Vector2 screenPosition)
        {
            var target = m_Drag.Target;
            if (!m_Drag.AxisMode)
            {
                if (!TryGetDragPoint(screenPosition, target, out var point, out var surface))
                    return;
                var position = point + m_Drag.GrabOffset;
                if (surface == null)
                    position.y = target.transform.position.y;
                else
                {
                    m_Drag.LastSurface = surface;
                    m_Drag.HasSurfaceHit = true;
                }

                m_Transformer.SetPosition(this, position);
                return;
            }

            float travel;
            var ray = m_Camera.ScreenPointToRay(screenPosition);
            if (m_Drag.AxisStartValid &&
                ManipulationMath.TryClosestPointOnAxis(ray, m_Drag.AxisOrigin, m_Drag.AxisDirection, out var t))
            {
                travel = t - m_Drag.AxisStartT;
            }
            else
            {
                // Axis almost parallel to the view ray: fall back to the axis' projection on screen.
                Vector2 screenOrigin = m_Camera.WorldToScreenPoint(m_Drag.AxisOrigin);
                Vector2 screenTip = m_Camera.WorldToScreenPoint(m_Drag.AxisOrigin + m_Drag.AxisDirection);
                var screenAxis = screenTip - screenOrigin;
                if (screenAxis.sqrMagnitude < 1f)
                    return;
                travel = Vector2.Dot(screenPosition - m_Drag.StartScreen, screenAxis.normalized) / screenAxis.magnitude;
            }

            travel = Mathf.Clamp(travel, -m_MaxAxisTravel, m_MaxAxisTravel);
            m_Transformer.SetPosition(this, m_Drag.AxisOrigin + m_Drag.AxisDirection * travel);
        }

        void UpdateRotate(Vector2 screenPosition)
        {
            var delta = screenPosition - m_Drag.LastScreen;
            // Y and Z follow horizontal drags; X (tilt) follows vertical drags.
            var pixels = m_RotationAxis == TransformAxis.X ? delta.y : delta.x;
            var degrees = ManipulationMath.DegreesFromDrag(pixels, Screen.width, m_RotationDegreesPerScreenWidth);
            // Dragging right swings the near side of the object to the right (counter-clockwise from above).
            if (m_RotationAxis == TransformAxis.Y)
                degrees = -degrees;
            m_Transformer.RotateBy(this, degrees);
        }

        void UpdateScale(Vector2 screenPosition)
        {
            var dragPixels = screenPosition.y - m_Drag.StartScreen.y;
            var factor = ManipulationMath.ScaleFactorFromDrag(dragPixels, Screen.height * m_ScaleDoublingScreenFraction);
            m_Transformer.ScaleFromStart(this, factor);
        }

        /// <summary>
        /// Surface point under the finger. Falls back to a horizontal plane at the object's base when no
        /// detected surface is hit, so a drag never stalls at a plane boundary.
        /// </summary>
        bool TryGetDragPoint(Vector2 screenPosition, PlacedFurniture target, out Vector3 point, out Component surface)
        {
            if (m_SurfaceProvider.TryRaycast(screenPosition, out var hit))
            {
                point = hit.Pose.position;
                surface = hit.Surface;
                return true;
            }

            surface = null;
            return ManipulationMath.TryIntersectHorizontalPlane(
                m_Camera.ScreenPointToRay(screenPosition), target.transform.position.y, out point);
        }

        // ------------------------------------------------------------------ gesture lifecycle

        void EndActiveGesture()
        {
            if (!m_Drag.Active)
                return;

            var drag = m_Drag;
            ClearDrag();
            if (!m_Transformer.IsOwner(this))
                return;

            m_Transformer.End(this);
            if (drag.Kind == ManipulationKind.Move && drag.Target != null && !drag.Target.IsBeingDestroyed)
            {
                // Re-anchor once per finished move (never per frame).
                if (!drag.AxisMode && drag.HasSurfaceHit && drag.LastSurface != null)
                    m_SurfaceProvider.AttachToSurface(drag.Target, drag.LastSurface);
                else
                    m_SurfaceProvider.AttachInPlace(drag.Target);
            }
        }

        void CancelActiveGesture(bool restoreStartPose)
        {
            if (!m_Drag.Active)
                return;
            ClearDrag();
            m_Transformer.Cancel(this, restoreStartPose);
        }

        void ClearDrag()
        {
            m_Drag = default;
            if (m_MoveGizmo != null)
                m_MoveGizmo.Highlight(m_MoveConstraint.TryGetAxis(out var axis) ? axis : (TransformAxis?)null);
        }

        // ------------------------------------------------------------------ helpers

        PlacedFurniture PickFurniture(Vector2 screenPosition)
        {
            Physics.SyncTransforms();
            var ray = m_Camera.ScreenPointToRay(screenPosition);
            if (!Physics.Raycast(ray, out var hit, m_MaxPickDistance, m_FurnitureMask, QueryTriggerInteraction.Ignore))
                return null;
            var item = hit.collider.GetComponentInParent<PlacedFurniture>();
            return item != null && !item.IsBeingDestroyed ? item : null;
        }

        void OnStatusChanged(ExperienceStatus status)
        {
            if (!status.AllowsInteraction)
                CancelActiveGesture(true);
            RefreshGizmo();
        }

        void OnSelectionChanged(PlacedFurniture selected)
        {
            if (m_Drag.Active && m_Drag.Target != selected)
                CancelActiveGesture(false);
            RefreshGizmo();
        }

        void RefreshGizmo()
        {
            if (m_MoveGizmo == null || !m_IsValid)
                return;
            var selected = m_Selection.Selected;
            if (m_Mode == InteractionMode.Move && selected != null && m_StatusProvider.Current.AllowsInteraction)
            {
                m_MoveGizmo.Show(selected);
                m_MoveGizmo.Highlight(m_MoveConstraint.TryGetAxis(out var axis) ? axis : (TransformAxis?)null);
            }
            else
            {
                m_MoveGizmo.Hide();
            }
        }

        static ManipulationKind ToManipulationKind(InteractionMode mode)
        {
            switch (mode)
            {
                case InteractionMode.Move:
                    return ManipulationKind.Move;
                case InteractionMode.Rotate:
                    return ManipulationKind.Rotate;
                case InteractionMode.Scale:
                    return ManipulationKind.Scale;
                default:
                    return ManipulationKind.None;
            }
        }
    }
}
