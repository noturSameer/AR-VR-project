using System;
using ARInterior.Core;
using ARInterior.Furniture;
using UnityEngine;

namespace ARInterior.Interaction
{
    /// <summary>
    /// The only component that writes to a furniture Transform during manipulation. A caller must
    /// acquire the lock with <see cref="TryBegin"/>; while one owner holds it every other request is
    /// rejected, so two input handlers can never fight over the same object.
    /// </summary>
    public sealed class TransformController : MonoBehaviour
    {
        [SerializeField] bool m_SnapRotation;
        [SerializeField, Range(1f, 90f)] float m_SnapStep = ManipulationMath.DefaultSnapStep;

        PlacedFurniture m_Target;
        object m_Owner;
        ManipulationKind m_Kind;
        TransformAxis m_RotationAxis;
        Vector3 m_StartPosition;
        Quaternion m_StartRotation;
        float m_StartScale;
        float m_AccumulatedDegrees;

        /// <summary>Raised whenever position, rotation or scale of a furniture item changes.</summary>
        public event Action<PlacedFurniture> TransformChanged;

        /// <summary>Raised when a manipulation finishes (ended or cancelled).</summary>
        public event Action<PlacedFurniture, ManipulationKind> ManipulationEnded;

        public bool IsManipulating => m_Owner != null && m_Target != null;
        public PlacedFurniture Target => m_Target;
        public ManipulationKind ActiveKind => IsManipulating ? m_Kind : ManipulationKind.None;
        public float SnapStep => m_SnapStep;

        public bool SnapRotation
        {
            get => m_SnapRotation;
            set => m_SnapRotation = value;
        }

        public bool IsOwner(object owner) => IsManipulating && ReferenceEquals(owner, m_Owner);

        public bool TryBegin(PlacedFurniture target, ManipulationKind kind, object owner,
            TransformAxis rotationAxis = TransformAxis.Y)
        {
            if (target == null || owner == null || kind == ManipulationKind.None || target.IsBeingDestroyed)
                return false;

            // Drop a stale lock whose target was destroyed without notifying us.
            if (m_Owner != null && m_Target == null)
                ReleaseLock();

            if (IsManipulating)
                return false;

            m_Target = target;
            m_Owner = owner;
            m_Kind = kind;
            m_RotationAxis = rotationAxis;
            var t = target.transform;
            m_StartPosition = t.position;
            m_StartRotation = t.rotation;
            m_StartScale = t.localScale.x;
            m_AccumulatedDegrees = 0f;
            target.Destroyed += OnTargetDestroyed;
            return true;
        }

        public void SetPosition(object owner, Vector3 worldPosition)
        {
            if (!IsOwner(owner) || m_Kind != ManipulationKind.Move)
                return;
            if (!IsFinite(worldPosition))
                return;
            m_Target.transform.position = worldPosition;
            TransformChanged?.Invoke(m_Target);
        }

        /// <summary>Accumulates a rotation delta; with snapping on, the applied angle jumps in <see cref="SnapStep"/> increments.</summary>
        public void RotateBy(object owner, float deltaDegrees)
        {
            if (!IsOwner(owner) || (m_Kind != ManipulationKind.Rotate && m_Kind != ManipulationKind.TwoFinger))
                return;
            if (float.IsNaN(deltaDegrees) || float.IsInfinity(deltaDegrees))
                return;

            m_AccumulatedDegrees += deltaDegrees;
            var applied = m_SnapRotation
                ? ManipulationMath.SnapAngle(m_AccumulatedDegrees, m_SnapStep)
                : m_AccumulatedDegrees;
            var axis = ManipulationMath.LocalAxisVector(m_RotationAxis);
            m_Target.transform.rotation = m_StartRotation * Quaternion.AngleAxis(applied, axis);
            TransformChanged?.Invoke(m_Target);
        }

        /// <summary>Sets the uniform scale to start scale × <paramref name="factor"/>, clamped to the item's limits.</summary>
        public void ScaleFromStart(object owner, float factor)
        {
            if (!IsOwner(owner) || (m_Kind != ManipulationKind.Scale && m_Kind != ManipulationKind.TwoFinger))
                return;

            var scale = ManipulationMath.ClampScale(m_StartScale * factor, m_Target.MinScale, m_Target.MaxScale);
            m_Target.transform.localScale = Vector3.one * scale;
            TransformChanged?.Invoke(m_Target);
        }

        public void End(object owner)
        {
            if (!IsOwner(owner))
                return;
            var target = m_Target;
            var kind = m_Kind;
            ReleaseLock();
            ManipulationEnded?.Invoke(target, kind);
        }

        public void Cancel(object owner, bool restoreStartPose)
        {
            if (!IsOwner(owner))
                return;
            CancelInternal(restoreStartPose);
        }

        /// <summary>Releases the lock regardless of owner (deletion, tracking loss).</summary>
        public void ForceCancel(bool restoreStartPose)
        {
            if (m_Owner == null)
                return;
            CancelInternal(restoreStartPose);
        }

        /// <summary>One-shot reset used by the UI; refused while a gesture holds the lock.</summary>
        public bool TryResetScale(PlacedFurniture target)
        {
            if (target == null || target.IsBeingDestroyed || IsManipulating)
                return false;
            var scale = ManipulationMath.ClampScale(1f, target.MinScale, target.MaxScale);
            target.transform.localScale = Vector3.one * scale;
            TransformChanged?.Invoke(target);
            return true;
        }

        void CancelInternal(bool restoreStartPose)
        {
            var target = m_Target;
            var kind = m_Kind;
            if (restoreStartPose && target != null && !target.IsBeingDestroyed)
            {
                var t = target.transform;
                t.SetPositionAndRotation(m_StartPosition, m_StartRotation);
                t.localScale = Vector3.one * m_StartScale;
                TransformChanged?.Invoke(target);
            }

            ReleaseLock();
            if (target != null)
                ManipulationEnded?.Invoke(target, kind);
        }

        void ReleaseLock()
        {
            if (m_Target != null)
                m_Target.Destroyed -= OnTargetDestroyed;
            m_Target = null;
            m_Owner = null;
            m_Kind = ManipulationKind.None;
            m_AccumulatedDegrees = 0f;
        }

        void OnTargetDestroyed(PlacedFurniture destroyed)
        {
            if (destroyed == m_Target)
            {
                m_Target = null;
                m_Owner = null;
                m_Kind = ManipulationKind.None;
            }
        }

        void OnDisable()
        {
            ForceCancel(false);
        }

        static bool IsFinite(Vector3 v) =>
            !(float.IsNaN(v.x) || float.IsNaN(v.y) || float.IsNaN(v.z) ||
              float.IsInfinity(v.x) || float.IsInfinity(v.y) || float.IsInfinity(v.z));
    }
}
