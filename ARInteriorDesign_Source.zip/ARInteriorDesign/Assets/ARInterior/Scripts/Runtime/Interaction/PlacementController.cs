using System;
using System.Collections.Generic;
using ARInterior.Core;
using ARInterior.Furniture;
using UnityEngine;

namespace ARInterior.Interaction
{
    /// <summary>
    /// Arms a catalogue item and instantiates it where the user taps on a surface. Placement is guarded
    /// against duplicates (one placement per frame, a short cooldown and disarm-after-place) and against
    /// unbounded instantiation (item limit).
    /// </summary>
    public sealed class PlacementController : MonoBehaviour
    {
        [SerializeField] FurnitureCatalog m_Catalog;
        [SerializeField] SurfaceProvider m_SurfaceProvider;
        [SerializeField] Camera m_Camera;
        [SerializeField, Range(1, 100)] int m_MaxPlacedItems = 25;
        [SerializeField, Min(0f)] float m_PlacementCooldown = 0.3f;
        [SerializeField] bool m_DisarmAfterPlacement = true;

        readonly List<PlacedFurniture> m_Placed = new List<PlacedFurniture>();
        FurnitureDefinition m_Armed;
        int m_LastPlacementFrame = -1;
        float m_LastPlacementTime = float.NegativeInfinity;
        int m_Counter;

        public event Action<FurnitureDefinition> ArmedItemChanged;
        public event Action<PlacedFurniture> ItemPlaced;
        public event Action<PlacedFurniture> ItemRemoved;

        public FurnitureCatalog Catalog => m_Catalog;
        public FurnitureDefinition ArmedItem => m_Armed;
        public bool IsArmed => m_Armed != null;
        public IReadOnlyList<PlacedFurniture> PlacedItems => m_Placed;
        public int PlacedCount => m_Placed.Count;
        public int MaxPlacedItems => m_MaxPlacedItems;

        /// <summary>Human-readable reason for the last failed <see cref="TryPlace"/>; null for silent duplicate suppression.</summary>
        public string LastFailureReason { get; private set; }

        void Awake()
        {
            if (m_Catalog == null || m_SurfaceProvider == null || m_Camera == null)
            {
                Debug.LogError($"{nameof(PlacementController)} on '{name}' is missing catalog, surface provider or camera.", this);
                enabled = false;
                return;
            }

            foreach (var problem in m_Catalog.Validate())
                Debug.LogError($"Furniture catalogue problem: {problem}", m_Catalog);
        }

        /// <summary>Arms an item for placement. Arming the already armed item disarms it (toggle).</summary>
        public void Arm(FurnitureDefinition definition)
        {
            if (definition == null || !definition.IsValid(out _))
            {
                Disarm();
                return;
            }

            if (definition == m_Armed)
            {
                Disarm();
                return;
            }

            m_Armed = definition;
            ArmedItemChanged?.Invoke(m_Armed);
        }

        public void Disarm()
        {
            if (m_Armed == null)
                return;
            m_Armed = null;
            ArmedItemChanged?.Invoke(null);
        }

        public bool TryPlace(Vector2 screenPosition, out PlacedFurniture placed)
        {
            placed = null;
            LastFailureReason = null;

            if (!enabled || m_Armed == null)
            {
                LastFailureReason = "Choose furniture from the catalogue first";
                return false;
            }

            // Duplicate tap protection: repeated events in the same frame or within the cooldown are ignored.
            if (Time.frameCount == m_LastPlacementFrame ||
                Time.unscaledTime - m_LastPlacementTime < m_PlacementCooldown)
            {
                return false;
            }

            if (m_Placed.Count >= m_MaxPlacedItems)
            {
                LastFailureReason = $"Limit of {m_MaxPlacedItems} items reached — delete something first";
                return false;
            }

            if (!m_SurfaceProvider.TryRaycast(screenPosition, out var hit))
            {
                LastFailureReason = "No surface detected there — tap a highlighted surface";
                return false;
            }

            placed = PlaceAt(m_Armed, hit);
            return placed != null;
        }

        /// <summary>Instantiates <paramref name="definition"/> on <paramref name="hit"/>, facing the camera.</summary>
        public PlacedFurniture PlaceAt(FurnitureDefinition definition, SurfaceHit hit)
        {
            if (definition == null || definition.Prefab == null)
                return null;

            var position = hit.Pose.position;
            var rotation = ManipulationMath.FacingViewer(position, m_Camera.transform.position);
            var instance = Instantiate(definition.Prefab, position, rotation, m_SurfaceProvider.PlacedObjectsRoot);
            instance.name = $"{definition.DisplayName} #{++m_Counter}";
            instance.Destroyed += OnItemDestroyed;
            m_Placed.Add(instance);

            m_SurfaceProvider.AttachToSurface(instance, hit.Surface);
            Physics.SyncTransforms();

            m_LastPlacementFrame = Time.frameCount;
            m_LastPlacementTime = Time.unscaledTime;
            if (m_DisarmAfterPlacement)
                Disarm();

            ItemPlaced?.Invoke(instance);
            return instance;
        }

        /// <summary>Releases surface resources (anchors) and destroys the item.</summary>
        public void Remove(PlacedFurniture item)
        {
            if (item == null)
                return;
            item.Destroyed -= OnItemDestroyed;
            m_SurfaceProvider.Release(item);
            var wasTracked = m_Placed.Remove(item);
            item.DestroySelf();
            if (wasTracked)
                ItemRemoved?.Invoke(item);
        }

        void OnItemDestroyed(PlacedFurniture item)
        {
            if (!m_Placed.Remove(item))
                return;
            if (m_SurfaceProvider != null)
                m_SurfaceProvider.Release(item);
            ItemRemoved?.Invoke(item);
        }

        void OnDestroy()
        {
            foreach (var item in m_Placed)
            {
                if (item != null)
                    item.Destroyed -= OnItemDestroyed;
            }

            m_Placed.Clear();
        }
    }
}
