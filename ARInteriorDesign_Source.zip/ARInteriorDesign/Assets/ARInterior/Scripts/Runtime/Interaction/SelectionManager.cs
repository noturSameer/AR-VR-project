using System;
using ARInterior.Furniture;
using ARInterior.Rendering;
using UnityEngine;

namespace ARInterior.Interaction
{
    /// <summary>Owns the current selection and drives the yellow-orange outline.</summary>
    public sealed class SelectionManager : MonoBehaviour
    {
        [SerializeField] SelectionOutline m_Outline;

        PlacedFurniture m_Selected;

        public event Action<PlacedFurniture> SelectionChanged;

        public PlacedFurniture Selected => m_Selected;
        public bool HasSelection => m_Selected != null;
        public SelectionOutline Outline => m_Outline;

        void Awake()
        {
            if (m_Outline == null)
                Debug.LogError($"{nameof(SelectionManager)} on '{name}' has no outline assigned.", this);
        }

        public void Select(PlacedFurniture item)
        {
            if (item != null && item.IsBeingDestroyed)
                item = null;
            if (item == m_Selected)
                return;

            if (m_Selected != null)
                m_Selected.Destroyed -= OnSelectedDestroyed;

            m_Selected = item;

            if (m_Selected != null)
            {
                m_Selected.Destroyed += OnSelectedDestroyed;
                if (m_Outline != null)
                    m_Outline.Show(m_Selected);
            }
            else if (m_Outline != null)
            {
                m_Outline.Clear();
            }

            SelectionChanged?.Invoke(m_Selected);
        }

        public void Deselect() => Select(null);

        void OnSelectedDestroyed(PlacedFurniture destroyed)
        {
            if (destroyed != m_Selected)
                return;
            m_Selected = null;
            if (m_Outline != null)
                m_Outline.Clear();
            SelectionChanged?.Invoke(null);
        }

        void OnDestroy()
        {
            if (m_Selected != null)
                m_Selected.Destroyed -= OnSelectedDestroyed;
            m_Selected = null;
        }
    }
}
