using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace ARInterior.Interaction
{
    /// <summary>
    /// Per-frame entry point for scene input. Collects pointer samples, filters pointers that start on
    /// the UI (EventSystem raycast) and feeds the gesture recogniser, which calls the InteractionController.
    /// </summary>
    [DefaultExecutionOrder(-50)]
    public sealed class TouchInputRouter : MonoBehaviour
    {
        [SerializeField] InteractionController m_Interaction;
        [Tooltip("Optional; falls back to EventSystem.current.")]
        [SerializeField] EventSystem m_EventSystem;
        [SerializeField, Min(0.05f)] float m_TapMaxDuration = 0.45f;
        [Tooltip("Finger travel (inches) before a touch becomes a drag.")]
        [SerializeField, Min(0.01f)] float m_DragThresholdInches = 0.06f;

        readonly List<PointerSample> m_Samples = new List<PointerSample>(8);
        readonly List<RaycastResult> m_UiHits = new List<RaycastResult>(8);
        IPointerSource m_Source;
        DevicePointerSource m_OwnedSource;
        GestureRecognizer m_Recognizer;
        PointerEventData m_PointerData;
        EventSystem m_PointerDataOwner;

        public GestureRecognizer Recognizer => m_Recognizer;

        void Awake()
        {
            if (m_Interaction == null)
            {
                Debug.LogError($"{nameof(TouchInputRouter)} on '{name}' has no InteractionController assigned.", this);
                enabled = false;
                return;
            }

            m_Recognizer = new GestureRecognizer(m_Interaction, IsOverUI)
            {
                TapMaxDuration = m_TapMaxDuration,
                DragThresholdPixels = ComputeDragThresholdPixels()
            };
        }

        void OnEnable()
        {
            if (m_Source == null)
            {
                m_OwnedSource = new DevicePointerSource();
                m_Source = m_OwnedSource;
            }
        }

        void OnDisable()
        {
            m_Recognizer?.Reset();
            if (m_OwnedSource != null)
            {
                if (ReferenceEquals(m_Source, m_OwnedSource))
                    m_Source = null;
                m_OwnedSource.Dispose();
                m_OwnedSource = null;
            }
        }

        void OnApplicationPause(bool paused)
        {
            if (paused)
                m_Recognizer?.Reset();
        }

        /// <summary>Replaces the device input (used by automated tests to inject touches).</summary>
        public void SetPointerSource(IPointerSource source)
        {
            m_Recognizer?.Reset();
            if (m_OwnedSource != null && !ReferenceEquals(source, m_OwnedSource))
            {
                m_OwnedSource.Dispose();
                m_OwnedSource = null;
            }

            m_Source = source;
        }

        void Update()
        {
            if (m_Source == null || m_Recognizer == null)
                return;
            m_Source.Collect(m_Samples);
            if (m_Samples.Count == 0 && m_Recognizer.ScenePointerCount == 0 && m_Recognizer.UiPointerCount == 0)
                return;
            m_Recognizer.Process(m_Samples, Time.unscaledTime);
        }

        /// <summary>True when a UI graphic with raycastTarget enabled lies under <paramref name="screenPosition"/>.</summary>
        public bool IsOverUI(Vector2 screenPosition)
        {
            var eventSystem = m_EventSystem != null ? m_EventSystem : EventSystem.current;
            if (eventSystem == null)
                return false;

            if (m_PointerData == null || m_PointerDataOwner != eventSystem)
            {
                m_PointerData = new PointerEventData(eventSystem);
                m_PointerDataOwner = eventSystem;
            }

            m_PointerData.Reset();
            m_PointerData.position = screenPosition;
            m_UiHits.Clear();
            eventSystem.RaycastAll(m_PointerData, m_UiHits);
            return m_UiHits.Count > 0;
        }

        float ComputeDragThresholdPixels()
        {
            var dpi = Screen.dpi > 1f ? Screen.dpi : 160f;
            return Mathf.Max(8f, dpi * m_DragThresholdInches);
        }
    }
}
