using System;
using System.Collections.Generic;
using UnityEngine;

namespace ARInterior.Interaction
{
    /// <summary>Receives recognised scene gestures. Implemented by the InteractionController.</summary>
    public interface ISceneGestureHandler
    {
        void OnTap(Vector2 screenPosition);

        /// <summary>Return false to reject the drag; the recogniser then ignores the finger until it lifts.</summary>
        bool OnDragBegin(Vector2 startPosition, Vector2 currentPosition);

        /// <summary>Return false when the drag was cancelled elsewhere (mode change, deletion, tracking loss).</summary>
        bool OnDragUpdate(Vector2 screenPosition);

        void OnDragEnd();
        void OnDragCancel();
        bool OnTwoFingerBegin(Vector2 first, Vector2 second);
        bool OnTwoFingerUpdate(Vector2 first, Vector2 second);
        void OnTwoFingerEnd();
    }

    /// <summary>
    /// Turns raw pointer samples into tap / drag / two-finger gestures. Pointers that start on the UI
    /// are ignored for their whole lifetime, so UI touches can never leak into the scene. Exactly one
    /// gesture is active at a time; adding a second finger ends a drag before a pinch starts, and after
    /// any multi-finger gesture the recogniser waits until every finger has lifted.
    /// </summary>
    public sealed class GestureRecognizer
    {
        public enum State
        {
            Idle,
            Pending,
            Dragging,
            TwoFinger,
            WaitingForRelease
        }

        readonly ISceneGestureHandler m_Handler;
        readonly Func<Vector2, bool> m_IsOverUI;
        readonly HashSet<int> m_UiPointers = new HashSet<int>();
        readonly Dictionary<int, Vector2> m_ScenePointers = new Dictionary<int, Vector2>();
        readonly List<int> m_SceneOrder = new List<int>();
        readonly HashSet<int> m_SeenThisFrame = new HashSet<int>();
        readonly List<int> m_Missing = new List<int>();

        State m_State = State.Idle;
        int m_PrimaryId;
        int m_SecondaryId;
        Vector2 m_PrimaryStart;
        float m_PrimaryStartTime;
        bool m_Dirty;
        bool m_TwoFingerStartedThisFrame;

        public GestureRecognizer(ISceneGestureHandler handler, Func<Vector2, bool> isOverUI)
        {
            m_Handler = handler ?? throw new ArgumentNullException(nameof(handler));
            m_IsOverUI = isOverUI ?? (_ => false);
        }

        public State CurrentState => m_State;
        public float TapMaxDuration { get; set; } = 0.45f;
        public float DragThresholdPixels { get; set; } = 12f;
        public int ScenePointerCount => m_ScenePointers.Count;
        public int UiPointerCount => m_UiPointers.Count;

        public void Process(IReadOnlyList<PointerSample> samples, float time)
        {
            m_Dirty = false;
            m_TwoFingerStartedThisFrame = false;
            m_SeenThisFrame.Clear();

            for (var i = 0; i < samples.Count; i++)
            {
                var sample = samples[i];
                m_SeenThisFrame.Add(sample.Id);
                switch (sample.Phase)
                {
                    case PointerPhase.Began:
                        PointerDown(sample.Id, sample.Position, time);
                        break;
                    case PointerPhase.Moved:
                    case PointerPhase.Stationary:
                        PointerMove(sample.Id, sample.Position, time);
                        break;
                    case PointerPhase.Ended:
                        PointerUp(sample.Id, sample.Position, false, time);
                        break;
                    case PointerPhase.Canceled:
                        PointerUp(sample.Id, sample.Position, true, time);
                        break;
                }
            }

            CancelVanishedPointers(time);
            FlushContinuousUpdate();
        }

        /// <summary>Abandons any gesture in progress (application paused, component disabled).</summary>
        public void Reset()
        {
            switch (m_State)
            {
                case State.Dragging:
                    m_Handler.OnDragCancel();
                    break;
                case State.TwoFinger:
                    m_Handler.OnTwoFingerEnd();
                    break;
            }

            m_UiPointers.Clear();
            m_ScenePointers.Clear();
            m_SceneOrder.Clear();
            m_State = State.Idle;
        }

        void PointerDown(int id, Vector2 position, float time)
        {
            if (m_UiPointers.Contains(id) || m_ScenePointers.ContainsKey(id))
            {
                PointerMove(id, position, time);
                return;
            }

            if (m_IsOverUI(position))
            {
                m_UiPointers.Add(id);
                return;
            }

            m_ScenePointers[id] = position;
            m_SceneOrder.Add(id);

            switch (m_State)
            {
                case State.Idle:
                    m_State = State.Pending;
                    m_PrimaryId = id;
                    m_PrimaryStart = position;
                    m_PrimaryStartTime = time;
                    break;
                case State.Pending:
                    TryStartTwoFinger();
                    break;
                case State.Dragging:
                    m_Handler.OnDragEnd();
                    TryStartTwoFinger();
                    break;
            }
        }

        void PointerMove(int id, Vector2 position, float time)
        {
            if (!m_ScenePointers.ContainsKey(id))
                return;
            m_ScenePointers[id] = position;

            if (m_State == State.Pending && id == m_PrimaryId)
            {
                if ((position - m_PrimaryStart).magnitude > DragThresholdPixels)
                {
                    if (m_Handler.OnDragBegin(m_PrimaryStart, position))
                    {
                        m_State = State.Dragging;
                        m_Dirty = true;
                    }
                    else
                    {
                        m_State = State.WaitingForRelease;
                    }
                }
            }
            else if ((m_State == State.Dragging && id == m_PrimaryId) ||
                     (m_State == State.TwoFinger && (id == m_PrimaryId || id == m_SecondaryId)))
            {
                m_Dirty = true;
            }
        }

        void PointerUp(int id, Vector2 position, bool cancelled, float time)
        {
            if (m_UiPointers.Remove(id))
                return;
            if (!m_ScenePointers.Remove(id))
                return;
            m_SceneOrder.Remove(id);

            switch (m_State)
            {
                case State.Pending when id == m_PrimaryId:
                    if (!cancelled && time - m_PrimaryStartTime <= TapMaxDuration &&
                        (position - m_PrimaryStart).magnitude <= DragThresholdPixels)
                    {
                        m_Handler.OnTap(position);
                    }

                    m_State = m_ScenePointers.Count > 0 ? State.WaitingForRelease : State.Idle;
                    break;
                case State.Dragging when id == m_PrimaryId:
                    if (cancelled)
                        m_Handler.OnDragCancel();
                    else
                        m_Handler.OnDragEnd();
                    m_Dirty = false;
                    m_State = m_ScenePointers.Count > 0 ? State.WaitingForRelease : State.Idle;
                    break;
                case State.TwoFinger when id == m_PrimaryId || id == m_SecondaryId:
                    m_Handler.OnTwoFingerEnd();
                    m_Dirty = false;
                    m_State = m_ScenePointers.Count > 0 ? State.WaitingForRelease : State.Idle;
                    break;
                case State.WaitingForRelease:
                    if (m_ScenePointers.Count == 0)
                        m_State = State.Idle;
                    break;
            }
        }

        void TryStartTwoFinger()
        {
            if (m_SceneOrder.Count < 2)
                return;
            m_PrimaryId = m_SceneOrder[0];
            m_SecondaryId = m_SceneOrder[1];
            if (m_Handler.OnTwoFingerBegin(m_ScenePointers[m_PrimaryId], m_ScenePointers[m_SecondaryId]))
            {
                m_State = State.TwoFinger;
                // The pinch starts from this frame's positions; updates begin next frame regardless of sample order.
                m_TwoFingerStartedThisFrame = true;
            }
            else
            {
                m_State = State.WaitingForRelease;
            }
        }

        void CancelVanishedPointers(float time)
        {
            if (m_ScenePointers.Count == 0 && m_UiPointers.Count == 0)
                return;

            m_Missing.Clear();
            foreach (var id in m_ScenePointers.Keys)
            {
                if (!m_SeenThisFrame.Contains(id))
                    m_Missing.Add(id);
            }

            foreach (var id in m_UiPointers)
            {
                if (!m_SeenThisFrame.Contains(id))
                    m_Missing.Add(id);
            }

            foreach (var id in m_Missing)
            {
                var position = m_ScenePointers.TryGetValue(id, out var last) ? last : Vector2.zero;
                PointerUp(id, position, true, time);
            }
        }

        void FlushContinuousUpdate()
        {
            if (!m_Dirty || m_TwoFingerStartedThisFrame)
                return;
            m_Dirty = false;

            if (m_State == State.Dragging && m_ScenePointers.TryGetValue(m_PrimaryId, out var position))
            {
                if (!m_Handler.OnDragUpdate(position))
                    m_State = State.WaitingForRelease;
            }
            else if (m_State == State.TwoFinger &&
                     m_ScenePointers.TryGetValue(m_PrimaryId, out var first) &&
                     m_ScenePointers.TryGetValue(m_SecondaryId, out var second))
            {
                if (!m_Handler.OnTwoFingerUpdate(first, second))
                    m_State = State.WaitingForRelease;
            }
        }
    }
}
