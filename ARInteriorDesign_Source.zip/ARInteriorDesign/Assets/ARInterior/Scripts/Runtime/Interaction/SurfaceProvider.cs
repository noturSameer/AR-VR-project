using ARInterior.Furniture;
using UnityEngine;

namespace ARInterior.Interaction
{
    /// <summary>Result of casting a screen point against a placeable surface.</summary>
    public readonly struct SurfaceHit
    {
        public SurfaceHit(Pose pose, Component surface, float distance)
        {
            Pose = pose;
            Surface = surface;
            Distance = distance;
        }

        public Pose Pose { get; }

        /// <summary>The surface that was hit (an ARPlane in AR mode, a Collider in demo mode).</summary>
        public Component Surface { get; }

        public float Distance { get; }
    }

    /// <summary>
    /// Abstraction over "where can furniture stand". The AR scene uses detected AR planes and anchors,
    /// the demo scene uses physics colliders of a virtual room. Everything else is shared.
    /// </summary>
    public abstract class SurfaceProvider : MonoBehaviour
    {
        [Tooltip("Parent for placed furniture that is not attached to an anchor.")]
        [SerializeField] Transform m_PlacedObjectsRoot;

        public Transform PlacedObjectsRoot => m_PlacedObjectsRoot;

        /// <summary>True once at least one placeable surface exists.</summary>
        public abstract bool HasSurfaces { get; }

        public abstract bool TryRaycast(Vector2 screenPosition, out SurfaceHit hit);

        /// <summary>Called after placement or a surface drag: keep <paramref name="item"/> attached to <paramref name="surface"/>.</summary>
        public virtual void AttachToSurface(PlacedFurniture item, Component surface) => ParentToRoot(item);

        /// <summary>Called after a free (axis) move: keep the item where it is.</summary>
        public virtual void AttachInPlace(PlacedFurniture item) => ParentToRoot(item);

        /// <summary>Called before the item is destroyed: release anchors or other per-item resources.</summary>
        public virtual void Release(PlacedFurniture item) => ParentToRoot(item);

        public void SetPlacedObjectsRoot(Transform root) => m_PlacedObjectsRoot = root;

        protected void ParentToRoot(PlacedFurniture item)
        {
            if (item == null)
                return;
            if (item.transform.parent != m_PlacedObjectsRoot)
                item.transform.SetParent(m_PlacedObjectsRoot, true);
        }
    }
}
