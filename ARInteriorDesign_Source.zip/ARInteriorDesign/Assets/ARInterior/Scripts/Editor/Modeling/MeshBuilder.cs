using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace ARInterior.EditorTools.Modeling
{
    /// <summary>
    /// Small procedural modelling toolkit used to author the furniture meshes. All primitives are emitted
    /// directly in the model's space (pivot = centre of the footprint on the floor, +Z = front).
    /// UVs are planar/cylindrical in metres so textures keep a consistent real-world scale.
    /// <see cref="ToMesh"/> bakes averaged ("smoothed") normals into UV channel 3 for the outline shader.
    /// </summary>
    public sealed class MeshBuilder
    {
        readonly List<Vector3> m_Vertices = new List<Vector3>();
        readonly List<Vector3> m_Normals = new List<Vector3>();
        readonly List<Vector2> m_Uvs = new List<Vector2>();
        readonly List<int> m_Triangles = new List<int>();

        public int VertexCount => m_Vertices.Count;
        public int TriangleCount => m_Triangles.Count / 3;
        public IReadOnlyList<Vector3> Vertices => m_Vertices;
        public IReadOnlyList<Vector3> Normals => m_Normals;
        public IReadOnlyList<int> Triangles => m_Triangles;

        int AddVertex(Vector3 position, Vector3 normal, Vector2 uv)
        {
            m_Vertices.Add(position);
            m_Normals.Add(normal);
            m_Uvs.Add(uv);
            return m_Vertices.Count - 1;
        }

        void AddTriangle(int a, int b, int c)
        {
            m_Triangles.Add(a);
            m_Triangles.Add(b);
            m_Triangles.Add(c);
        }

        /// <summary>Axis-aligned (then rotated) box with hard edges.</summary>
        public void AddBox(Vector3 center, Vector3 size, Quaternion rotation)
        {
            var h = size * 0.5f;
            // Each face: normal, tangent (u), bitangent (v).
            AddBoxFace(center, rotation, Vector3.right, Vector3.forward, Vector3.up, h.x, h.z, h.y);
            AddBoxFace(center, rotation, Vector3.left, Vector3.back, Vector3.up, h.x, h.z, h.y);
            AddBoxFace(center, rotation, Vector3.up, Vector3.right, Vector3.forward, h.y, h.x, h.z);
            AddBoxFace(center, rotation, Vector3.down, Vector3.right, Vector3.back, h.y, h.x, h.z);
            AddBoxFace(center, rotation, Vector3.forward, Vector3.left, Vector3.up, h.z, h.x, h.y);
            AddBoxFace(center, rotation, Vector3.back, Vector3.right, Vector3.up, h.z, h.x, h.y);
        }

        public void AddBox(Vector3 center, Vector3 size) => AddBox(center, size, Quaternion.identity);

        void AddBoxFace(Vector3 center, Quaternion rotation, Vector3 normal, Vector3 u, Vector3 v,
            float normalExtent, float uExtent, float vExtent)
        {
            var faceCenter = normal * normalExtent;
            var corners = new[]
            {
                faceCenter - u * uExtent - v * vExtent,
                faceCenter + u * uExtent - v * vExtent,
                faceCenter + u * uExtent + v * vExtent,
                faceCenter - u * uExtent + v * vExtent
            };
            var uvs = new[]
            {
                new Vector2(-uExtent, -vExtent),
                new Vector2(uExtent, -vExtent),
                new Vector2(uExtent, vExtent),
                new Vector2(-uExtent, vExtent)
            };
            var worldNormal = rotation * normal;
            var start = m_Vertices.Count;
            for (var i = 0; i < 4; i++)
                AddVertex(center + rotation * corners[i], worldNormal, uvs[i]);

            // Unity treats a triangle (a, b, c) as front-facing when cross(b - a, c - a) points outwards.
            if (Vector3.Dot(Vector3.Cross(u, v), normal) > 0f)
            {
                AddTriangle(start, start + 1, start + 2);
                AddTriangle(start, start + 2, start + 3);
            }
            else
            {
                AddTriangle(start, start + 2, start + 1);
                AddTriangle(start, start + 3, start + 2);
            }
        }

        /// <summary>
        /// Box with rounded edges and corners (cushions, table tops). Built as a subdivided cube whose
        /// vertices are pushed onto an inner box offset by <paramref name="radius"/>.
        /// </summary>
        public void AddRoundedBox(Vector3 center, Vector3 size, float radius, int segments, Quaternion rotation)
        {
            var h = size * 0.5f;
            var r = Mathf.Clamp(radius, 0.0005f, Mathf.Min(h.x, Mathf.Min(h.y, h.z)) * 0.999f);
            segments = Mathf.Clamp(segments, 1, 12);
            var inner = h - Vector3.one * r;

            var xs = RoundedCoordinates(h.x, r, segments);
            var ys = RoundedCoordinates(h.y, r, segments);
            var zs = RoundedCoordinates(h.z, r, segments);

            AddRoundedFace(center, rotation, inner, r, 0, 1f, h.x, zs, ys);
            AddRoundedFace(center, rotation, inner, r, 0, -1f, h.x, zs, ys);
            AddRoundedFace(center, rotation, inner, r, 1, 1f, h.y, xs, zs);
            AddRoundedFace(center, rotation, inner, r, 1, -1f, h.y, xs, zs);
            AddRoundedFace(center, rotation, inner, r, 2, 1f, h.z, xs, ys);
            AddRoundedFace(center, rotation, inner, r, 2, -1f, h.z, xs, ys);
        }

        public void AddRoundedBox(Vector3 center, Vector3 size, float radius, int segments = 4) =>
            AddRoundedBox(center, size, radius, segments, Quaternion.identity);

        static List<float> RoundedCoordinates(float half, float radius, int segments)
        {
            // Grid lines spaced so the projected arc angles are uniform: x = (h - r) + r * tan(phi).
            var coordinates = new List<float>();
            for (var k = segments; k >= 0; k--)
                coordinates.Add(-(half - radius) - radius * Mathf.Tan(Mathf.PI * 0.25f * k / segments));
            for (var k = 0; k <= segments; k++)
            {
                var value = (half - radius) + radius * Mathf.Tan(Mathf.PI * 0.25f * k / segments);
                if (value - coordinates[coordinates.Count - 1] > 1e-6f)
                    coordinates.Add(value);
            }

            return coordinates;
        }

        void AddRoundedFace(Vector3 center, Quaternion rotation, Vector3 inner, float r, int axis, float sign,
            float extent, List<float> aCoords, List<float> bCoords)
        {
            // Face plane is perpendicular to 'axis'; a/b run along the two other axes.
            int axisA, axisB;
            switch (axis)
            {
                case 0:
                    axisA = 2;
                    axisB = 1;
                    break;
                case 1:
                    axisA = 0;
                    axisB = 2;
                    break;
                default:
                    axisA = 0;
                    axisB = 1;
                    break;
            }

            var start = m_Vertices.Count;
            var columns = aCoords.Count;
            for (var j = 0; j < bCoords.Count; j++)
            {
                for (var i = 0; i < columns; i++)
                {
                    var p = Vector3.zero;
                    p[axis] = sign * extent;
                    p[axisA] = aCoords[i];
                    p[axisB] = bCoords[j];
                    var clamped = new Vector3(
                        Mathf.Clamp(p.x, -inner.x, inner.x),
                        Mathf.Clamp(p.y, -inner.y, inner.y),
                        Mathf.Clamp(p.z, -inner.z, inner.z));
                    var normal = (p - clamped).normalized;
                    var position = clamped + normal * r;
                    var uv = new Vector2(position[axisA], position[axisB]);
                    AddVertex(center + rotation * position, rotation * normal, uv);
                }
            }

            // Grid triangle (a, b, c) faces along cross(A, B); flip it when that points inwards.
            var aDir = Vector3.zero;
            aDir[axisA] = 1f;
            var bDir = Vector3.zero;
            bDir[axisB] = 1f;
            var outward = Vector3.zero;
            outward[axis] = sign;
            var flip = Vector3.Dot(Vector3.Cross(aDir, bDir), outward) < 0f;

            for (var j = 0; j < bCoords.Count - 1; j++)
            {
                for (var i = 0; i < columns - 1; i++)
                {
                    var a = start + j * columns + i;
                    var b = a + 1;
                    var c = a + columns + 1;
                    var d = a + columns;
                    if (flip)
                    {
                        AddTriangle(a, c, b);
                        AddTriangle(a, d, c);
                    }
                    else
                    {
                        AddTriangle(a, b, c);
                        AddTriangle(a, c, d);
                    }
                }
            }
        }

        /// <summary>
        /// Truncated cone along the local +Y axis starting at <paramref name="baseCenter"/>. A cylinder when
        /// both radii match, a cone when <paramref name="topRadius"/> is zero.
        /// </summary>
        public void AddFrustum(Vector3 baseCenter, float bottomRadius, float topRadius, float height, int segments,
            bool capBottom, bool capTop, Quaternion rotation, bool doubleSided = false)
        {
            segments = Mathf.Max(3, segments);
            var slope = (bottomRadius - topRadius) / Mathf.Max(height, 1e-5f);
            var averageRadius = (bottomRadius + topRadius) * 0.5f;
            var circumference = 2f * Mathf.PI * averageRadius;

            for (var side = 0; side < (doubleSided ? 2 : 1); side++)
            {
                var inward = side == 1;
                var start = m_Vertices.Count;
                for (var i = 0; i <= segments; i++)
                {
                    var angle = 2f * Mathf.PI * i / segments;
                    var dir = new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle));
                    var normal = new Vector3(dir.x, slope, dir.z).normalized;
                    if (inward)
                        normal = -normal;
                    var u = circumference * i / segments;
                    AddVertex(baseCenter + rotation * (dir * bottomRadius), rotation * normal, new Vector2(u, 0f));
                    AddVertex(baseCenter + rotation * (dir * topRadius + Vector3.up * height), rotation * normal,
                        new Vector2(u, height));
                }

                for (var i = 0; i < segments; i++)
                {
                    var b0 = start + i * 2;
                    var t0 = b0 + 1;
                    var b1 = b0 + 2;
                    var t1 = b0 + 3;
                    if (inward)
                    {
                        AddTriangle(b0, b1, t0);
                        AddTriangle(t0, b1, t1);
                    }
                    else
                    {
                        AddTriangle(b0, t0, b1);
                        AddTriangle(t0, t1, b1);
                    }
                }
            }

            if (capBottom && bottomRadius > 1e-5f)
                AddDisc(baseCenter, bottomRadius, segments, false, rotation);
            if (capTop && topRadius > 1e-5f)
                AddDisc(baseCenter + rotation * (Vector3.up * height), topRadius, segments, true, rotation);
        }

        public void AddCylinder(Vector3 baseCenter, float radius, float height, int segments, bool caps = true) =>
            AddFrustum(baseCenter, radius, radius, height, segments, caps, caps, Quaternion.identity);

        public void AddDisc(Vector3 center, float radius, int segments, bool facingUp, Quaternion rotation)
        {
            var normal = rotation * (facingUp ? Vector3.up : Vector3.down);
            var hub = AddVertex(center, normal, Vector2.zero);
            var start = m_Vertices.Count;
            for (var i = 0; i <= segments; i++)
            {
                var angle = 2f * Mathf.PI * i / segments;
                var local = new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle)) * radius;
                AddVertex(center + rotation * local, normal, new Vector2(local.x, local.z));
            }

            for (var i = 0; i < segments; i++)
            {
                if (facingUp)
                    AddTriangle(hub, start + i + 1, start + i);
                else
                    AddTriangle(hub, start + i, start + i + 1);
            }
        }

        public void AddSphere(Vector3 center, float radius, int longitude, int latitude)
        {
            longitude = Mathf.Max(3, longitude);
            latitude = Mathf.Max(2, latitude);
            var start = m_Vertices.Count;
            for (var lat = 0; lat <= latitude; lat++)
            {
                var theta = Mathf.PI * lat / latitude;
                for (var lon = 0; lon <= longitude; lon++)
                {
                    var phi = 2f * Mathf.PI * lon / longitude;
                    var normal = new Vector3(Mathf.Sin(theta) * Mathf.Cos(phi), Mathf.Cos(theta),
                        Mathf.Sin(theta) * Mathf.Sin(phi));
                    AddVertex(center + normal * radius, normal,
                        new Vector2(phi * radius, theta * radius));
                }
            }

            var stride = longitude + 1;
            for (var lat = 0; lat < latitude; lat++)
            {
                for (var lon = 0; lon < longitude; lon++)
                {
                    var a = start + lat * stride + lon;
                    var b = a + stride;
                    AddTriangle(a, a + 1, b);
                    AddTriangle(a + 1, b + 1, b);
                }
            }
        }

        /// <summary>Appends another builder's geometry, transformed by <paramref name="matrix"/>.</summary>
        public void Append(MeshBuilder other, Matrix4x4 matrix)
        {
            var offset = m_Vertices.Count;
            for (var i = 0; i < other.m_Vertices.Count; i++)
            {
                m_Vertices.Add(matrix.MultiplyPoint3x4(other.m_Vertices[i]));
                m_Normals.Add(matrix.MultiplyVector(other.m_Normals[i]).normalized);
                m_Uvs.Add(other.m_Uvs[i]);
            }

            foreach (var index in other.m_Triangles)
                m_Triangles.Add(index + offset);
        }

        public Bounds CalculateBounds()
        {
            if (m_Vertices.Count == 0)
                return new Bounds();
            var bounds = new Bounds(m_Vertices[0], Vector3.zero);
            foreach (var v in m_Vertices)
                bounds.Encapsulate(v);
            return bounds;
        }

        /// <summary>Averaged normals of all vertices sharing a position (hard edges are merged).</summary>
        public List<Vector3> ComputeSmoothedNormals()
        {
            var sums = new Dictionary<Vector3Int, Vector3>();
            var keys = new Vector3Int[m_Vertices.Count];
            for (var i = 0; i < m_Vertices.Count; i++)
            {
                var p = m_Vertices[i];
                var key = new Vector3Int(Mathf.RoundToInt(p.x * 10000f), Mathf.RoundToInt(p.y * 10000f),
                    Mathf.RoundToInt(p.z * 10000f));
                keys[i] = key;
                sums.TryGetValue(key, out var sum);
                sums[key] = sum + m_Normals[i];
            }

            var smoothed = new List<Vector3>(m_Vertices.Count);
            for (var i = 0; i < m_Vertices.Count; i++)
            {
                var n = sums[keys[i]];
                smoothed.Add(n.sqrMagnitude > 1e-8f ? n.normalized : m_Normals[i]);
            }

            return smoothed;
        }

        /// <summary>Writes the geometry into <paramref name="mesh"/> (cleared first, so asset references survive).</summary>
        public void WriteTo(Mesh mesh, bool includeWhiteVertexColors = false)
        {
            mesh.Clear();
            mesh.indexFormat = m_Vertices.Count > 65000 ? IndexFormat.UInt32 : IndexFormat.UInt16;
            mesh.SetVertices(m_Vertices);
            mesh.SetNormals(m_Normals);
            mesh.SetUVs(0, m_Uvs);
            mesh.SetUVs(3, ComputeSmoothedNormals());
            if (includeWhiteVertexColors)
            {
                var colors = new List<Color32>(m_Vertices.Count);
                for (var i = 0; i < m_Vertices.Count; i++)
                    colors.Add(new Color32(255, 255, 255, 255));
                mesh.SetColors(colors);
            }

            mesh.SetTriangles(m_Triangles, 0, true);
            mesh.RecalculateTangents();
            mesh.RecalculateBounds();
        }

        public Mesh ToMesh(string name, bool includeWhiteVertexColors = false)
        {
            var mesh = new Mesh { name = name };
            WriteTo(mesh, includeWhiteVertexColors);
            return mesh;
        }
    }
}
