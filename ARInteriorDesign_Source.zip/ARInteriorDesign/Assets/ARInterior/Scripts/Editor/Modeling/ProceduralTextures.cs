using UnityEngine;

namespace ARInterior.EditorTools.Modeling
{
    /// <summary>
    /// Deterministic texture generators (wood grain, fabric weave, brushed metal, linen, floor planks).
    /// Textures are mostly neutral in colour so materials can tint them with _BaseColor. The same seed
    /// always produces identical pixels, keeping the setup wizard idempotent.
    /// </summary>
    public static class ProceduralTextures
    {
        public static Color[] WoodGrain(int size, int seed, float ringFrequency, float contrast)
        {
            var pixels = new Color[size * size];
            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var u = (float)x / size;
                    var v = (float)y / size;
                    var warp = TileableNoise(u * 3f, v * 0.6f, 3, 1, seed) * 0.35f;
                    var rings = Mathf.Sin((u + warp) * Mathf.PI * 2f * ringFrequency);
                    var grain = TileableNoise(u * 48f, v * 2f, 48, 2, seed + 7) - 0.5f;
                    var value = 0.78f + rings * 0.08f * contrast + grain * 0.10f * contrast;
                    var tint = new Color(1f, 0.93f, 0.84f);
                    pixels[y * size + x] = tint * Mathf.Clamp01(value);
                }
            }

            return pixels;
        }

        public static Color[] FabricWeave(int size, int seed, int threads)
        {
            var pixels = new Color[size * size];
            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var u = (float)x / size;
                    var v = (float)y / size;
                    var warp = Mathf.Sin(u * Mathf.PI * 2f * threads);
                    var weft = Mathf.Sin(v * Mathf.PI * 2f * threads);
                    var cell = ((Mathf.FloorToInt(u * threads * 2f) + Mathf.FloorToInt(v * threads * 2f)) & 1) == 0;
                    var thread = cell ? warp : weft;
                    var fuzz = TileableNoise(u * 64f, v * 64f, 64, 64, seed) - 0.5f;
                    var mottle = TileableNoise(u * 4f, v * 4f, 4, 4, seed + 3) - 0.5f;
                    var value = 0.82f + thread * 0.05f + fuzz * 0.10f + mottle * 0.06f;
                    pixels[y * size + x] = Color.white * Mathf.Clamp01(value);
                }
            }

            return pixels;
        }

        public static Color[] BrushedMetal(int size, int seed)
        {
            var pixels = new Color[size * size];
            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var u = (float)x / size;
                    var v = (float)y / size;
                    var streaks = TileableNoise(u * 2f, v * 96f, 2, 96, seed) - 0.5f;
                    var fine = TileableNoise(u * 32f, v * 256f, 32, 256, seed + 11) - 0.5f;
                    var value = 0.80f + streaks * 0.12f + fine * 0.06f;
                    pixels[y * size + x] = Color.white * Mathf.Clamp01(value);
                }
            }

            return pixels;
        }

        public static Color[] Linen(int size, int seed)
        {
            var pixels = new Color[size * size];
            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var u = (float)x / size;
                    var v = (float)y / size;
                    var slub = TileableNoise(u * 128f, v * 6f, 128, 6, seed) - 0.5f;
                    var cross = TileableNoise(u * 6f, v * 128f, 6, 128, seed + 5) - 0.5f;
                    var value = 0.88f + slub * 0.10f + cross * 0.08f;
                    pixels[y * size + x] = Color.white * Mathf.Clamp01(value);
                }
            }

            return pixels;
        }

        /// <summary>Floor planks for the demo room (warm oak, 4 planks across the texture).</summary>
        public static Color[] FloorPlanks(int size, int seed)
        {
            var pixels = new Color[size * size];
            const int planks = 4;
            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var u = (float)x / size;
                    var v = (float)y / size;
                    var plank = Mathf.FloorToInt(u * planks);
                    var local = u * planks - plank;
                    var offset = Hash(plank, 0, seed) * 0.7f;
                    var lengthwise = Mathf.Repeat(v + offset, 1f);
                    var seam = Mathf.Min(local, 1f - local) < 0.012f || lengthwise < 0.006f;
                    var grain = TileableNoise(u * 64f, v * 3f, 64, 3, seed + plank) - 0.5f;
                    var shade = 0.82f + (Hash(plank, 1, seed) - 0.5f) * 0.14f + grain * 0.12f;
                    var c = new Color(0.78f, 0.60f, 0.42f) * Mathf.Clamp01(shade);
                    if (seam)
                        c *= 0.55f;
                    c.a = 1f;
                    pixels[y * size + x] = c;
                }
            }

            return pixels;
        }

        public static Color Average(Color[] pixels)
        {
            var sum = Color.clear;
            foreach (var p in pixels)
                sum += p;
            return pixels.Length > 0 ? sum / pixels.Length : Color.white;
        }

        public static Texture2D ToTexture(Color[] pixels, int size)
        {
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.SetPixels(pixels);
            texture.Apply(false, false);
            return texture;
        }

        /// <summary>Value noise that tiles with the given integer periods.</summary>
        static float TileableNoise(float x, float y, int periodX, int periodY, int seed)
        {
            var x0 = Mathf.FloorToInt(x);
            var y0 = Mathf.FloorToInt(y);
            var fx = x - x0;
            var fy = y - y0;
            var sx = fx * fx * (3f - 2f * fx);
            var sy = fy * fy * (3f - 2f * fy);
            float Corner(int ix, int iy) => Hash(Mod(ix, periodX), Mod(iy, periodY), seed);
            var top = Mathf.Lerp(Corner(x0, y0), Corner(x0 + 1, y0), sx);
            var bottom = Mathf.Lerp(Corner(x0, y0 + 1), Corner(x0 + 1, y0 + 1), sx);
            return Mathf.Lerp(top, bottom, sy);
        }

        static int Mod(int value, int period) => period <= 0 ? value : ((value % period) + period) % period;

        static float Hash(int x, int y, int seed)
        {
            unchecked
            {
                var h = (uint)(x * 374761393 + y * 668265263 + seed * 1442695041);
                h = (h ^ (h >> 13)) * 1274126177u;
                h ^= h >> 16;
                return (h & 0x00FFFFFF) / 16777215f;
            }
        }
    }
}
