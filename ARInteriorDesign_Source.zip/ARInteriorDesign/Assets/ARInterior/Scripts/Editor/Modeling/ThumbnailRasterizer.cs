using System.Collections.Generic;
using UnityEngine;

namespace ARInterior.EditorTools.Modeling
{
    /// <summary>
    /// CPU rasteriser that renders catalogue thumbnails straight from the generated geometry. It needs no
    /// GPU, camera or scene, so it works identically in batch mode and keeps thumbnails deterministic.
    /// Orthographic three-quarter view from the front-right (models face +Z), z-buffer, Lambert + ambient
    /// shading, 2× supersampling.
    /// </summary>
    public static class ThumbnailRasterizer
    {
        public static Texture2D Render(IReadOnlyList<(MeshBuilder geometry, Color color)> parts, int size,
            float yawDegrees = 215f, float pitchDegrees = 22f)
        {
            const int supersample = 2;
            var n = size * supersample;
            var colorBuffer = new Color[n * n];
            var depthBuffer = new float[n * n];
            for (var i = 0; i < depthBuffer.Length; i++)
                depthBuffer[i] = float.MaxValue;

            var view = Quaternion.Inverse(Quaternion.Euler(pitchDegrees, yawDegrees, 0f));
            var light = (view * new Vector3(-0.4f, 0.8f, 0.5f)).normalized;

            // Fit the projected bounds into the image with a margin.
            var min = new Vector2(float.MaxValue, float.MaxValue);
            var max = new Vector2(float.MinValue, float.MinValue);
            foreach (var (geometry, _) in parts)
            {
                foreach (var v in geometry.Vertices)
                {
                    var p = view * v;
                    min = Vector2.Min(min, new Vector2(p.x, p.y));
                    max = Vector2.Max(max, new Vector2(p.x, p.y));
                }
            }

            var extent = Mathf.Max(max.x - min.x, max.y - min.y);
            if (extent <= 0f)
                return new Texture2D(size, size, TextureFormat.RGBA32, false);
            var scale = n * 0.84f / extent;
            var center = (min + max) * 0.5f;
            var offset = new Vector2(n * 0.5f, n * 0.5f);

            foreach (var (geometry, color) in parts)
            {
                var vertices = geometry.Vertices;
                var triangles = geometry.Triangles;
                for (var t = 0; t < triangles.Count; t += 3)
                {
                    var a = view * vertices[triangles[t]];
                    var b = view * vertices[triangles[t + 1]];
                    var c = view * vertices[triangles[t + 2]];
                    var normal = Vector3.Cross(b - a, c - a).normalized;
                    var shade = 0.42f + 0.58f * Mathf.Abs(Vector3.Dot(normal, light));
                    var shaded = new Color(color.r * shade, color.g * shade, color.b * shade, 1f);
                    RasterTriangle(Project(a), Project(b), Project(c), a.z, b.z, c.z, shaded, colorBuffer, depthBuffer, n);
                }
            }

            Vector2 Project(Vector3 p) => (new Vector2(p.x, p.y) - center) * scale + offset;

            var output = new Color[size * size];
            for (var y = 0; y < size; y++)
            {
                for (var x = 0; x < size; x++)
                {
                    var sum = Color.clear;
                    for (var sy = 0; sy < supersample; sy++)
                    {
                        for (var sx = 0; sx < supersample; sx++)
                            sum += colorBuffer[(y * supersample + sy) * n + x * supersample + sx];
                    }

                    var averaged = sum / (supersample * supersample);
                    // Un-premultiply colour so edges blend cleanly over the card background.
                    if (averaged.a > 0f)
                    {
                        averaged.r /= averaged.a;
                        averaged.g /= averaged.a;
                        averaged.b /= averaged.a;
                    }

                    output[y * size + x] = averaged;
                }
            }

            var texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.SetPixels(output);
            texture.Apply(false, false);
            return texture;
        }

        static void RasterTriangle(Vector2 a, Vector2 b, Vector2 c, float za, float zb, float zc, Color color,
            Color[] colorBuffer, float[] depthBuffer, int n)
        {
            var minX = Mathf.Max(0, Mathf.FloorToInt(Mathf.Min(a.x, Mathf.Min(b.x, c.x))));
            var maxX = Mathf.Min(n - 1, Mathf.CeilToInt(Mathf.Max(a.x, Mathf.Max(b.x, c.x))));
            var minY = Mathf.Max(0, Mathf.FloorToInt(Mathf.Min(a.y, Mathf.Min(b.y, c.y))));
            var maxY = Mathf.Min(n - 1, Mathf.CeilToInt(Mathf.Max(a.y, Mathf.Max(b.y, c.y))));
            var area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
            if (Mathf.Abs(area) < 1e-6f)
                return;

            for (var y = minY; y <= maxY; y++)
            {
                for (var x = minX; x <= maxX; x++)
                {
                    var p = new Vector2(x + 0.5f, y + 0.5f);
                    var w0 = ((b.x - p.x) * (c.y - p.y) - (b.y - p.y) * (c.x - p.x)) / area;
                    var w1 = ((c.x - p.x) * (a.y - p.y) - (c.y - p.y) * (a.x - p.x)) / area;
                    var w2 = 1f - w0 - w1;
                    if (w0 < 0f || w1 < 0f || w2 < 0f)
                        continue;
                    var depth = w0 * za + w1 * zb + w2 * zc;
                    var index = y * n + x;
                    // View space looks down +Z, so a smaller z is closer to the viewer.
                    if (depth >= depthBuffer[index])
                        continue;
                    depthBuffer[index] = depth;
                    colorBuffer[index] = color;
                }
            }
        }
    }
}
