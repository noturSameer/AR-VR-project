using System.Collections.Generic;
using UnityEngine;

namespace ARInterior.EditorTools.Modeling
{
    /// <summary>One named component of a furniture model (e.g. "Legs") rendered with one material.</summary>
    public sealed class FurniturePart
    {
        public FurniturePart(string name, string materialKey, MeshBuilder geometry)
        {
            Name = name;
            MaterialKey = materialKey;
            Geometry = geometry;
        }

        public string Name { get; }
        public string MaterialKey { get; }
        public MeshBuilder Geometry { get; }
    }

    /// <summary>Full description of a generated furniture model.</summary>
    public sealed class FurnitureModel
    {
        public string Id;
        public string DisplayName;
        public string Description;
        public Vector3 Dimensions;
        public float MinScale = 0.5f;
        public float MaxScale = 2f;
        public readonly List<FurniturePart> Parts = new List<FurniturePart>();

        public FurniturePart AddPart(string name, string materialKey)
        {
            var part = new FurniturePart(name, materialKey, new MeshBuilder());
            Parts.Add(part);
            return part;
        }

        public Bounds CalculateBounds()
        {
            var hasBounds = false;
            var bounds = new Bounds();
            foreach (var part in Parts)
            {
                if (part.Geometry.VertexCount == 0)
                    continue;
                var b = part.Geometry.CalculateBounds();
                if (!hasBounds)
                {
                    bounds = b;
                    hasBounds = true;
                }
                else
                {
                    bounds.Encapsulate(b);
                }
            }

            return bounds;
        }
    }

    /// <summary>
    /// Procedural definitions of the five catalogue models. Units are metres; the pivot is the centre of
    /// the footprint at floor level and the front of each model faces +Z.
    /// </summary>
    public static class FurnitureFactory
    {
        public const string ModernChairId = "modern-chair";
        public const string DiningTableId = "dining-table";
        public const string SofaId = "sofa";
        public const string FloorLampId = "floor-lamp";
        public const string BookshelfId = "bookshelf";

        public static List<FurnitureModel> CreateAll() => new List<FurnitureModel>
        {
            ModernChair(),
            DiningTable(),
            Sofa(),
            FloorLamp(),
            Bookshelf()
        };

        public static FurnitureModel ModernChair()
        {
            var model = new FurnitureModel
            {
                Id = ModernChairId,
                DisplayName = "Modern Chair",
                Description = "Upholstered dining chair with splayed oak legs.",
                Dimensions = new Vector3(0.48f, 0.82f, 0.52f)
            };

            var legs = model.AddPart("Legs", MaterialKeys.WoodOak).Geometry;
            foreach (var sx in new[] { -1f, 1f })
            {
                foreach (var sz in new[] { -1f, 1f })
                {
                    var foot = new Vector3(sx * 0.215f, 0f, sz * 0.215f);
                    var top = new Vector3(sx * 0.185f, 0.405f, sz * 0.185f);
                    AddStrut(legs, foot, top, 0.014f, 0.019f, 14);
                }
            }

            model.AddPart("SeatFrame", MaterialKeys.WoodOak).Geometry
                .AddRoundedBox(new Vector3(0f, 0.41f, 0f), new Vector3(0.42f, 0.03f, 0.42f), 0.008f, 2);

            model.AddPart("Seat", MaterialKeys.FabricMustard).Geometry
                .AddRoundedBox(new Vector3(0f, 0.452f, 0.012f), new Vector3(0.48f, 0.06f, 0.47f), 0.025f, 4);

            var backTilt = Quaternion.Euler(-10f, 0f, 0f);
            var supports = model.AddPart("BackSupports", MaterialKeys.WoodOak).Geometry;
            foreach (var sx in new[] { -1f, 1f })
            {
                var start = new Vector3(sx * 0.185f, 0.42f, -0.19f);
                supports.AddFrustum(start, 0.012f, 0.012f, 0.33f, 12, true, true, backTilt);
            }

            model.AddPart("Backrest", MaterialKeys.FabricMustard).Geometry
                .AddRoundedBox(new Vector3(0f, 0.665f, -0.215f), new Vector3(0.46f, 0.28f, 0.045f), 0.02f, 4, backTilt);

            return model;
        }

        public static FurnitureModel DiningTable()
        {
            var model = new FurnitureModel
            {
                Id = DiningTableId,
                DisplayName = "Dining Table",
                Description = "Six-seat walnut table on a black steel frame.",
                Dimensions = new Vector3(1.60f, 0.75f, 0.90f),
                MinScale = 0.5f,
                MaxScale = 1.6f
            };

            model.AddPart("Tabletop", MaterialKeys.WoodWalnut).Geometry
                .AddRoundedBox(new Vector3(0f, 0.73f, 0f), new Vector3(1.60f, 0.04f, 0.90f), 0.012f, 3);

            var apron = model.AddPart("Apron", MaterialKeys.MetalBlack).Geometry;
            apron.AddBox(new Vector3(0f, 0.675f, 0.38f), new Vector3(1.38f, 0.07f, 0.02f));
            apron.AddBox(new Vector3(0f, 0.675f, -0.38f), new Vector3(1.38f, 0.07f, 0.02f));
            apron.AddBox(new Vector3(0.70f, 0.675f, 0f), new Vector3(0.02f, 0.07f, 0.74f));
            apron.AddBox(new Vector3(-0.70f, 0.675f, 0f), new Vector3(0.02f, 0.07f, 0.74f));

            var legs = model.AddPart("Legs", MaterialKeys.MetalBlack).Geometry;
            foreach (var sx in new[] { -1f, 1f })
            {
                foreach (var sz in new[] { -1f, 1f })
                    legs.AddBox(new Vector3(sx * 0.72f, 0.355f, sz * 0.37f), new Vector3(0.05f, 0.71f, 0.05f));
            }

            var feet = model.AddPart("Feet", MaterialKeys.WoodWalnut).Geometry;
            foreach (var sx in new[] { -1f, 1f })
            {
                foreach (var sz in new[] { -1f, 1f })
                    feet.AddCylinder(new Vector3(sx * 0.72f, 0f, sz * 0.37f), 0.026f, 0.012f, 16);
            }

            return model;
        }

        public static FurnitureModel Sofa()
        {
            var model = new FurnitureModel
            {
                Id = SofaId,
                DisplayName = "Sofa",
                Description = "Three-seat sofa with removable cushions.",
                Dimensions = new Vector3(2.00f, 0.85f, 0.90f),
                MinScale = 0.5f,
                MaxScale = 1.5f
            };

            var legs = model.AddPart("Legs", MaterialKeys.WoodWalnut).Geometry;
            foreach (var sx in new[] { -1f, 1f })
            {
                foreach (var sz in new[] { -1f, 1f })
                    legs.AddFrustum(new Vector3(sx * 0.90f, 0f, sz * 0.37f), 0.016f, 0.024f, 0.11f, 14, true, true,
                        Quaternion.identity);
            }

            model.AddPart("BaseFrame", MaterialKeys.FabricTeal).Geometry
                .AddRoundedBox(new Vector3(0f, 0.22f, 0f), new Vector3(2.0f, 0.24f, 0.90f), 0.03f, 3);

            var arms = model.AddPart("Armrests", MaterialKeys.FabricTeal).Geometry;
            foreach (var sx in new[] { -1f, 1f })
                arms.AddRoundedBox(new Vector3(sx * 0.91f, 0.375f, 0f), new Vector3(0.18f, 0.55f, 0.90f), 0.05f, 4);

            model.AddPart("Backrest", MaterialKeys.FabricTeal).Geometry
                .AddRoundedBox(new Vector3(0f, 0.59f, -0.36f), new Vector3(1.64f, 0.52f, 0.18f), 0.05f, 4);

            var seatCushions = model.AddPart("SeatCushions", MaterialKeys.FabricTealLight).Geometry;
            var backCushions = model.AddPart("BackCushions", MaterialKeys.FabricTealLight).Geometry;
            var cushionTilt = Quaternion.Euler(-12f, 0f, 0f);
            foreach (var x in new[] { -0.545f, 0f, 0.545f })
            {
                seatCushions.AddRoundedBox(new Vector3(x, 0.41f, 0.07f), new Vector3(0.535f, 0.14f, 0.64f), 0.05f, 4);
                backCushions.AddRoundedBox(new Vector3(x, 0.63f, -0.205f), new Vector3(0.52f, 0.36f, 0.14f), 0.06f, 4,
                    cushionTilt);
            }

            return model;
        }

        public static FurnitureModel FloorLamp()
        {
            var model = new FurnitureModel
            {
                Id = FloorLampId,
                DisplayName = "Floor Lamp",
                Description = "Brass floor lamp with a linen drum shade.",
                Dimensions = new Vector3(0.44f, 1.65f, 0.44f),
                MinScale = 0.6f,
                MaxScale = 1.5f
            };

            model.AddPart("Base", MaterialKeys.MetalBlack).Geometry
                .AddFrustum(Vector3.zero, 0.15f, 0.135f, 0.028f, 40, true, true, Quaternion.identity);

            model.AddPart("Pole", MaterialKeys.MetalBrass).Geometry
                .AddCylinder(new Vector3(0f, 0.028f, 0f), 0.011f, 1.372f, 16);

            model.AddPart("Switch", MaterialKeys.MetalBlack).Geometry
                .AddRoundedBox(new Vector3(0f, 0.95f, 0.018f), new Vector3(0.028f, 0.055f, 0.022f), 0.006f, 2);

            var shadeFrame = model.AddPart("ShadeFrame", MaterialKeys.MetalBrass).Geometry;
            shadeFrame.AddCylinder(new Vector3(0f, 1.38f, 0f), 0.028f, 0.05f, 20);
            for (var i = 0; i < 3; i++)
            {
                var angle = i * 120f;
                var rotation = Quaternion.Euler(0f, angle, 0f);
                shadeFrame.AddBox(rotation * new Vector3(0.112f, 1.425f, 0f), new Vector3(0.17f, 0.006f, 0.006f), rotation);
            }

            model.AddPart("Bulb", MaterialKeys.BulbGlow).Geometry
                .AddSphere(new Vector3(0f, 1.475f, 0f), 0.045f, 20, 12);

            model.AddPart("Shade", MaterialKeys.LinenShade).Geometry
                .AddFrustum(new Vector3(0f, 1.32f, 0f), 0.22f, 0.15f, 0.33f, 48, false, false, Quaternion.identity, true);

            return model;
        }

        public static FurnitureModel Bookshelf()
        {
            var model = new FurnitureModel
            {
                Id = BookshelfId,
                DisplayName = "Bookshelf",
                Description = "Oak bookcase with four shelves and books.",
                Dimensions = new Vector3(0.80f, 1.80f, 0.30f),
                MinScale = 0.5f,
                MaxScale = 1.3f
            };

            var carcass = model.AddPart("Carcass", MaterialKeys.WoodOak).Geometry;
            carcass.AddBox(new Vector3(-0.39f, 0.90f, 0f), new Vector3(0.02f, 1.80f, 0.30f));
            carcass.AddBox(new Vector3(0.39f, 0.90f, 0f), new Vector3(0.02f, 1.80f, 0.30f));
            carcass.AddBox(new Vector3(0f, 1.79f, 0f), new Vector3(0.76f, 0.02f, 0.30f));
            carcass.AddBox(new Vector3(0f, 0.03f, 0.005f), new Vector3(0.76f, 0.06f, 0.28f));

            var shelfHeights = new[] { 0.07f, 0.49f, 0.91f, 1.33f };
            var shelves = model.AddPart("Shelves", MaterialKeys.WoodOak).Geometry;
            foreach (var y in shelfHeights)
                shelves.AddBox(new Vector3(0f, y, 0.005f), new Vector3(0.76f, 0.02f, 0.28f));

            model.AddPart("BackPanel", MaterialKeys.WoodWalnut).Geometry
                .AddBox(new Vector3(0f, 0.92f, -0.144f), new Vector3(0.76f, 1.74f, 0.012f));

            var bookParts = new[]
            {
                model.AddPart("BooksRed", MaterialKeys.BookRed).Geometry,
                model.AddPart("BooksNavy", MaterialKeys.BookNavy).Geometry,
                model.AddPart("BooksCream", MaterialKeys.BookCream).Geometry,
                model.AddPart("BooksGreen", MaterialKeys.BookGreen).Geometry
            };

            // Deterministic pseudo-random rows of books (same result on every run).
            var random = new System.Random(20261023);
            for (var shelf = 0; shelf < shelfHeights.Length; shelf++)
            {
                var surface = shelfHeights[shelf] + 0.01f;
                var x = -0.37f;
                var rowEnd = shelf == shelfHeights.Length - 1 ? 0.12f : 0.30f - (float)random.NextDouble() * 0.12f;
                var colour = random.Next(bookParts.Length);
                while (true)
                {
                    var width = 0.024f + (float)random.NextDouble() * 0.026f;
                    if (x + width > rowEnd)
                        break;
                    var height = 0.19f + (float)random.NextDouble() * 0.12f;
                    var depth = 0.17f + (float)random.NextDouble() * 0.06f;
                    bookParts[colour].AddBox(new Vector3(x + width * 0.5f, surface + height * 0.5f, 0.135f - depth * 0.5f),
                        new Vector3(width, height, depth));
                    x += width + 0.002f;
                    colour = (colour + 1 + random.Next(2)) % bookParts.Length;
                }
            }

            var decor = model.AddPart("Vase", MaterialKeys.CeramicWhite).Geometry;
            decor.AddFrustum(new Vector3(0.25f, 1.34f, 0f), 0.045f, 0.06f, 0.12f, 24, true, false, Quaternion.identity);
            decor.AddFrustum(new Vector3(0.25f, 1.46f, 0f), 0.06f, 0.03f, 0.05f, 24, false, true, Quaternion.identity);

            return model;
        }

        /// <summary>Tapered round strut between two points (chair legs).</summary>
        static void AddStrut(MeshBuilder builder, Vector3 from, Vector3 to, float bottomRadius, float topRadius, int segments)
        {
            var direction = to - from;
            var rotation = Quaternion.FromToRotation(Vector3.up, direction.normalized);
            builder.AddFrustum(from, bottomRadius, topRadius, direction.magnitude, segments, true, true, rotation);
        }
    }

    /// <summary>Material identifiers shared by the model factory and the material library.</summary>
    public static class MaterialKeys
    {
        public const string WoodOak = "WoodOak";
        public const string WoodWalnut = "WoodWalnut";
        public const string FabricMustard = "FabricMustard";
        public const string FabricTeal = "FabricTeal";
        public const string FabricTealLight = "FabricTealLight";
        public const string MetalBlack = "MetalBlack";
        public const string MetalBrass = "MetalBrass";
        public const string LinenShade = "LinenShade";
        public const string BulbGlow = "BulbGlow";
        public const string BookRed = "BookRed";
        public const string BookNavy = "BookNavy";
        public const string BookCream = "BookCream";
        public const string BookGreen = "BookGreen";
        public const string CeramicWhite = "CeramicWhite";
    }
}
