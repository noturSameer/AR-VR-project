using UnityEngine;

namespace ARInterior.EditorTools.Modeling
{
    /// <summary>
    /// Anti-aliased signed-distance painter used to generate the white UI icons and 9-slice sprites.
    /// Coordinates are in pixels with the origin at the bottom-left.
    /// </summary>
    public sealed class IconPainter
    {
        readonly int m_Size;
        readonly float[] m_Alpha;

        public IconPainter(int size)
        {
            m_Size = size;
            m_Alpha = new float[size * size];
        }

        public int Size => m_Size;

        void Stamp(System.Func<Vector2, float> signedDistance, bool erase = false)
        {
            for (var y = 0; y < m_Size; y++)
            {
                for (var x = 0; x < m_Size; x++)
                {
                    var d = signedDistance(new Vector2(x + 0.5f, y + 0.5f));
                    var coverage = Mathf.Clamp01(0.5f - d);
                    var i = y * m_Size + x;
                    m_Alpha[i] = erase ? Mathf.Min(m_Alpha[i], 1f - coverage) : Mathf.Max(m_Alpha[i], coverage);
                }
            }
        }

        public void Line(Vector2 a, Vector2 b, float thickness, bool erase = false)
        {
            var r = thickness * 0.5f;
            Stamp(p =>
            {
                var pa = p - a;
                var ba = b - a;
                var h = Mathf.Clamp01(Vector2.Dot(pa, ba) / Mathf.Max(ba.sqrMagnitude, 1e-5f));
                return (pa - ba * h).magnitude - r;
            }, erase);
        }

        public void Circle(Vector2 center, float radius, bool erase = false) =>
            Stamp(p => (p - center).magnitude - radius, erase);

        public void Ring(Vector2 center, float radius, float thickness, float startDegrees, float endDegrees)
        {
            var half = thickness * 0.5f;
            Stamp(p =>
            {
                var d = p - center;
                var angle = Mathf.Atan2(d.y, d.x) * Mathf.Rad2Deg;
                if (angle < 0f)
                    angle += 360f;
                var inArc = startDegrees <= endDegrees
                    ? angle >= startDegrees && angle <= endDegrees
                    : angle >= startDegrees || angle <= endDegrees;
                if (!inArc)
                    return float.MaxValue;
                return Mathf.Abs(d.magnitude - radius) - half;
            });
        }

        public void Triangle(Vector2 a, Vector2 b, Vector2 c)
        {
            Stamp(p =>
            {
                float Edge(Vector2 e0, Vector2 e1)
                {
                    var e = e1 - e0;
                    var n = new Vector2(e.y, -e.x).normalized;
                    return Vector2.Dot(p - e0, n);
                }

                var orientation = Mathf.Sign((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x));
                // Edge() is negative on the left of an edge, i.e. inside a counter-clockwise triangle.
                var d = Mathf.Max(Edge(a, b) * orientation, Mathf.Max(Edge(b, c) * orientation, Edge(c, a) * orientation));
                return d;
            });
        }

        public void RoundedRect(Vector2 min, Vector2 max, float radius, bool erase = false)
        {
            var center = (min + max) * 0.5f;
            var half = (max - min) * 0.5f;
            Stamp(p =>
            {
                var q = new Vector2(Mathf.Abs(p.x - center.x), Mathf.Abs(p.y - center.y)) - half + Vector2.one * radius;
                var outside = new Vector2(Mathf.Max(q.x, 0f), Mathf.Max(q.y, 0f)).magnitude;
                return outside + Mathf.Min(Mathf.Max(q.x, q.y), 0f) - radius;
            }, erase);
        }

        public void RoundedRectOutline(Vector2 min, Vector2 max, float radius, float thickness)
        {
            RoundedRect(min, max, radius);
            RoundedRect(min + Vector2.one * thickness, max - Vector2.one * thickness, Mathf.Max(0f, radius - thickness), true);
        }

        /// <summary>Arrow head pointing from <paramref name="from"/> towards <paramref name="tip"/>.</summary>
        public void ArrowHead(Vector2 tip, Vector2 from, float length, float width)
        {
            var dir = (tip - from).normalized;
            var normal = new Vector2(-dir.y, dir.x);
            var baseCenter = tip - dir * length;
            Triangle(tip, baseCenter + normal * width * 0.5f, baseCenter - normal * width * 0.5f);
        }

        public Texture2D ToTexture(Color tint)
        {
            var texture = new Texture2D(m_Size, m_Size, TextureFormat.RGBA32, false);
            var pixels = new Color[m_Alpha.Length];
            for (var i = 0; i < m_Alpha.Length; i++)
                pixels[i] = new Color(tint.r, tint.g, tint.b, tint.a * m_Alpha[i]);
            texture.SetPixels(pixels);
            texture.Apply(false, false);
            return texture;
        }

        public float AlphaAt(int x, int y) => m_Alpha[y * m_Size + x];
    }
}
