using ARInterior.AR;
using ARInterior.Core;
using ARInterior.Demo;
using ARInterior.EditorTools.Modeling;
using ARInterior.Furniture;
using ARInterior.Interaction;
using ARInterior.Rendering;
using ARInterior.UI;
using Unity.XR.CoreUtils;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>Everything the scene builders need, produced by earlier setup steps.</summary>
    public sealed class SceneContext
    {
        public FurnitureCatalog Catalog;
        public Material OutlineMaterial;
        public Material MaskMaterial;
        public Material GizmoMaterial;
        public GameObject PlanePrefab;
        public Mesh GizmoArrowMesh;
        public MaterialLibrary.Result Materials;
        public UIBuilder.Style UIStyle;
    }

    /// <summary>
    /// Generates MainARScene (AR Foundation session, XR Origin, plane detection, anchors) and DemoScene
    /// (virtual room for the Editor and non-AR devices). Both share the same interaction systems and HUD.
    /// Scenes are rebuilt from scratch on every run, so repeated runs never duplicate objects.
    /// </summary>
    public static class SceneBuilder
    {
        static readonly Color GizmoX = new Color(0.95f, 0.27f, 0.27f);
        static readonly Color GizmoY = new Color(0.36f, 0.86f, 0.36f);
        static readonly Color GizmoZ = new Color(0.32f, 0.56f, 1f);

        public static void BuildMainARScene(SceneContext context)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            ConfigureLighting(new Color(0.62f, 0.62f, 0.64f), new Color(0.5f, 0.5f, 0.5f), new Color(0.32f, 0.3f, 0.28f));

            new GameObject("AR Session", typeof(ARSession), typeof(ARInputManager));

            var originGo = new GameObject("XR Origin (AR)", typeof(XROrigin), typeof(ARPlaneManager),
                typeof(ARRaycastManager), typeof(ARAnchorManager));
            var offset = new GameObject("Camera Offset");
            offset.transform.SetParent(originGo.transform, false);
            var camera = CreateARCamera(offset.transform);
            var origin = originGo.GetComponent<XROrigin>();
            origin.CameraFloorOffsetObject = offset;
            origin.Camera = camera;

            var planeManager = originGo.GetComponent<ARPlaneManager>();
            planeManager.planePrefab = context.PlanePrefab;
            planeManager.requestedDetectionMode = PlaneDetectionMode.Horizontal;
            var raycastManager = originGo.GetComponent<ARRaycastManager>();
            var anchorManager = originGo.GetComponent<ARAnchorManager>();

            CreateSun();

            var placedRoot = new GameObject("Placed Furniture").transform;
            var app = new GameObject("AR Interior App");
            var status = app.AddComponent<ARSessionStatusProvider>();
            status.Configure(planeManager);
            var surfaces = app.AddComponent<ARPlaneSurfaceProvider>();
            surfaces.Configure(raycastManager, planeManager, anchorManager);
            surfaces.SetPlacedObjectsRoot(placedRoot);

            BuildSharedSystems(context, app, camera, surfaces, status, SetupPaths.DemoSceneName, "Demo");
            EditorSceneManager.SaveScene(scene, SetupPaths.MainScene);
        }

        public static void BuildDemoScene(SceneContext context)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            ConfigureLighting(new Color(0.70f, 0.72f, 0.76f), new Color(0.52f, 0.50f, 0.47f), new Color(0.30f, 0.27f, 0.24f));

            var cameraGo = new GameObject("Main Camera", typeof(Camera), typeof(UniversalAdditionalCameraData),
                typeof(DemoCameraController));
            cameraGo.tag = "MainCamera";
            var camera = cameraGo.GetComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.11f, 0.12f, 0.14f);
            camera.nearClipPlane = 0.05f;
            camera.farClipPlane = 60f;
            camera.fieldOfView = 55f;
            cameraGo.transform.SetPositionAndRotation(new Vector3(1.4f, 3.47f, 3.85f), Quaternion.Euler(35f, 200f, 0f));

            CreateSun();
            BuildDemoRoom(context);

            var placedRoot = new GameObject("Placed Furniture").transform;
            var app = new GameObject("AR Interior App");
            var status = app.AddComponent<DemoStatusProvider>();
            var surfaces = app.AddComponent<PhysicsSurfaceProvider>();
            surfaces.Configure(camera, 1 << SetupPaths.DemoSurfaceLayer);
            surfaces.SetPlacedObjectsRoot(placedRoot);

            BuildSharedSystems(context, app, camera, surfaces, status, SetupPaths.MainSceneName, "AR");
            EditorSceneManager.SaveScene(scene, SetupPaths.DemoScene);
        }

        static void BuildSharedSystems(SceneContext context, GameObject app, Camera camera, SurfaceProvider surfaces,
            ExperienceStatusProvider status, string alternateScene, string alternateLabel)
        {
            var transformer = app.AddComponent<TransformController>();
            var outline = app.AddComponent<SelectionOutline>();
            outline.Configure(context.OutlineMaterial, context.MaskMaterial, SetupPaths.OutlineColor, 5f);
            var selection = app.AddComponent<SelectionManager>();
            SerializedFields.Set(selection, "m_Outline", outline);

            // NewScene unloads unreferenced assets, so reload the catalogue instead of reusing a stale handle.
            var catalog = AssetDatabase.LoadAssetAtPath<FurnitureCatalog>(SetupPaths.Catalog);
            if (catalog == null)
                throw new System.InvalidOperationException($"Furniture catalogue not found at {SetupPaths.Catalog}.");

            var placement = app.AddComponent<PlacementController>();
            SerializedFields.Set(placement, "m_Catalog", catalog);
            SerializedFields.Set(placement, "m_SurfaceProvider", surfaces);
            SerializedFields.Set(placement, "m_Camera", camera);

            var gizmo = BuildMoveGizmo(context, camera);

            var interaction = app.AddComponent<InteractionController>();
            SerializedFields.Set(interaction, "m_Camera", camera);
            SerializedFields.Set(interaction, "m_SurfaceProvider", surfaces);
            SerializedFields.Set(interaction, "m_StatusProvider", status);
            SerializedFields.Set(interaction, "m_Selection", selection);
            SerializedFields.Set(interaction, "m_Transformer", transformer);
            SerializedFields.Set(interaction, "m_Placement", placement);
            SerializedFields.Set(interaction, "m_MoveGizmo", gizmo);
            SerializedFields.SetMask(interaction, "m_FurnitureMask", 1 << SetupPaths.FurnitureLayer);

            var router = app.AddComponent<TouchInputRouter>();
            SerializedFields.Set(router, "m_Interaction", interaction);

            var eventSystem = UIBuilder.CreateEventSystem();
            SerializedFields.Set(router, "m_EventSystem", eventSystem);
            UIBuilder.Build(context.UIStyle, interaction, catalog, alternateScene, alternateLabel);
        }

        static Camera CreateARCamera(Transform parent)
        {
            var cameraGo = new GameObject("Main Camera", typeof(Camera), typeof(UniversalAdditionalCameraData),
                typeof(ARCameraManager), typeof(ARCameraBackground), typeof(TrackedPoseDriver));
            cameraGo.transform.SetParent(parent, false);
            cameraGo.tag = "MainCamera";
            var camera = cameraGo.GetComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = Color.black;
            camera.nearClipPlane = 0.05f;
            camera.farClipPlane = 30f;

            // Same bindings as AR Foundation's "XR Origin (Mobile AR)" menu item.
            var trackedPoseDriver = cameraGo.GetComponent<TrackedPoseDriver>();
            var positionAction = new InputAction("Position", binding: "<XRHMD>/centerEyePosition", expectedControlType: "Vector3");
            positionAction.AddBinding("<HandheldARInputDevice>/devicePosition");
            var rotationAction = new InputAction("Rotation", binding: "<XRHMD>/centerEyeRotation", expectedControlType: "Quaternion");
            rotationAction.AddBinding("<HandheldARInputDevice>/deviceRotation");
            trackedPoseDriver.positionInput = new InputActionProperty(positionAction);
            trackedPoseDriver.rotationInput = new InputActionProperty(rotationAction);
            return camera;
        }

        static void CreateSun()
        {
            var lightGo = new GameObject("Directional Light", typeof(Light));
            var light = lightGo.GetComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.15f;
            light.color = new Color(1f, 0.97f, 0.92f);
            light.shadows = LightShadows.Soft;
            light.shadowStrength = 0.6f;
            lightGo.transform.rotation = Quaternion.Euler(52f, -35f, 0f);
        }

        static void ConfigureLighting(Color sky, Color equator, Color ground)
        {
            RenderSettings.skybox = null;
            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = sky;
            RenderSettings.ambientEquatorColor = equator;
            RenderSettings.ambientGroundColor = ground;
            RenderSettings.fog = false;
        }

        static AxisGizmo BuildMoveGizmo(SceneContext context, Camera camera)
        {
            var root = new GameObject("Move Gizmo");
            root.layer = SetupPaths.GizmoLayer;
            var gizmo = root.AddComponent<AxisGizmo>();
            var handles = new[]
            {
                CreateHandle(root.transform, context, TransformAxis.X, Quaternion.Euler(0f, 0f, -90f), GizmoX),
                CreateHandle(root.transform, context, TransformAxis.Y, Quaternion.identity, GizmoY),
                CreateHandle(root.transform, context, TransformAxis.Z, Quaternion.Euler(90f, 0f, 0f), GizmoZ)
            };
            gizmo.Configure(camera, handles, 1 << SetupPaths.GizmoLayer);
            root.SetActive(false);
            return gizmo;
        }

        static AxisHandle CreateHandle(Transform parent, SceneContext context, TransformAxis axis, Quaternion rotation, Color color)
        {
            var go = new GameObject($"Handle {axis}", typeof(MeshFilter), typeof(MeshRenderer), typeof(CapsuleCollider));
            go.layer = SetupPaths.GizmoLayer;
            go.transform.SetParent(parent, false);
            go.transform.localRotation = rotation;
            go.GetComponent<MeshFilter>().sharedMesh = context.GizmoArrowMesh;
            var meshRenderer = go.GetComponent<MeshRenderer>();
            meshRenderer.sharedMaterial = context.GizmoMaterial;
            meshRenderer.shadowCastingMode = ShadowCastingMode.Off;
            meshRenderer.receiveShadows = false;
            var capsule = go.GetComponent<CapsuleCollider>();
            capsule.isTrigger = true;
            capsule.direction = 1;
            capsule.center = new Vector3(0f, 0.6f, 0f);
            capsule.height = 1.0f;
            capsule.radius = 0.16f;
            var handle = go.AddComponent<AxisHandle>();
            handle.Configure(axis, meshRenderer, color, SetupPaths.OutlineColor);
            return handle;
        }

        static void BuildDemoRoom(SceneContext context)
        {
            var room = new GameObject("Demo Room");
            var floor = new MeshBuilder();
            floor.AddBox(new Vector3(0f, -0.01f, 0f), new Vector3(6f, 0.02f, 6f));
            var rug = new MeshBuilder();
            rug.AddRoundedBox(new Vector3(0f, 0.004f, 0.4f), new Vector3(2.6f, 0.008f, 1.8f), 0.003f, 1);
            var walls = new MeshBuilder();
            walls.AddBox(new Vector3(0f, 1.3f, -3.05f), new Vector3(6.2f, 2.6f, 0.1f));
            walls.AddBox(new Vector3(-3.05f, 1.3f, 0f), new Vector3(0.1f, 2.6f, 6.2f));
            var skirting = new MeshBuilder();
            skirting.AddBox(new Vector3(0f, 0.05f, -2.99f), new Vector3(6.0f, 0.1f, 0.02f));
            skirting.AddBox(new Vector3(-2.99f, 0.05f, 0f), new Vector3(0.02f, 0.1f, 6.0f));

            var meshes = AssetUtility.WriteMeshAsset(SetupPaths.DemoRoomMesh, new (string, System.Action<Mesh>)[]
            {
                ("DemoRoom_Floor", m => floor.WriteTo(m)),
                ("DemoRoom_Rug", m => rug.WriteTo(m)),
                ("DemoRoom_Walls", m => walls.WriteTo(m)),
                ("DemoRoom_Skirting", m => skirting.WriteTo(m))
            });

            var floorGo = CreateStatic("Floor", room.transform, meshes["DemoRoom_Floor"], context.Materials.Materials[MaterialLibrary.DemoFloorKey]);
            floorGo.layer = SetupPaths.DemoSurfaceLayer;
            var floorCollider = floorGo.AddComponent<BoxCollider>();
            floorCollider.center = new Vector3(0f, -0.01f, 0f);
            floorCollider.size = new Vector3(6f, 0.02f, 6f);

            var rugGo = CreateStatic("Rug", room.transform, meshes["DemoRoom_Rug"], context.Materials.Materials[MaterialLibrary.DemoRugKey]);
            rugGo.layer = SetupPaths.DemoSurfaceLayer;
            var rugCollider = rugGo.AddComponent<BoxCollider>();
            rugCollider.center = new Vector3(0f, 0.004f, 0.4f);
            rugCollider.size = new Vector3(2.6f, 0.008f, 1.8f);

            CreateStatic("Walls", room.transform, meshes["DemoRoom_Walls"], context.Materials.Materials[MaterialLibrary.DemoWallKey]);
            CreateStatic("Skirting", room.transform, meshes["DemoRoom_Skirting"], context.Materials.Materials[MaterialKeys.WoodWalnut]);
        }

        static GameObject CreateStatic(string name, Transform parent, Mesh mesh, Material material)
        {
            var go = new GameObject(name, typeof(MeshFilter), typeof(MeshRenderer));
            go.transform.SetParent(parent, false);
            go.GetComponent<MeshFilter>().sharedMesh = mesh;
            var meshRenderer = go.GetComponent<MeshRenderer>();
            meshRenderer.sharedMaterial = material;
            meshRenderer.shadowCastingMode = ShadowCastingMode.On;
            meshRenderer.receiveShadows = true;
            return go;
        }

        /// <summary>AR plane prefab: ARPlane + mesh visualiser with the grid material and a boundary line.</summary>
        public static GameObject BuildPlanePrefab(Material gridMaterial, Material lineMaterial)
        {
            var go = new GameObject("AR Plane Visualizer", typeof(ARPlane), typeof(ARPlaneMeshVisualizer),
                typeof(MeshFilter), typeof(MeshRenderer), typeof(LineRenderer));
            try
            {
                var meshRenderer = go.GetComponent<MeshRenderer>();
                meshRenderer.sharedMaterial = gridMaterial;
                meshRenderer.shadowCastingMode = ShadowCastingMode.Off;
                meshRenderer.receiveShadows = false;

                var line = go.GetComponent<LineRenderer>();
                line.sharedMaterials = new[] { lineMaterial };
                line.loop = true;
                line.useWorldSpace = false;
                line.widthMultiplier = 0.006f;
                line.numCornerVertices = 4;
                line.numCapVertices = 4;
                line.startColor = new Color(1f, 0.85f, 0.5f, 0.9f);
                line.endColor = new Color(1f, 0.85f, 0.5f, 0.9f);
                line.shadowCastingMode = ShadowCastingMode.Off;
                line.receiveShadows = false;

                AssetUtility.EnsureFolder(SetupPaths.ARPrefabs);
                var prefab = PrefabUtility.SaveAsPrefabAsset(go, SetupPaths.PlanePrefab, out var success);
                if (!success)
                    throw new System.InvalidOperationException("Saving the AR plane prefab failed.");
                return prefab;
            }
            finally
            {
                Object.DestroyImmediate(go);
            }
        }

        public static Mesh BuildGizmoArrowMesh()
        {
            var arrow = new MeshBuilder();
            arrow.AddCylinder(new Vector3(0f, 0.15f, 0f), 0.035f, 0.68f, 12);
            arrow.AddFrustum(new Vector3(0f, 0.83f, 0f), 0.095f, 0f, 0.27f, 16, true, false, Quaternion.identity);
            var meshes = AssetUtility.WriteMeshAsset(SetupPaths.GizmoMesh, new (string, System.Action<Mesh>)[]
            {
                ("MoveGizmoArrow", m => arrow.WriteTo(m, true))
            });
            return meshes["MoveGizmoArrow"];
        }

        public static Scene OpenScene(string path) => EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
    }
}
