using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>Idempotent asset helpers: every method updates an existing asset in place instead of duplicating it.</summary>
    public static class AssetUtility
    {
        public static void EnsureFolder(string assetPath)
        {
            assetPath = assetPath.TrimEnd('/');
            if (AssetDatabase.IsValidFolder(assetPath))
                return;
            var parent = Path.GetDirectoryName(assetPath)?.Replace('\\', '/');
            var leaf = Path.GetFileName(assetPath);
            if (!string.IsNullOrEmpty(parent) && !AssetDatabase.IsValidFolder(parent))
                EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, leaf);
        }

        public static string ToFullPath(string assetPath) =>
            Path.GetFullPath(Path.Combine(Application.dataPath, "..", assetPath));

        /// <summary>Writes a PNG only when its bytes changed, then (re)imports it.</summary>
        public static void WritePng(string assetPath, Texture2D texture)
        {
            EnsureFolder(Path.GetDirectoryName(assetPath)?.Replace('\\', '/'));
            var bytes = texture.EncodeToPNG();
            var fullPath = ToFullPath(assetPath);
            var unchanged = File.Exists(fullPath) && FilesEqual(File.ReadAllBytes(fullPath), bytes);
            if (!unchanged)
                File.WriteAllBytes(fullPath, bytes);
            AssetDatabase.ImportAsset(assetPath, unchanged ? ImportAssetOptions.Default : ImportAssetOptions.ForceUpdate);
        }

        static bool FilesEqual(byte[] a, byte[] b)
        {
            if (a.Length != b.Length)
                return false;
            for (var i = 0; i < a.Length; i++)
            {
                if (a[i] != b[i])
                    return false;
            }

            return true;
        }

        public static void ConfigureAlbedoTexture(string assetPath, int maxSize)
        {
            var importer = (TextureImporter)AssetImporter.GetAtPath(assetPath);
            var dirty = importer.textureType != TextureImporterType.Default || !importer.sRGBTexture ||
                        !importer.mipmapEnabled || importer.wrapMode != TextureWrapMode.Repeat ||
                        importer.maxTextureSize != maxSize;
            if (!dirty)
                return;
            importer.textureType = TextureImporterType.Default;
            importer.sRGBTexture = true;
            importer.mipmapEnabled = true;
            importer.wrapMode = TextureWrapMode.Repeat;
            importer.filterMode = FilterMode.Trilinear;
            importer.anisoLevel = 2;
            importer.maxTextureSize = maxSize;
            importer.SaveAndReimport();
        }

        public static void ConfigureSprite(string assetPath, Vector4 border, int maxSize = 512)
        {
            var importer = (TextureImporter)AssetImporter.GetAtPath(assetPath);
            var dirty = importer.textureType != TextureImporterType.Sprite || importer.spriteBorder != border ||
                        importer.mipmapEnabled || importer.maxTextureSize != maxSize ||
                        importer.spriteImportMode != SpriteImportMode.Single;
            if (!dirty)
                return;
            importer.textureType = TextureImporterType.Sprite;
            importer.spriteImportMode = SpriteImportMode.Single;
            importer.spriteBorder = border;
            importer.mipmapEnabled = false;
            importer.alphaIsTransparency = true;
            importer.wrapMode = TextureWrapMode.Clamp;
            importer.filterMode = FilterMode.Bilinear;
            importer.maxTextureSize = maxSize;
            importer.SaveAndReimport();
        }

        public static T LoadOrCreateAsset<T>(string assetPath) where T : ScriptableObject
        {
            var existing = AssetDatabase.LoadAssetAtPath<T>(assetPath);
            if (existing != null)
                return existing;
            EnsureFolder(Path.GetDirectoryName(assetPath)?.Replace('\\', '/'));
            var created = ScriptableObject.CreateInstance<T>();
            AssetDatabase.CreateAsset(created, assetPath);
            return created;
        }

        public static Material LoadOrCreateMaterial(string assetPath, Shader shader)
        {
            var material = AssetDatabase.LoadAssetAtPath<Material>(assetPath);
            if (material == null)
            {
                EnsureFolder(Path.GetDirectoryName(assetPath)?.Replace('\\', '/'));
                material = new Material(shader);
                AssetDatabase.CreateAsset(material, assetPath);
            }
            else if (material.shader != shader)
            {
                material.shader = shader;
            }

            return material;
        }

        /// <summary>
        /// Stores meshes as one model asset file (first mesh = main asset, the rest sub-assets). Existing
        /// meshes with the same name are overwritten in place so prefab references stay valid.
        /// </summary>
        public static Dictionary<string, Mesh> WriteMeshAsset(string assetPath, IReadOnlyList<(string name, System.Action<Mesh> write)> meshes)
        {
            EnsureFolder(Path.GetDirectoryName(assetPath)?.Replace('\\', '/'));
            var existing = new Dictionary<string, Mesh>();
            foreach (var asset in AssetDatabase.LoadAllAssetsAtPath(assetPath))
            {
                if (asset is Mesh mesh && !existing.ContainsKey(mesh.name))
                    existing.Add(mesh.name, mesh);
            }

            var result = new Dictionary<string, Mesh>();
            Object mainAsset = AssetDatabase.LoadMainAssetAtPath(assetPath);
            foreach (var (name, write) in meshes)
            {
                if (!existing.TryGetValue(name, out var mesh))
                {
                    mesh = new Mesh { name = name };
                    if (mainAsset == null)
                    {
                        AssetDatabase.CreateAsset(mesh, assetPath);
                        mainAsset = mesh;
                    }
                    else
                    {
                        AssetDatabase.AddObjectToAsset(mesh, assetPath);
                    }
                }

                write(mesh);
                mesh.name = name;
                EditorUtility.SetDirty(mesh);
                result[name] = mesh;
            }

            // Remove stale sub-meshes that are no longer generated (never the main asset).
            foreach (var pair in existing)
            {
                if (!result.ContainsKey(pair.Key) && pair.Value != mainAsset)
                    Object.DestroyImmediate(pair.Value, true);
            }

            return result;
        }

        public static void SetLayerRecursively(GameObject root, int layer)
        {
            root.layer = layer;
            foreach (Transform child in root.transform)
                SetLayerRecursively(child.gameObject, layer);
        }
    }
}
