using System.Collections.Generic;
using ARInterior.EditorTools.Modeling;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>Generates the texture files and the URP materials used by furniture, AR visuals and the demo room.</summary>
    public static class MaterialLibrary
    {
        const int TextureSize = 512;

        static readonly int BaseMap = Shader.PropertyToID("_BaseMap");
        static readonly int BaseColor = Shader.PropertyToID("_BaseColor");
        static readonly int Metallic = Shader.PropertyToID("_Metallic");
        static readonly int Smoothness = Shader.PropertyToID("_Smoothness");
        static readonly int EmissionColor = Shader.PropertyToID("_EmissionColor");

        sealed class LitSpec
        {
            public string Key;
            public string Texture;
            public Color Color;
            public float Metallic;
            public float Smoothness;
            public Vector2 Tiling = Vector2.one;
            public Color Emission = Color.black;
        }

        public const string WoodOakTexture = "WoodOak_Albedo";
        public const string WoodWalnutTexture = "WoodWalnut_Albedo";
        public const string FabricTexture = "FabricWeave_Albedo";
        public const string MetalTexture = "BrushedMetal_Albedo";
        public const string LinenTexture = "Linen_Albedo";
        public const string FloorTexture = "FloorPlanks_Albedo";

        static readonly LitSpec[] FurnitureSpecs =
        {
            new LitSpec { Key = MaterialKeys.WoodOak, Texture = WoodOakTexture, Color = new Color(0.86f, 0.68f, 0.47f), Smoothness = 0.35f, Tiling = new Vector2(2f, 2f) },
            new LitSpec { Key = MaterialKeys.WoodWalnut, Texture = WoodWalnutTexture, Color = new Color(0.47f, 0.31f, 0.21f), Smoothness = 0.42f, Tiling = new Vector2(1.5f, 1.5f) },
            new LitSpec { Key = MaterialKeys.FabricMustard, Texture = FabricTexture, Color = new Color(0.86f, 0.62f, 0.19f), Smoothness = 0.12f, Tiling = new Vector2(6f, 6f) },
            new LitSpec { Key = MaterialKeys.FabricTeal, Texture = FabricTexture, Color = new Color(0.15f, 0.40f, 0.43f), Smoothness = 0.12f, Tiling = new Vector2(6f, 6f) },
            new LitSpec { Key = MaterialKeys.FabricTealLight, Texture = FabricTexture, Color = new Color(0.25f, 0.55f, 0.57f), Smoothness = 0.12f, Tiling = new Vector2(6f, 6f) },
            new LitSpec { Key = MaterialKeys.MetalBlack, Texture = MetalTexture, Color = new Color(0.13f, 0.13f, 0.14f), Metallic = 0.85f, Smoothness = 0.55f, Tiling = new Vector2(2f, 2f) },
            new LitSpec { Key = MaterialKeys.MetalBrass, Texture = MetalTexture, Color = new Color(0.86f, 0.67f, 0.34f), Metallic = 1f, Smoothness = 0.65f, Tiling = new Vector2(2f, 2f) },
            new LitSpec { Key = MaterialKeys.LinenShade, Texture = LinenTexture, Color = new Color(0.96f, 0.92f, 0.84f), Smoothness = 0.15f, Tiling = new Vector2(4f, 4f), Emission = new Color(0.30f, 0.24f, 0.15f) },
            new LitSpec { Key = MaterialKeys.BulbGlow, Color = new Color(1f, 0.95f, 0.82f), Smoothness = 0.9f, Emission = new Color(2.2f, 1.9f, 1.4f) },
            new LitSpec { Key = MaterialKeys.BookRed, Texture = FabricTexture, Color = new Color(0.62f, 0.17f, 0.15f), Smoothness = 0.25f, Tiling = new Vector2(8f, 8f) },
            new LitSpec { Key = MaterialKeys.BookNavy, Texture = FabricTexture, Color = new Color(0.15f, 0.21f, 0.38f), Smoothness = 0.25f, Tiling = new Vector2(8f, 8f) },
            new LitSpec { Key = MaterialKeys.BookCream, Texture = FabricTexture, Color = new Color(0.88f, 0.82f, 0.68f), Smoothness = 0.25f, Tiling = new Vector2(8f, 8f) },
            new LitSpec { Key = MaterialKeys.BookGreen, Texture = FabricTexture, Color = new Color(0.21f, 0.40f, 0.29f), Smoothness = 0.25f, Tiling = new Vector2(8f, 8f) },
            new LitSpec { Key = MaterialKeys.CeramicWhite, Color = new Color(0.95f, 0.95f, 0.93f), Smoothness = 0.8f }
        };

        public const string DemoFloorKey = "DemoFloor";
        public const string DemoWallKey = "DemoWall";
        public const string DemoRugKey = "DemoRug";

        static readonly LitSpec[] DemoSpecs =
        {
            new LitSpec { Key = DemoFloorKey, Texture = FloorTexture, Color = Color.white, Smoothness = 0.35f, Tiling = new Vector2(1.39f, 0.5f) },
            new LitSpec { Key = DemoWallKey, Color = new Color(0.90f, 0.88f, 0.84f), Smoothness = 0.08f },
            new LitSpec { Key = DemoRugKey, Texture = FabricTexture, Color = new Color(0.56f, 0.37f, 0.31f), Smoothness = 0.05f, Tiling = new Vector2(8f, 8f) }
        };

        public sealed class Result
        {
            public readonly Dictionary<string, Material> Materials = new Dictionary<string, Material>();
            /// <summary>Approximate on-screen colour of each material (base colour × texture average) for thumbnails.</summary>
            public readonly Dictionary<string, Color> PreviewColors = new Dictionary<string, Color>();
        }

        public static Result BuildAll()
        {
            var textures = BuildTextures(out var averages);
            var result = new Result();
            var lit = Shader.Find(SetupPaths.LitShader);
            if (lit == null)
                throw new System.InvalidOperationException($"Shader '{SetupPaths.LitShader}' not found. Is URP installed?");

            foreach (var spec in FurnitureSpecs)
                AddLit(result, spec, lit, textures, averages);
            foreach (var spec in DemoSpecs)
                AddLit(result, spec, lit, textures, averages);
            return result;
        }

        static void AddLit(Result result, LitSpec spec, Shader lit, Dictionary<string, Texture2D> textures,
            Dictionary<string, Color> averages)
        {
            var material = AssetUtility.LoadOrCreateMaterial($"{SetupPaths.Materials}/{spec.Key}.mat", lit);
            Texture2D texture = null;
            if (!string.IsNullOrEmpty(spec.Texture))
                textures.TryGetValue(spec.Texture, out texture);
            material.SetTexture(BaseMap, texture);
            material.SetTextureScale(BaseMap, spec.Tiling);
            material.SetColor(BaseColor, spec.Color);
            material.SetFloat(Metallic, spec.Metallic);
            material.SetFloat(Smoothness, spec.Smoothness);
            if (spec.Emission.maxColorComponent > 0f)
            {
                material.EnableKeyword("_EMISSION");
                material.SetColor(EmissionColor, spec.Emission);
                material.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
            }
            else
            {
                material.DisableKeyword("_EMISSION");
                material.SetColor(EmissionColor, Color.black);
                material.globalIlluminationFlags = MaterialGlobalIlluminationFlags.EmissiveIsBlack;
            }

            EditorUtility.SetDirty(material);
            result.Materials[spec.Key] = material;

            var average = texture != null && averages.TryGetValue(spec.Texture, out var a) ? a : Color.white;
            var preview = spec.Color * average + spec.Emission * 0.15f;
            preview.a = 1f;
            result.PreviewColors[spec.Key] = preview;
        }

        static Dictionary<string, Texture2D> BuildTextures(out Dictionary<string, Color> averages)
        {
            averages = new Dictionary<string, Color>();
            var generated = new Dictionary<string, Color[]>
            {
                { WoodOakTexture, ProceduralTextures.WoodGrain(TextureSize, 1, 6f, 1f) },
                { WoodWalnutTexture, ProceduralTextures.WoodGrain(TextureSize, 2, 9f, 1.4f) },
                { FabricTexture, ProceduralTextures.FabricWeave(TextureSize, 3, 48) },
                { MetalTexture, ProceduralTextures.BrushedMetal(TextureSize, 4) },
                { LinenTexture, ProceduralTextures.Linen(TextureSize, 5) },
                { FloorTexture, ProceduralTextures.FloorPlanks(TextureSize, 6) }
            };

            var textures = new Dictionary<string, Texture2D>();
            foreach (var pair in generated)
            {
                var path = $"{SetupPaths.Textures}/{pair.Key}.png";
                var temporary = ProceduralTextures.ToTexture(pair.Value, TextureSize);
                AssetUtility.WritePng(path, temporary);
                Object.DestroyImmediate(temporary);
                AssetUtility.ConfigureAlbedoTexture(path, TextureSize);
                textures[pair.Key] = AssetDatabase.LoadAssetAtPath<Texture2D>(path);
                averages[pair.Key] = ProceduralTextures.Average(pair.Value);
            }

            return textures;
        }

        public static Material BuildOutlineMaterial()
        {
            var material = AssetUtility.LoadOrCreateMaterial(SetupPaths.OutlineMaterial, RequireShader(SetupPaths.OutlineShader));
            material.SetColor("_OutlineColor", SetupPaths.OutlineColor);
            material.SetFloat("_OutlineWidth", 5f);
            EditorUtility.SetDirty(material);
            return material;
        }

        public static Material BuildMaskMaterial()
        {
            var material = AssetUtility.LoadOrCreateMaterial(SetupPaths.MaskMaterial, RequireShader(SetupPaths.MaskShader));
            EditorUtility.SetDirty(material);
            return material;
        }

        public static Material BuildUnlitColorMaterial(string path, Color color, CompareFunction zTest)
        {
            var material = AssetUtility.LoadOrCreateMaterial(path, RequireShader(SetupPaths.UnlitColorShader));
            material.SetColor("_Color", color);
            material.SetFloat("_ZTest", (float)zTest);
            material.SetFloat("_ZWrite", 0f);
            material.enableInstancing = true;
            EditorUtility.SetDirty(material);
            return material;
        }

        public static Material BuildPlaneGridMaterial()
        {
            var material = AssetUtility.LoadOrCreateMaterial(SetupPaths.PlaneGridMaterial, RequireShader(SetupPaths.PlaneGridShader));
            material.SetColor("_FillColor", new Color(1f, 0.69f, 0f, 0.10f));
            material.SetColor("_LineColor", new Color(1f, 1f, 1f, 0.55f));
            material.SetFloat("_CellSize", 0.25f);
            material.SetFloat("_LineWidth", 1.2f);
            EditorUtility.SetDirty(material);
            return material;
        }

        static Shader RequireShader(string name)
        {
            var shader = Shader.Find(name);
            if (shader == null)
                throw new System.InvalidOperationException($"Shader '{name}' was not found; check {SetupPaths.Shaders}.");
            return shader;
        }
    }
}
