using System.Collections.Generic;
using ARInterior.EditorTools.Modeling;
using UnityEditor;
using UnityEngine;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>Generates the HUD sprites: a 9-slice rounded panel, a circle and the five tool icons.</summary>
    public static class UIAssets
    {
        public const string RoundedPanel = SetupPaths.UI + "/UI_RoundedPanel.png";
        public const string Circle = SetupPaths.UI + "/UI_Circle.png";
        public const string IconSelect = SetupPaths.UI + "/Icon_Select.png";
        public const string IconMove = SetupPaths.UI + "/Icon_Move.png";
        public const string IconRotate = SetupPaths.UI + "/Icon_Rotate.png";
        public const string IconScale = SetupPaths.UI + "/Icon_Scale.png";
        public const string IconDelete = SetupPaths.UI + "/Icon_Delete.png";

        public sealed class Sprites
        {
            public Sprite Rounded;
            public Sprite Circle;
            public readonly Dictionary<string, Sprite> Icons = new Dictionary<string, Sprite>();
        }

        public static Sprites BuildAll()
        {
            var sprites = new Sprites();

            var panel = new IconPainter(96);
            panel.RoundedRect(new Vector2(0f, 0f), new Vector2(96f, 96f), 30f);
            sprites.Rounded = Save(RoundedPanel, panel, new Vector4(36f, 36f, 36f, 36f));

            var circle = new IconPainter(64);
            circle.Circle(new Vector2(32f, 32f), 30f);
            sprites.Circle = Save(Circle, circle, Vector4.zero);

            sprites.Icons[IconSelect] = Save(IconSelect, PaintSelect(), Vector4.zero);
            sprites.Icons[IconMove] = Save(IconMove, PaintMove(), Vector4.zero);
            sprites.Icons[IconRotate] = Save(IconRotate, PaintRotate(), Vector4.zero);
            sprites.Icons[IconScale] = Save(IconScale, PaintScale(), Vector4.zero);
            sprites.Icons[IconDelete] = Save(IconDelete, PaintDelete(), Vector4.zero);
            return sprites;
        }

        static Sprite Save(string path, IconPainter painter, Vector4 border)
        {
            var texture = painter.ToTexture(Color.white);
            AssetUtility.WritePng(path, texture);
            Object.DestroyImmediate(texture);
            AssetUtility.ConfigureSprite(path, border, 256);
            return AssetDatabase.LoadAssetAtPath<Sprite>(path);
        }

        static IconPainter PaintSelect()
        {
            var p = new IconPainter(128);
            // Pointer arrow: head plus tail.
            p.Triangle(new Vector2(38f, 108f), new Vector2(38f, 36f), new Vector2(92f, 60f));
            p.Line(new Vector2(58f, 56f), new Vector2(76f, 22f), 15f);
            return p;
        }

        static IconPainter PaintMove()
        {
            var p = new IconPainter(128);
            var c = new Vector2(64f, 64f);
            p.Line(new Vector2(22f, 64f), new Vector2(106f, 64f), 9f);
            p.Line(new Vector2(64f, 22f), new Vector2(64f, 106f), 9f);
            p.ArrowHead(new Vector2(116f, 64f), c, 22f, 30f);
            p.ArrowHead(new Vector2(12f, 64f), c, 22f, 30f);
            p.ArrowHead(new Vector2(64f, 116f), c, 22f, 30f);
            p.ArrowHead(new Vector2(64f, 12f), c, 22f, 30f);
            return p;
        }

        static IconPainter PaintRotate()
        {
            var p = new IconPainter(128);
            var c = new Vector2(64f, 64f);
            const float radius = 38f;
            p.Ring(c, radius, 11f, 60f, 350f);
            // Arrow head at the 60° end of the arc, pointing counter-clockwise.
            var endAngle = 60f * Mathf.Deg2Rad;
            var end = c + new Vector2(Mathf.Cos(endAngle), Mathf.Sin(endAngle)) * radius;
            var tangent = new Vector2(-Mathf.Sin(endAngle), Mathf.Cos(endAngle));
            p.ArrowHead(end - tangent * 18f, end + tangent * 10f, 26f, 34f);
            return p;
        }

        static IconPainter PaintScale()
        {
            var p = new IconPainter(128);
            p.Line(new Vector2(36f, 36f), new Vector2(92f, 92f), 9f);
            p.ArrowHead(new Vector2(104f, 104f), new Vector2(64f, 64f), 26f, 32f);
            p.ArrowHead(new Vector2(24f, 24f), new Vector2(64f, 64f), 26f, 32f);
            p.Line(new Vector2(16f, 70f), new Vector2(16f, 112f), 8f);
            p.Line(new Vector2(16f, 112f), new Vector2(58f, 112f), 8f);
            p.Line(new Vector2(112f, 16f), new Vector2(112f, 58f), 8f);
            p.Line(new Vector2(112f, 16f), new Vector2(70f, 16f), 8f);
            return p;
        }

        static IconPainter PaintDelete()
        {
            var p = new IconPainter(128);
            p.Line(new Vector2(26f, 98f), new Vector2(102f, 98f), 9f);
            p.RoundedRectOutline(new Vector2(50f, 98f), new Vector2(78f, 116f), 5f, 7f);
            p.RoundedRectOutline(new Vector2(36f, 14f), new Vector2(92f, 92f), 9f, 9f);
            p.Line(new Vector2(55f, 30f), new Vector2(55f, 76f), 7f);
            p.Line(new Vector2(73f, 30f), new Vector2(73f, 76f), 7f);
            return p;
        }
    }
}
