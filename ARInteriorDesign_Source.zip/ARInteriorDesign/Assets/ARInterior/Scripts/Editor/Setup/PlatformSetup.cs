using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.XR.ARCore;
using UnityEditor.XR.Management;
using UnityEditor.XR.Management.Metadata;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.XR.ARCore;
using UnityEngine.XR.Management;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>Layers, Android player settings, XR Plug-in Management (ARCore) and build scene list.</summary>
    public static class PlatformSetup
    {
        public const AndroidSdkVersions MinimumSdk = AndroidSdkVersions.AndroidApiLevel26;
        const string XRSettingsFolder = "Assets/XR";
        const string XRSettingsAsset = XRSettingsFolder + "/XRGeneralSettingsPerBuildTarget.asset";
        const string ARCoreSettingsAsset = XRSettingsFolder + "/Settings/ARCoreSettings.asset";

        public static void ConfigureLayers()
        {
            var tagManager = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset").FirstOrDefault();
            if (tagManager == null)
                throw new System.InvalidOperationException("TagManager.asset could not be loaded.");
            var serialized = new SerializedObject(tagManager);
            var layers = serialized.FindProperty("layers");
            SetLayer(layers, SetupPaths.FurnitureLayer, SetupPaths.FurnitureLayerName);
            SetLayer(layers, SetupPaths.GizmoLayer, SetupPaths.GizmoLayerName);
            SetLayer(layers, SetupPaths.DemoSurfaceLayer, SetupPaths.DemoSurfaceLayerName);
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        static void SetLayer(SerializedProperty layers, int index, string name)
        {
            var element = layers.GetArrayElementAtIndex(index);
            if (!string.IsNullOrEmpty(element.stringValue) && element.stringValue != name)
                throw new System.InvalidOperationException($"Layer {index} is already used by '{element.stringValue}'.");
            element.stringValue = name;
        }

        public static void ConfigurePlayerSettings()
        {
            PlayerSettings.companyName = SetupPaths.CompanyName;
            PlayerSettings.productName = SetupPaths.ProductName;
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, SetupPaths.ApplicationIdentifier);
            PlayerSettings.bundleVersion = "1.0.0";
            PlayerSettings.Android.bundleVersionCode = 1;

            // ARCore (AR Foundation 6.6 on Unity 6000.5+) requires API 26 with OpenGLES3.
            PlayerSettings.Android.minSdkVersion = MinimumSdk;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.OpenGLES3 });
            PlayerSettings.colorSpace = ColorSpace.Linear;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            EditorUserBuildSettings.buildAppBundle = false;

            // Input System package only (the HUD and touch router use it exclusively).
            var playerSettings = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset").FirstOrDefault();
            if (playerSettings != null)
            {
                var serialized = new SerializedObject(playerSettings);
                var inputHandler = serialized.FindProperty("activeInputHandler");
                if (inputHandler != null && inputHandler.intValue != 1)
                {
                    inputHandler.intValue = 1;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                }
            }
        }

        public static void ConfigureXR()
        {
            if (!EditorBuildSettings.TryGetConfigObject(XRGeneralSettings.settingsKey, out XRGeneralSettingsPerBuildTarget perTarget) ||
                perTarget == null)
            {
                var guids = AssetDatabase.FindAssets("t:XRGeneralSettingsPerBuildTarget");
                if (guids.Length > 0)
                {
                    perTarget = AssetDatabase.LoadAssetAtPath<XRGeneralSettingsPerBuildTarget>(AssetDatabase.GUIDToAssetPath(guids[0]));
                }
                else
                {
                    AssetUtility.EnsureFolder(XRSettingsFolder);
                    perTarget = ScriptableObject.CreateInstance<XRGeneralSettingsPerBuildTarget>();
                    AssetDatabase.CreateAsset(perTarget, XRSettingsAsset);
                }

                EditorBuildSettings.AddConfigObject(XRGeneralSettings.settingsKey, perTarget, true);
            }

            if (!perTarget.HasManagerSettingsForBuildTarget(BuildTargetGroup.Android))
                perTarget.CreateDefaultManagerSettingsForBuildTarget(BuildTargetGroup.Android);

            var general = perTarget.SettingsForBuildTarget(BuildTargetGroup.Android);
            general.InitManagerOnStart = true;
            var manager = general.Manager;
            if (!manager.activeLoaders.Any(loader => loader is ARCoreLoader))
            {
                if (!XRPackageMetadataStore.AssignLoader(manager, typeof(ARCoreLoader).FullName, BuildTargetGroup.Android))
                    throw new System.InvalidOperationException("Could not assign the ARCore loader for Android.");
            }

            EditorUtility.SetDirty(general);
            EditorUtility.SetDirty(manager);
            EditorUtility.SetDirty(perTarget);

            var arcore = ARCoreSettings.currentSettings;
            if (arcore == null)
            {
                arcore = AssetDatabase.LoadAssetAtPath<ARCoreSettings>(ARCoreSettingsAsset);
                if (arcore == null)
                {
                    AssetUtility.EnsureFolder(XRSettingsFolder + "/Settings");
                    arcore = ScriptableObject.CreateInstance<ARCoreSettings>();
                    AssetDatabase.CreateAsset(arcore, ARCoreSettingsAsset);
                }

                ARCoreSettings.currentSettings = arcore;
            }

            // Optional: devices without ARCore can still install the app and use the demo scene.
            arcore.requirement = ARCoreSettings.Requirement.Optional;
            arcore.depth = ARCoreSettings.Requirement.Optional;
            EditorUtility.SetDirty(arcore);
        }

        public static bool IsARCoreAssignedForAndroid()
        {
            var general = XRGeneralSettingsPerBuildTarget.XRGeneralSettingsForBuildTarget(BuildTargetGroup.Android);
            return general != null && general.Manager != null && general.Manager.activeLoaders.Any(l => l is ARCoreLoader);
        }

        public static void ConfigureBuildScenes()
        {
            var scenes = new List<EditorBuildSettingsScene>
            {
                new EditorBuildSettingsScene(SetupPaths.MainScene, true),
                new EditorBuildSettingsScene(SetupPaths.DemoScene, true)
            };
            EditorBuildSettings.scenes = scenes.ToArray();
        }
    }
}
