using System.Collections.Generic;
using ARInterior.EditorTools.Modeling;
using ARInterior.Furniture;
using UnityEditor;
using UnityEngine;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>
    /// Turns the procedural furniture models into project assets: one mesh file per model, a thumbnail
    /// PNG, a prefab (root collider + one child per component) and a catalogue entry.
    /// </summary>
    public static class FurnitureAssetBuilder
    {
        public static FurnitureCatalog BuildAll(MaterialLibrary.Result materials)
        {
            var definitions = new List<FurnitureDefinition>();
            foreach (var model in FurnitureFactory.CreateAll())
                definitions.Add(Build(model, materials));

            var catalog = AssetUtility.LoadOrCreateAsset<FurnitureCatalog>(SetupPaths.Catalog);
            catalog.SetItems(definitions);
            EditorUtility.SetDirty(catalog);
            return catalog;
        }

        static FurnitureDefinition Build(FurnitureModel model, MaterialLibrary.Result materials)
        {
            // 1. Mesh file (one asset per model, one mesh per component).
            var meshEntries = new List<(string, System.Action<Mesh>)>();
            foreach (var part in model.Parts)
            {
                var geometry = part.Geometry;
                meshEntries.Add(($"{SetupPaths.ToPascal(model.Id)}_{part.Name}", mesh => geometry.WriteTo(mesh)));
            }

            var meshes = AssetUtility.WriteMeshAsset(SetupPaths.FurnitureModelPath(model.Id), meshEntries);

            // 2. Thumbnail rendered on the CPU from the same geometry.
            var thumbnailParts = new List<(MeshBuilder, Color)>();
            foreach (var part in model.Parts)
                thumbnailParts.Add((part.Geometry, materials.PreviewColors[part.MaterialKey]));
            var thumbnailTexture = ThumbnailRasterizer.Render(thumbnailParts, 256);
            var thumbnailPath = SetupPaths.ThumbnailPath(model.Id);
            AssetUtility.WritePng(thumbnailPath, thumbnailTexture);
            Object.DestroyImmediate(thumbnailTexture);
            AssetUtility.ConfigureSprite(thumbnailPath, Vector4.zero, 256);
            var thumbnail = AssetDatabase.LoadAssetAtPath<Sprite>(thumbnailPath);

            // 3. Prefab.
            var prefab = BuildPrefab(model, meshes, materials);

            // 4. Catalogue entry.
            var definition = AssetUtility.LoadOrCreateAsset<FurnitureDefinition>(SetupPaths.FurnitureDefinitionPath(model.Id));
            definition.Configure(model.Id, model.DisplayName, model.Description, prefab, thumbnail, model.Dimensions);
            EditorUtility.SetDirty(definition);
            return definition;
        }

        static PlacedFurniture BuildPrefab(FurnitureModel model, Dictionary<string, Mesh> meshes,
            MaterialLibrary.Result materials)
        {
            var root = new GameObject(model.DisplayName);
            try
            {
                var renderers = new List<Renderer>();
                foreach (var part in model.Parts)
                {
                    var child = new GameObject(part.Name);
                    child.transform.SetParent(root.transform, false);
                    child.AddComponent<MeshFilter>().sharedMesh = meshes[$"{SetupPaths.ToPascal(model.Id)}_{part.Name}"];
                    var meshRenderer = child.AddComponent<MeshRenderer>();
                    meshRenderer.sharedMaterial = materials.Materials[part.MaterialKey];
                    meshRenderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
                    meshRenderer.receiveShadows = true;
                    renderers.Add(meshRenderer);
                }

                var bounds = model.CalculateBounds();
                var collider = root.AddComponent<BoxCollider>();
                collider.center = bounds.center;
                collider.size = bounds.size;

                var furniture = root.AddComponent<PlacedFurniture>();
                furniture.Configure(model.Id, model.DisplayName, model.Dimensions, collider, renderers.ToArray(),
                    model.MinScale, model.MaxScale);

                AssetUtility.SetLayerRecursively(root, SetupPaths.FurnitureLayer);
                AssetUtility.EnsureFolder(SetupPaths.FurniturePrefabs);
                var saved = PrefabUtility.SaveAsPrefabAsset(root, SetupPaths.FurniturePrefabPath(model.Id), out var success);
                if (!success || saved == null)
                    throw new System.InvalidOperationException($"Saving the prefab for '{model.Id}' failed.");
                return saved.GetComponent<PlacedFurniture>();
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }
    }
}
