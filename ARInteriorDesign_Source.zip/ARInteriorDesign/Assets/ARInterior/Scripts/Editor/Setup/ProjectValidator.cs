using System;
using System.Collections.Generic;
using System.Linq;
using ARInterior.AR;
using ARInterior.Demo;
using ARInterior.Furniture;
using ARInterior.Interaction;
using ARInterior.Rendering;
using ARInterior.UI;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;
using UnityEngine.XR.ARFoundation;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>
    /// Static project checks: catalogue → prefab resolution, model dimensions/pivots/colliders/materials,
    /// outline shader and colour, URP + AR background feature, XR loader, Android settings, build scenes and
    /// null references in every project component of both scenes.
    /// </summary>
    public static class ProjectValidator
    {
        const float DimensionTolerance = 0.04f;

        /// <summary>Serialized references that may legitimately be empty.</summary>
        static readonly HashSet<string> OptionalReferences = new HashSet<string> { "m_EventSystem", "m_Icon" };

        [MenuItem("AR Interior/3. Validate Project", priority = 2)]
        public static void ValidateMenu()
        {
            var problems = Validate();
            LogReport(problems);
            EditorUtility.DisplayDialog("AR Interior Design",
                problems.Count == 0 ? "Validation passed." : $"{problems.Count} problem(s) found. See the Console.", "OK");
        }

        public static void ValidateBatch()
        {
            var exitCode = 1;
            try
            {
                var problems = Validate();
                LogReport(problems);
                exitCode = problems.Count == 0 ? 0 : 2;
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
            }

            EditorApplication.Exit(exitCode);
        }

        public static void LogReport(List<string> problems)
        {
            if (problems.Count == 0)
            {
                Debug.Log("[ARInterior] Validation PASSED: no problems found.");
                return;
            }

            Debug.LogError($"[ARInterior] Validation FAILED with {problems.Count} problem(s):\n - " + string.Join("\n - ", problems));
        }

        public static List<string> Validate()
        {
            var problems = new List<string>();
            ValidateCatalogue(problems);
            ValidateRendering(problems);
            ValidatePlatform(problems);
            ValidateScenes(problems);
            return problems;
        }

        public static void ValidateCatalogue(List<string> problems)
        {
            var catalog = AssetDatabase.LoadAssetAtPath<FurnitureCatalog>(SetupPaths.Catalog);
            if (catalog == null)
            {
                problems.Add($"Catalogue missing at {SetupPaths.Catalog}");
                return;
            }

            problems.AddRange(catalog.Validate());
            if (catalog.Items.Count < 5)
                problems.Add($"Catalogue has {catalog.Items.Count} items; at least 5 are required");

            foreach (var definition in catalog.Items.Where(d => d != null && d.Prefab != null))
                ValidateFurniturePrefab(definition, problems);
        }

        public static void ValidateFurniturePrefab(FurnitureDefinition definition, List<string> problems)
        {
            var prefab = definition.Prefab;
            var id = definition.Id;
            if (prefab.FurnitureId != id)
                problems.Add($"{id}: prefab id '{prefab.FurnitureId}' does not match its catalogue entry");
            if (definition.Thumbnail == null)
                problems.Add($"{id}: no thumbnail");

            var renderers = prefab.Renderers;
            if (renderers == null || renderers.Length < 3)
                problems.Add($"{id}: needs at least 3 renderers (multi-part model), found {renderers?.Length ?? 0}");

            var hasBounds = false;
            var bounds = new Bounds();
            foreach (var r in renderers ?? Array.Empty<Renderer>())
            {
                if (r == null)
                {
                    problems.Add($"{id}: null renderer reference");
                    continue;
                }

                if (r.sharedMaterials.Length == 0 || r.sharedMaterials.Any(m => m == null))
                    problems.Add($"{id}/{r.name}: missing material");
                var filter = r.GetComponent<MeshFilter>();
                if (filter == null || filter.sharedMesh == null || filter.sharedMesh.vertexCount == 0)
                {
                    problems.Add($"{id}/{r.name}: missing mesh");
                    continue;
                }

                if (filter.sharedMesh.subMeshCount != 1)
                    problems.Add($"{id}/{r.name}: expected one sub-mesh per component (outline relies on it)");

                var meshBounds = filter.sharedMesh.bounds;
                var local = TransformBounds(r.transform, prefab.transform, meshBounds);
                if (!hasBounds)
                {
                    bounds = local;
                    hasBounds = true;
                }
                else
                {
                    bounds.Encapsulate(local);
                }
            }

            if (hasBounds)
            {
                var size = bounds.size;
                var expected = definition.Dimensions;
                if (Mathf.Abs(size.x - expected.x) > DimensionTolerance ||
                    Mathf.Abs(size.y - expected.y) > DimensionTolerance ||
                    Mathf.Abs(size.z - expected.z) > DimensionTolerance)
                {
                    problems.Add($"{id}: geometry size {size:F3} differs from declared dimensions {expected:F3}");
                }

                if (Mathf.Abs(bounds.min.y) > 0.005f)
                    problems.Add($"{id}: pivot is not at floor level (min y = {bounds.min.y:F3})");
                if (Mathf.Abs(bounds.center.x) > 0.03f || Mathf.Abs(bounds.center.z) > 0.03f)
                    problems.Add($"{id}: pivot is not centred on the footprint (centre {bounds.center:F3})");
            }

            var collider = prefab.SelectionCollider;
            if (collider == null || !collider.enabled || collider.isTrigger)
                problems.Add($"{id}: needs an enabled, non-trigger BoxCollider");
            else if (hasBounds && (collider.size - bounds.size).magnitude > 0.01f)
                problems.Add($"{id}: collider size {collider.size:F3} does not match the model bounds {bounds.size:F3}");

            if (prefab.gameObject.layer != SetupPaths.FurnitureLayer)
                problems.Add($"{id}: root is not on the Furniture layer");
            if (prefab.MinScale <= 0f || prefab.MaxScale < prefab.MinScale || prefab.MinScale > 1f || prefab.MaxScale < 1f)
                problems.Add($"{id}: invalid scale limits [{prefab.MinScale}, {prefab.MaxScale}]");
        }

        static Bounds TransformBounds(Transform from, Transform to, Bounds bounds)
        {
            var matrix = to.worldToLocalMatrix * from.localToWorldMatrix;
            var result = new Bounds(matrix.MultiplyPoint3x4(bounds.center), Vector3.zero);
            var e = bounds.extents;
            for (var i = 0; i < 8; i++)
            {
                var corner = bounds.center + new Vector3((i & 1) == 0 ? -e.x : e.x, (i & 2) == 0 ? -e.y : e.y, (i & 4) == 0 ? -e.z : e.z);
                result.Encapsulate(matrix.MultiplyPoint3x4(corner));
            }

            return result;
        }

        public static void ValidateRendering(List<string> problems)
        {
            if (GraphicsSettings.defaultRenderPipeline == null)
                problems.Add("No render pipeline asset assigned in Graphics settings");
            if (!RenderPipelineSetup.HasBackgroundFeature())
                problems.Add("URP renderer must contain exactly one ARBackgroundRendererFeature");

            var outline = AssetDatabase.LoadAssetAtPath<Material>(SetupPaths.OutlineMaterial);
            if (outline == null)
            {
                problems.Add("Outline material missing");
            }
            else
            {
                if (outline.shader == null || outline.shader.name != SetupPaths.OutlineShader)
                    problems.Add("Outline material does not use the outline shader");
                else if (ShaderUtil.ShaderHasError(outline.shader))
                    problems.Add("Outline shader has compile errors");
                var color = outline.GetColor("_OutlineColor");
                if (!Approximately(color, SetupPaths.OutlineColor))
                    problems.Add($"Outline colour is {color}, expected #FFB000");
            }

            foreach (var shaderName in new[] { SetupPaths.MaskShader, SetupPaths.UnlitColorShader, SetupPaths.PlaneGridShader })
            {
                var shader = Shader.Find(shaderName);
                if (shader == null)
                    problems.Add($"Shader '{shaderName}' missing");
                else if (ShaderUtil.ShaderHasError(shader))
                    problems.Add($"Shader '{shaderName}' has compile errors");
            }
        }

        public static void ValidatePlatform(List<string> problems)
        {
            if (!PlatformSetup.IsARCoreAssignedForAndroid())
                problems.Add("ARCore loader is not enabled for Android in XR Plug-in Management");
            if (PlayerSettings.Android.minSdkVersion < PlatformSetup.MinimumSdk)
                problems.Add($"Android min SDK {PlayerSettings.Android.minSdkVersion} is below {PlatformSetup.MinimumSdk}");
            if (PlayerSettings.GetScriptingBackend(NamedBuildTarget.Android) != ScriptingImplementation.IL2CPP)
                problems.Add("Android scripting backend must be IL2CPP (ARM64)");
            if ((PlayerSettings.Android.targetArchitectures & AndroidArchitecture.ARM64) == 0)
                problems.Add("ARM64 is not enabled for Android");
            var apis = PlayerSettings.GetGraphicsAPIs(BuildTarget.Android);
            if (apis.Length == 0 || apis[0] != GraphicsDeviceType.OpenGLES3)
                problems.Add("OpenGLES3 must be the first Android graphics API");
            if (PlayerSettings.GetApplicationIdentifier(NamedBuildTarget.Android) != SetupPaths.ApplicationIdentifier)
                problems.Add("Android application identifier not set");

            var scenes = EditorBuildSettings.scenes;
            if (scenes.Length < 2 || scenes[0].path != SetupPaths.MainScene || scenes[1].path != SetupPaths.DemoScene ||
                !scenes[0].enabled || !scenes[1].enabled)
            {
                problems.Add("Build settings must list MainARScene (index 0) and DemoScene (index 1), both enabled");
            }
        }

        public static void ValidateScenes(List<string> problems)
        {
            var previous = EditorSceneManager.GetActiveScene().path;
            ValidateScene(SetupPaths.MainScene, true, problems);
            ValidateScene(SetupPaths.DemoScene, false, problems);
            if (!string.IsNullOrEmpty(previous) && previous != SetupPaths.MainScene && previous != SetupPaths.DemoScene)
                EditorSceneManager.OpenScene(previous, OpenSceneMode.Single);
        }

        static void ValidateScene(string path, bool isAR, List<string> problems)
        {
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
            {
                problems.Add($"Scene missing: {path}");
                return;
            }

            var scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
            var name = scene.name;

            void RequireOne<T>() where T : Component
            {
                var count = UnityEngine.Object.FindObjectsByType<T>(FindObjectsInactive.Include).Length;
                if (count != 1)
                    problems.Add($"{name}: expected exactly one {typeof(T).Name}, found {count}");
            }

            RequireOne<InteractionController>();
            RequireOne<TouchInputRouter>();
            RequireOne<SelectionManager>();
            RequireOne<SelectionOutline>();
            RequireOne<TransformController>();
            RequireOne<PlacementController>();
            RequireOne<AxisGizmo>();
            RequireOne<ARInteriorHUD>();
            RequireOne<UnityEngine.EventSystems.EventSystem>();
            if (isAR)
            {
                RequireOne<ARSession>();
                RequireOne<ARPlaneManager>();
                RequireOne<ARRaycastManager>();
                RequireOne<ARAnchorManager>();
                RequireOne<ARCameraBackground>();
                RequireOne<ARPlaneSurfaceProvider>();
                RequireOne<ARSessionStatusProvider>();
                var planeManager = UnityEngine.Object.FindAnyObjectByType<ARPlaneManager>(FindObjectsInactive.Include);
                if (planeManager != null && planeManager.planePrefab == null)
                    problems.Add($"{name}: ARPlaneManager has no plane prefab");
            }
            else
            {
                RequireOne<PhysicsSurfaceProvider>();
                RequireOne<DemoStatusProvider>();
            }

            // Every serialized object reference on project components must be assigned.
            foreach (var behaviour in UnityEngine.Object.FindObjectsByType<MonoBehaviour>(FindObjectsInactive.Include))
            {
                if (behaviour == null || behaviour.GetType().Namespace == null || !behaviour.GetType().Namespace.StartsWith("ARInterior"))
                    continue;
                var serialized = new SerializedObject(behaviour);
                var property = serialized.GetIterator();
                while (property.NextVisible(true))
                {
                    if (property.propertyType != SerializedPropertyType.ObjectReference || OptionalReferences.Contains(property.name))
                        continue;
                    if (property.objectReferenceValue == null)
                        problems.Add($"{name}: {behaviour.GetType().Name} on '{behaviour.name}' has an empty reference '{property.propertyPath}'");
                }
            }

            // No decorative buttons: every Button must be one the HUD binds.
            var hud = UnityEngine.Object.FindAnyObjectByType<ARInteriorHUD>(FindObjectsInactive.Include);
            if (hud != null)
            {
                var referenced = new HashSet<Button>();
                var serializedHud = new SerializedObject(hud);
                var iterator = serializedHud.GetIterator();
                while (iterator.NextVisible(true))
                {
                    if (iterator.propertyType != SerializedPropertyType.ObjectReference || iterator.objectReferenceValue == null)
                        continue;
                    if (iterator.objectReferenceValue is HudButton hudButton && hudButton.Button != null)
                        referenced.Add(hudButton.Button);
                    if (iterator.objectReferenceValue is CatalogItemView card && card.Button != null)
                        referenced.Add(card.Button);
                }

                foreach (var button in hud.GetComponentsInChildren<Button>(true))
                {
                    if (!referenced.Contains(button))
                        problems.Add($"{name}: button '{button.name}' is not connected to the HUD");
                }
            }
        }

        static bool Approximately(Color a, Color b) =>
            Mathf.Abs(a.r - b.r) < 0.01f && Mathf.Abs(a.g - b.g) < 0.01f && Mathf.Abs(a.b - b.b) < 0.01f;
    }
}
