using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>
    /// Builds the Android APK (IL2CPP, ARM64) after validating the project.
    /// Batch: Unity -batchmode -projectPath P -buildTarget Android -executeMethod ARInterior.EditorTools.Setup.AndroidBuilder.BuildApkBatch
    /// </summary>
    public static class AndroidBuilder
    {
        [MenuItem("AR Interior/4. Build Android APK", priority = 3)]
        public static void BuildApkMenu()
        {
            var report = BuildApk();
            EditorUtility.DisplayDialog("AR Interior Design",
                report != null && report.summary.result == BuildResult.Succeeded
                    ? $"APK built: {SetupPaths.ApkPath}"
                    : "The Android build failed. See the Console.", "OK");
        }

        public static void BuildApkBatch()
        {
            var exitCode = 1;
            try
            {
                var report = BuildApk();
                exitCode = report != null && report.summary.result == BuildResult.Succeeded ? 0 : 3;
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
            }

            EditorApplication.Exit(exitCode);
        }

        public static BuildReport BuildApk()
        {
            var problems = ProjectValidator.Validate();
            ProjectValidator.LogReport(problems);
            if (problems.Count > 0)
            {
                Debug.LogError("[ARInterior] Build aborted: fix the validation problems first.");
                return null;
            }

            var output = Path.GetFullPath(Path.Combine(Application.dataPath, "..", SetupPaths.ApkPath));
            Directory.CreateDirectory(Path.GetDirectoryName(output) ?? ".");
            EditorUserBuildSettings.buildAppBundle = false;

            var options = new BuildPlayerOptions
            {
                scenes = new[] { SetupPaths.MainScene, SetupPaths.DemoScene },
                locationPathName = output,
                target = BuildTarget.Android,
                targetGroup = BuildTargetGroup.Android,
                options = BuildOptions.None
            };

            var report = BuildPipeline.BuildPlayer(options);
            var summary = report.summary;
            Debug.Log($"[ARInterior] Build result: {summary.result}, errors: {summary.totalErrors}, warnings: {summary.totalWarnings}, " +
                      $"size: {summary.totalSize} bytes, time: {summary.totalTime}, output: {summary.outputPath}");
            if (summary.result == BuildResult.Succeeded)
            {
                var info = new FileInfo(output);
                if (!info.Exists || info.Length == 0)
                    Debug.LogError($"[ARInterior] Build reported success but the APK is missing or empty: {output}");
                else
                    Debug.Log($"[ARInterior] APK OK: {output} ({info.Length} bytes)");
            }

            return report;
        }
    }
}
