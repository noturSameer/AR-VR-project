using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.XR.ARFoundation;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>
    /// Creates the mobile URP asset and renderer, adds AR Foundation's ARBackgroundRendererFeature exactly
    /// once (required for the camera feed in URP) and assigns the pipeline to Graphics and all Quality levels.
    /// </summary>
    public static class RenderPipelineSetup
    {
        const string PostProcessDataPath = "Packages/com.unity.render-pipelines.universal/Runtime/Data/PostProcessData.asset";

        public static UniversalRenderPipelineAsset Configure()
        {
            AssetUtility.EnsureFolder(SetupPaths.Settings);

            var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(SetupPaths.UrpRenderer);
            if (renderer == null)
            {
                renderer = ScriptableObject.CreateInstance<UniversalRendererData>();
                renderer.postProcessData = AssetDatabase.LoadAssetAtPath<PostProcessData>(PostProcessDataPath);
                AssetDatabase.CreateAsset(renderer, SetupPaths.UrpRenderer);
            }

            EnsureBackgroundFeature(renderer);

            var asset = AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(SetupPaths.UrpAsset);
            if (asset == null)
            {
                asset = UniversalRenderPipelineAsset.Create(renderer);
                AssetDatabase.CreateAsset(asset, SetupPaths.UrpAsset);
            }

            // Mobile-friendly defaults: no HDR, 4× MSAA for clean outlines, short shadow distance.
            asset.supportsHDR = false;
            asset.msaaSampleCount = 4;
            asset.renderScale = 1f;
            asset.shadowDistance = 8f;
            EditorUtility.SetDirty(asset);

            GraphicsSettings.defaultRenderPipeline = asset;
            AssignToQualityLevels(asset);
            return asset;
        }

        static void EnsureBackgroundFeature(UniversalRendererData renderer)
        {
            var serialized = new SerializedObject(renderer);
            var features = serialized.FindProperty("m_RendererFeatures");
            var map = serialized.FindProperty("m_RendererFeatureMap");
            if (features == null || map == null)
                throw new System.InvalidOperationException("Unexpected UniversalRendererData layout; cannot add the AR background feature.");

            var existing = renderer.rendererFeatures.Count(f => f is ARBackgroundRendererFeature);
            if (existing == 1)
                return;
            if (existing > 1)
                throw new System.InvalidOperationException("The URP renderer contains more than one ARBackgroundRendererFeature.");

            var feature = ScriptableObject.CreateInstance<ARBackgroundRendererFeature>();
            feature.name = "ARBackgroundRendererFeature";
            AssetDatabase.AddObjectToAsset(feature, renderer);
            AssetDatabase.TryGetGUIDAndLocalFileIdentifier(feature, out _, out long localId);

            var index = features.arraySize;
            features.InsertArrayElementAtIndex(index);
            features.GetArrayElementAtIndex(index).objectReferenceValue = feature;
            map.InsertArrayElementAtIndex(index);
            map.GetArrayElementAtIndex(index).longValue = localId;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            renderer.SetDirty();
            EditorUtility.SetDirty(renderer);
        }

        static void AssignToQualityLevels(RenderPipelineAsset asset)
        {
            var qualitySettings = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/QualitySettings.asset").FirstOrDefault();
            if (qualitySettings == null)
                return;
            var serialized = new SerializedObject(qualitySettings);
            var levels = serialized.FindProperty("m_QualitySettings");
            for (var i = 0; i < levels.arraySize; i++)
            {
                var pipeline = levels.GetArrayElementAtIndex(i).FindPropertyRelative("customRenderPipeline");
                if (pipeline != null)
                    pipeline.objectReferenceValue = asset;
            }

            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        public static bool HasBackgroundFeature()
        {
            var renderer = AssetDatabase.LoadAssetAtPath<UniversalRendererData>(SetupPaths.UrpRenderer);
            return renderer != null && renderer.rendererFeatures.Count(f => f is ARBackgroundRendererFeature) == 1;
        }
    }
}
