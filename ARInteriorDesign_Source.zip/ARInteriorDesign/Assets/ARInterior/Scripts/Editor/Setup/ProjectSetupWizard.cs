using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;
using TMPro;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>
    /// Idempotent one-click project setup. Generates textures, materials, models, prefabs, catalogue, URP,
    /// XR/ARCore and Android settings, both scenes with their HUD, and the build scene list. Safe to run
    /// repeatedly: assets are updated in place and scenes are rebuilt from scratch.
    ///
    /// Batch mode:
    ///   Unity -batchmode -projectPath P -buildTarget Android -executeMethod ARInterior.EditorTools.Setup.ProjectSetupWizard.ImportTextMeshProEssentialsBatch
    ///   Unity -batchmode -projectPath P -buildTarget Android -executeMethod ARInterior.EditorTools.Setup.ProjectSetupWizard.RunFullSetupBatch
    /// </summary>
    public static class ProjectSetupWizard
    {
        [MenuItem("AR Interior/1. Import TextMeshPro Essentials", priority = 0)]
        public static void ImportTextMeshProEssentialsMenu()
        {
            if (HasTextMeshProEssentials())
            {
                Debug.Log("TextMeshPro Essential Resources are already imported.");
                return;
            }

            UnityEditor.AssetPackage.Package.Import(FindTmpEssentialsPackage(), false);
        }

        [MenuItem("AR Interior/2. Run Full Setup", priority = 1)]
        public static void RunFullSetupMenu()
        {
            var problems = RunFullSetup();
            if (problems.Count == 0)
                EditorUtility.DisplayDialog("AR Interior Design", "Setup finished and validation passed.", "OK");
            else
                EditorUtility.DisplayDialog("AR Interior Design", $"Setup finished with {problems.Count} validation problem(s). See the Console.", "OK");
        }

        public static bool HasTextMeshProEssentials() =>
            AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(SetupPaths.TmpFont) != null &&
            File.Exists(AssetUtility.ToFullPath(SetupPaths.TmpSettings));

        static string FindTmpEssentialsPackage()
        {
            var package = UnityEditor.PackageManager.PackageInfo.FindForAssetPath("Packages/com.unity.ugui/package.json");
            if (package == null)
                throw new InvalidOperationException("com.unity.ugui is not installed.");
            var path = Path.Combine(package.resolvedPath, "Package Resources", "TMP Essential Resources.unitypackage");
            if (!File.Exists(path))
                throw new FileNotFoundException("TMP Essential Resources.unitypackage not found.", path);
            return path;
        }

        /// <summary>Batch entry: imports TMP Essential Resources and exits once the import has completed.</summary>
        public static void ImportTextMeshProEssentialsBatch()
        {
            if (HasTextMeshProEssentials())
            {
                Debug.Log("[ARInterior] TextMeshPro Essential Resources already present.");
                EditorApplication.Exit(0);
                return;
            }

            AssetDatabase.importPackageCompleted += name =>
            {
                Debug.Log($"[ARInterior] Imported package '{name}'.");
                AssetDatabase.Refresh();
                EditorApplication.Exit(HasTextMeshProEssentials() ? 0 : 1);
            };
            AssetDatabase.importPackageFailed += (name, error) =>
            {
                Debug.LogError($"[ARInterior] Importing '{name}' failed: {error}");
                EditorApplication.Exit(1);
            };
            UnityEditor.AssetPackage.Package.Import(FindTmpEssentialsPackage(), false);
        }

        /// <summary>Batch entry: runs the full setup and validation; exit code 0 only when validation passes.</summary>
        public static void RunFullSetupBatch()
        {
            var exitCode = 1;
            try
            {
                var problems = RunFullSetup();
                exitCode = problems.Count == 0 ? 0 : 2;
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
            }

            EditorApplication.Exit(exitCode);
        }

        public static System.Collections.Generic.List<string> RunFullSetup()
        {
            if (!HasTextMeshProEssentials())
                throw new InvalidOperationException("Import TextMeshPro Essential Resources first (AR Interior/1. Import TextMeshPro Essentials).");

            Log("Folders and layers");
            foreach (var folder in new[]
                     {
                         SetupPaths.Textures, SetupPaths.Materials, SetupPaths.Models, SetupPaths.UI, SetupPaths.Thumbnails,
                         SetupPaths.FurniturePrefabs, SetupPaths.ARPrefabs, SetupPaths.FurnitureData, SetupPaths.Scenes,
                         SetupPaths.Settings
                     })
            {
                AssetUtility.EnsureFolder(folder);
            }

            PlatformSetup.ConfigureLayers();

            Log("Render pipeline (URP + AR background feature)");
            RenderPipelineSetup.Configure();

            Log("Textures and materials");
            var materials = MaterialLibrary.BuildAll();
            var outline = MaterialLibrary.BuildOutlineMaterial();
            var mask = MaterialLibrary.BuildMaskMaterial();
            var gizmoMaterial = MaterialLibrary.BuildUnlitColorMaterial(SetupPaths.GizmoMaterial, Color.white, CompareFunction.Always);
            var planeLine = MaterialLibrary.BuildUnlitColorMaterial(SetupPaths.PlaneLineMaterial, Color.white, CompareFunction.LessEqual);
            var planeGrid = MaterialLibrary.BuildPlaneGridMaterial();

            Log("Furniture models, thumbnails, prefabs and catalogue");
            var catalog = FurnitureAssetBuilder.BuildAll(materials);

            Log("AR plane prefab and move gizmo");
            var planePrefab = SceneBuilder.BuildPlanePrefab(planeGrid, planeLine);
            var gizmoMesh = SceneBuilder.BuildGizmoArrowMesh();

            Log("UI sprites and icons");
            var sprites = UIAssets.BuildAll();
            AssetDatabase.SaveAssets();

            var context = new SceneContext
            {
                Catalog = catalog,
                OutlineMaterial = outline,
                MaskMaterial = mask,
                GizmoMaterial = gizmoMaterial,
                PlanePrefab = planePrefab,
                GizmoArrowMesh = gizmoMesh,
                Materials = materials,
                UIStyle = new UIBuilder.Style
                {
                    Font = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>(SetupPaths.TmpFont),
                    Rounded = sprites.Rounded,
                    Circle = sprites.Circle,
                    IconSelect = sprites.Icons[UIAssets.IconSelect],
                    IconMove = sprites.Icons[UIAssets.IconMove],
                    IconRotate = sprites.Icons[UIAssets.IconRotate],
                    IconScale = sprites.Icons[UIAssets.IconScale],
                    IconDelete = sprites.Icons[UIAssets.IconDelete]
                }
            };

            Log("Android player settings and XR (ARCore)");
            PlatformSetup.ConfigurePlayerSettings();
            PlatformSetup.ConfigureXR();

            Log("Scenes");
            SceneBuilder.BuildDemoScene(context);
            SceneBuilder.BuildMainARScene(context);
            PlatformSetup.ConfigureBuildScenes();

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            Log("Validation");
            var problems = ProjectValidator.Validate();
            ProjectValidator.LogReport(problems);
            return problems;
        }

        static void Log(string step) => Debug.Log($"[ARInterior] Setup: {step}");
    }
}
