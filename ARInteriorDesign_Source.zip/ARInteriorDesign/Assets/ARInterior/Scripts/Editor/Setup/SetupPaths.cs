using UnityEngine;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>Asset locations and project constants shared by the setup wizard, validator and tests.</summary>
    public static class SetupPaths
    {
        public const string Root = "Assets/ARInterior";
        public const string Textures = Root + "/Art/Textures";
        public const string Materials = Root + "/Art/Materials";
        public const string Models = Root + "/Art/Models";
        public const string UI = Root + "/Art/UI";
        public const string Thumbnails = Root + "/Art/UI/Thumbnails";
        public const string FurniturePrefabs = Root + "/Prefabs/Furniture";
        public const string ARPrefabs = Root + "/Prefabs/AR";
        public const string Data = Root + "/Data";
        public const string FurnitureData = Root + "/Data/Furniture";
        public const string Scenes = Root + "/Scenes";
        public const string Settings = Root + "/Settings";
        public const string Shaders = Root + "/Shaders";

        public const string MainScene = Scenes + "/MainARScene.unity";
        public const string DemoScene = Scenes + "/DemoScene.unity";
        public const string MainSceneName = "MainARScene";
        public const string DemoSceneName = "DemoScene";
        public const string Catalog = Data + "/FurnitureCatalog.asset";
        public const string UrpAsset = Settings + "/URP-Mobile.asset";
        public const string UrpRenderer = Settings + "/URP-Mobile_Renderer.asset";
        public const string PlanePrefab = ARPrefabs + "/ARPlaneVisualizer.prefab";
        public const string OutlineMaterial = Materials + "/SelectionOutline.mat";
        public const string MaskMaterial = Materials + "/SelectionStencilMask.mat";
        public const string GizmoMaterial = Materials + "/MoveGizmo.mat";
        public const string PlaneGridMaterial = Materials + "/ARPlaneGrid.mat";
        public const string PlaneLineMaterial = Materials + "/ARPlaneBoundary.mat";
        public const string GizmoMesh = Models + "/MoveGizmoArrow.asset";
        public const string DemoRoomMesh = Models + "/DemoRoom.asset";
        public const string TmpFont = "Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF.asset";
        public const string TmpSettings = "Assets/TextMesh Pro/Resources/TMP Settings.asset";

        public const string OutlineShader = "ARInterior/SelectionOutline";
        public const string MaskShader = "ARInterior/SelectionStencilMask";
        public const string UnlitColorShader = "ARInterior/UnlitColor";
        public const string PlaneGridShader = "ARInterior/PlaneGrid";
        public const string LitShader = "Universal Render Pipeline/Lit";

        public const int FurnitureLayer = 8;
        public const int GizmoLayer = 9;
        public const int DemoSurfaceLayer = 10;
        public const string FurnitureLayerName = "Furniture";
        public const string GizmoLayerName = "Gizmo";
        public const string DemoSurfaceLayerName = "DemoSurface";

        public const string ApplicationIdentifier = "com.university.arinteriordesign";
        public const string ProductName = "AR Interior Design";
        public const string CompanyName = "University AR Lab";
        public const string ApkPath = "Builds/Android/ARInteriorDesign.apk";

        /// <summary>#FFB000 selection colour.</summary>
        public static readonly Color OutlineColor = new Color32(0xFF, 0xB0, 0x00, 0xFF);

        public static string FurniturePrefabPath(string id) => $"{FurniturePrefabs}/{ToPascal(id)}.prefab";
        public static string FurnitureModelPath(string id) => $"{Models}/{ToPascal(id)}.asset";
        public static string FurnitureDefinitionPath(string id) => $"{FurnitureData}/{ToPascal(id)}.asset";
        public static string ThumbnailPath(string id) => $"{Thumbnails}/{ToPascal(id)}_Thumbnail.png";

        public static string ToPascal(string id)
        {
            var parts = id.Split('-');
            var result = string.Empty;
            foreach (var part in parts)
            {
                if (part.Length > 0)
                    result += char.ToUpperInvariant(part[0]) + part.Substring(1);
            }

            return result;
        }
    }
}
