using UnityEditor;
using UnityEngine;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>
    /// Writes private [SerializeField] references during scene authoring. Throws when a field name does not
    /// exist so a renamed field fails the setup loudly instead of leaving a silent null reference.
    /// </summary>
    public static class SerializedFields
    {
        public static void Set(Object target, string field, Object value)
        {
            var serialized = new SerializedObject(target);
            Find(serialized, field).objectReferenceValue = value;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        public static void SetMask(Object target, string field, int mask)
        {
            var serialized = new SerializedObject(target);
            Find(serialized, field).intValue = mask;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        public static void SetString(Object target, string field, string value)
        {
            var serialized = new SerializedObject(target);
            Find(serialized, field).stringValue = value;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        public static void SetArray(Object target, string field, Object[] values)
        {
            var serialized = new SerializedObject(target);
            var property = Find(serialized, field);
            property.arraySize = values.Length;
            for (var i = 0; i < values.Length; i++)
                property.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }

        static SerializedProperty Find(SerializedObject serialized, string field)
        {
            var property = serialized.FindProperty(field);
            if (property == null)
                throw new System.InvalidOperationException(
                    $"Serialized field '{field}' not found on {serialized.targetObject.GetType().Name}.");
            return property;
        }
    }
}
