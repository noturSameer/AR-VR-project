using System.Collections.Generic;
using ARInterior.Core;
using ARInterior.Furniture;
using ARInterior.Interaction;
using ARInterior.UI;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.UI;

namespace ARInterior.EditorTools.Setup
{
    /// <summary>
    /// Builds the portrait mobile HUD ("AR Interior Design") with uGUI and TextMeshPro and wires every control
    /// to <see cref="ARInteriorHUD"/>. Reference resolution 1080×1920; the content sits inside the safe area.
    /// </summary>
    public static class UIBuilder
    {
        public sealed class Style
        {
            public TMP_FontAsset Font;
            public Sprite Rounded;
            public Sprite Circle;
            public Sprite IconSelect;
            public Sprite IconMove;
            public Sprite IconRotate;
            public Sprite IconScale;
            public Sprite IconDelete;
        }

        static readonly Color PanelColor = new Color32(0x15, 0x17, 0x1C, 0xE0);
        static readonly Color ChipIdle = new Color(1f, 1f, 1f, 0.10f);
        static readonly Color Accent = SetupPaths.OutlineColor;
        static readonly Color AccentText = new Color32(0x1B, 0x1D, 0x22, 0xFF);
        static readonly Color DeleteIdle = new Color(1f, 0.27f, 0.23f, 0.22f);
        static readonly Color DeleteContent = new Color32(0xFF, 0x8A, 0x80, 0xFF);

        const int UILayer = 5;

        public static ARInteriorHUD Build(Style style, InteractionController interaction, FurnitureCatalog catalog,
            string alternateSceneName, string alternateSceneLabel)
        {
            if (style.Font == null)
                throw new System.InvalidOperationException("TextMeshPro font asset missing; import TMP Essential Resources first.");

            var canvasGo = new GameObject("HUD Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler),
                typeof(GraphicRaycaster));
            canvasGo.layer = UILayer;
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1080f, 1920f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.3f;

            var safeArea = CreateRect("Safe Area", canvasGo.transform);
            Stretch(safeArea);
            safeArea.gameObject.AddComponent<SafeAreaFitter>();

            var hud = canvasGo.AddComponent<ARInteriorHUD>();

            // ---------------------------------------------------------------- top bar
            var topBar = CreatePanel("Top Bar", safeArea, style, PanelColor, true);
            Anchor(topBar, new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -16f), new Vector2(-32f, 196f));

            var title = CreateText("Title", topBar, style, "AR Interior Design", 50f, FontStyles.Bold, TextAlignmentOptions.MidlineLeft, Color.white);
            Anchor(title.rectTransform, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(34f, -18f), new Vector2(700f, 70f));

            var switchButton = CreateTextButton("Switch Scene Button", topBar, style, alternateSceneLabel, 30f, ChipIdle, Accent, Color.white, AccentText);
            Anchor((RectTransform)switchButton.transform, new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-22f, -20f), new Vector2(170f, 74f));

            var statusPill = CreatePanel("Status Pill", topBar, style, new Color(1f, 1f, 1f, 0.08f), false);
            Anchor(statusPill, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(26f, -106f), new Vector2(520f, 68f));
            var dot = CreateImage("Status Dot", statusPill, style.Circle, Accent, false);
            Anchor(dot.rectTransform, new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(24f, 0f), new Vector2(22f, 22f));
            var statusLabel = CreateText("Status Label", statusPill, style, "Starting…", 28f, FontStyles.Normal, TextAlignmentOptions.MidlineLeft, Color.white);
            Anchor(statusLabel.rectTransform, new Vector2(0f, 0f), new Vector2(1f, 1f), new Vector2(0.5f, 0.5f), new Vector2(29f, 0f), new Vector2(-82f, 0f));

            var selectionLabel = CreateText("Selection Label", topBar, style, "Nothing selected", 28f, FontStyles.Normal, TextAlignmentOptions.MidlineRight, new Color(1f, 1f, 1f, 0.85f));
            Anchor(selectionLabel.rectTransform, new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-28f, -106f), new Vector2(450f, 68f));
            selectionLabel.overflowMode = TextOverflowModes.Ellipsis;

            // ---------------------------------------------------------------- guidance banner (touch-transparent)
            var guidance = CreatePanel("Guidance Banner", safeArea, style, new Color(0f, 0f, 0f, 0.62f), false);
            Anchor(guidance, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -228f), new Vector2(960f, 100f));
            var guidanceLayout = guidance.gameObject.AddComponent<VerticalLayoutGroup>();
            guidanceLayout.padding = new RectOffset(32, 32, 20, 20);
            guidanceLayout.childAlignment = TextAnchor.MiddleCenter;
            guidanceLayout.childControlHeight = true;
            guidanceLayout.childControlWidth = true;
            guidanceLayout.childForceExpandHeight = false;
            guidanceLayout.childForceExpandWidth = true;
            var guidanceFitter = guidance.gameObject.AddComponent<ContentSizeFitter>();
            guidanceFitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            var guidanceLabel = CreateText("Guidance Label", guidance, style, "Move your phone slowly to scan the room", 32f, FontStyles.Normal, TextAlignmentOptions.Center, Color.white);
            guidanceLabel.textWrappingMode = TextWrappingModes.Normal;

            // ---------------------------------------------------------------- tool bar (right edge)
            var toolbar = CreatePanel("Tool Bar", safeArea, style, PanelColor, true);
            Anchor(toolbar, new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(1f, 0.5f), new Vector2(-16f, 150f), new Vector2(172f, 820f));
            var toolLayout = toolbar.gameObject.AddComponent<VerticalLayoutGroup>();
            toolLayout.padding = new RectOffset(12, 12, 14, 14);
            toolLayout.spacing = 12f;
            toolLayout.childAlignment = TextAnchor.UpperCenter;
            toolLayout.childControlWidth = true;
            toolLayout.childControlHeight = true;
            toolLayout.childForceExpandWidth = true;
            toolLayout.childForceExpandHeight = true;

            var selectTool = CreateToolButton("Select Tool", toolbar, style, "Select", style.IconSelect, ChipIdle, Accent, Color.white, AccentText);
            var moveTool = CreateToolButton("Move Tool", toolbar, style, "Move", style.IconMove, ChipIdle, Accent, Color.white, AccentText);
            var rotateTool = CreateToolButton("Rotate Tool", toolbar, style, "Rotate", style.IconRotate, ChipIdle, Accent, Color.white, AccentText);
            var scaleTool = CreateToolButton("Scale Tool", toolbar, style, "Scale", style.IconScale, ChipIdle, Accent, Color.white, AccentText);
            var deleteTool = CreateToolButton("Delete Tool", toolbar, style, "Delete", style.IconDelete, DeleteIdle, DeleteIdle, DeleteContent, DeleteContent);

            // ---------------------------------------------------------------- tool options (above the catalogue)
            var options = CreateRect("Tool Options", safeArea);
            Anchor(options, new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 378f), new Vector2(-32f, 112f));

            var moveOptions = CreateOptionsRow("Move Options", options, style);
            AddRowLabel(moveOptions, style, "Move along", 200f);
            var moveConstraintButtons = new[]
            {
                CreateChip("Move Floor", moveOptions, style, "Floor", 150f),
                CreateChip("Move X", moveOptions, style, "X", 104f),
                CreateChip("Move Y", moveOptions, style, "Y", 104f),
                CreateChip("Move Z", moveOptions, style, "Z", 104f)
            };

            var rotateOptions = CreateOptionsRow("Rotate Options", options, style);
            AddRowLabel(rotateOptions, style, "Axis", 90f);
            var rotateAxisButtons = new[]
            {
                CreateChip("Rotate X", rotateOptions, style, "X", 104f),
                CreateChip("Rotate Y", rotateOptions, style, "Y", 104f),
                CreateChip("Rotate Z", rotateOptions, style, "Z", 104f)
            };
            var snapButton = CreateChip("Snap Toggle", rotateOptions, style, "Snap 15° Off", 270f);

            var scaleOptions = CreateOptionsRow("Scale Options", options, style);
            var scaleLabel = AddRowLabel(scaleOptions, style, "Size 100%", 280f);
            var resetScaleButton = CreateChip("Reset Size", scaleOptions, style, "Reset size", 240f);

            // ---------------------------------------------------------------- catalogue
            var catalogBar = CreatePanel("Catalogue", safeArea, style, PanelColor, true);
            Anchor(catalogBar, new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 16f), new Vector2(-32f, 350f));
            var header = CreateText("Header", catalogBar, style, "Furniture catalogue", 30f, FontStyles.Bold, TextAlignmentOptions.MidlineLeft, Color.white);
            Anchor(header.rectTransform, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(28f, -10f), new Vector2(520f, 52f));
            var hint = CreateText("Hint", catalogBar, style, "Tap an item, then tap a surface", 24f, FontStyles.Normal, TextAlignmentOptions.MidlineRight, new Color(1f, 1f, 1f, 0.65f));
            Anchor(hint.rectTransform, new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-28f, -10f), new Vector2(480f, 52f));

            var scrollGo = CreateRect("Scroll View", catalogBar);
            Anchor(scrollGo, new Vector2(0f, 0f), new Vector2(1f, 1f), new Vector2(0.5f, 0.5f), new Vector2(0f, -28f), new Vector2(-24f, -80f));
            var scroll = scrollGo.gameObject.AddComponent<ScrollRect>();
            scroll.horizontal = true;
            scroll.vertical = false;
            scroll.movementType = ScrollRect.MovementType.Elastic;
            scroll.inertia = true;
            scroll.scrollSensitivity = 20f;

            var viewport = CreateRect("Viewport", scrollGo);
            Stretch(viewport);
            viewport.gameObject.AddComponent<RectMask2D>();
            var viewportImage = viewport.gameObject.AddComponent<Image>();
            viewportImage.color = new Color(0f, 0f, 0f, 0f);
            viewportImage.raycastTarget = true;

            var content = CreateRect("Content", viewport);
            content.anchorMin = new Vector2(0f, 0f);
            content.anchorMax = new Vector2(0f, 1f);
            content.pivot = new Vector2(0f, 0.5f);
            content.anchoredPosition = Vector2.zero;
            content.sizeDelta = new Vector2(0f, 0f);
            var contentLayout = content.gameObject.AddComponent<HorizontalLayoutGroup>();
            contentLayout.padding = new RectOffset(8, 8, 6, 6);
            contentLayout.spacing = 16f;
            contentLayout.childAlignment = TextAnchor.MiddleLeft;
            contentLayout.childControlWidth = false;
            contentLayout.childControlHeight = false;
            contentLayout.childForceExpandWidth = false;
            contentLayout.childForceExpandHeight = false;
            content.gameObject.AddComponent<ContentSizeFitter>().horizontalFit = ContentSizeFitter.FitMode.PreferredSize;
            scroll.viewport = viewport;
            scroll.content = content;

            var cards = new List<CatalogItemView>();
            foreach (var definition in catalog.Items)
                cards.Add(CreateCatalogCard(content, style, definition));

            // ---------------------------------------------------------------- wiring
            SerializedFields.Set(hud, "m_Interaction", interaction);
            SerializedFields.Set(hud, "m_StatusLabel", statusLabel);
            SerializedFields.Set(hud, "m_StatusDot", dot);
            SerializedFields.Set(hud, "m_SelectionLabel", selectionLabel);
            SerializedFields.Set(hud, "m_GuidancePanel", guidance.gameObject);
            SerializedFields.Set(hud, "m_GuidanceLabel", guidanceLabel);
            SerializedFields.Set(hud, "m_SelectTool", selectTool);
            SerializedFields.Set(hud, "m_MoveTool", moveTool);
            SerializedFields.Set(hud, "m_RotateTool", rotateTool);
            SerializedFields.Set(hud, "m_ScaleTool", scaleTool);
            SerializedFields.Set(hud, "m_DeleteTool", deleteTool);
            SerializedFields.Set(hud, "m_MoveOptions", moveOptions.gameObject);
            SerializedFields.SetArray(hud, "m_MoveConstraintButtons", moveConstraintButtons);
            SerializedFields.Set(hud, "m_RotateOptions", rotateOptions.gameObject);
            SerializedFields.SetArray(hud, "m_RotationAxisButtons", rotateAxisButtons);
            SerializedFields.Set(hud, "m_SnapButton", snapButton);
            SerializedFields.Set(hud, "m_ScaleOptions", scaleOptions.gameObject);
            SerializedFields.Set(hud, "m_ScaleLabel", scaleLabel);
            SerializedFields.Set(hud, "m_ResetScaleButton", resetScaleButton);
            SerializedFields.SetArray(hud, "m_CatalogItems", cards.ToArray());
            SerializedFields.Set(hud, "m_SwitchSceneButton", switchButton);
            SerializedFields.SetString(hud, "m_AlternateSceneName", alternateSceneName);

            // Only the active tool's options are visible at runtime; start in Select mode.
            moveOptions.gameObject.SetActive(false);
            rotateOptions.gameObject.SetActive(false);
            scaleOptions.gameObject.SetActive(false);
            return hud;
        }

        public static EventSystem CreateEventSystem()
        {
            var go = new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
            go.GetComponent<InputSystemUIInputModule>().AssignDefaultActions();
            return go.GetComponent<EventSystem>();
        }

        // ------------------------------------------------------------------ element factories

        static CatalogItemView CreateCatalogCard(RectTransform parent, Style style, FurnitureDefinition definition)
        {
            var card = CreateRect($"Card {definition.DisplayName}", parent);
            card.sizeDelta = new Vector2(236f, 252f);
            var background = card.gameObject.AddComponent<Image>();
            background.sprite = style.Rounded;
            background.type = Image.Type.Sliced;
            background.color = ChipIdle;
            background.raycastTarget = true;
            var button = card.gameObject.AddComponent<Button>();
            ConfigureButtonTransition(button, background);

            var thumbnail = CreateImage("Thumbnail", card, definition.Thumbnail, Color.white, false);
            thumbnail.preserveAspect = true;
            Anchor(thumbnail.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -10f), new Vector2(170f, 150f));

            var nameLabel = CreateText("Name", card, style, definition.DisplayName, 28f, FontStyles.Bold, TextAlignmentOptions.Center, Color.white);
            Anchor(nameLabel.rectTransform, new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 46f), new Vector2(-16f, 40f));
            var dimensions = CreateText("Dimensions", card, style, definition.DimensionsLabel, 20f, FontStyles.Normal, TextAlignmentOptions.Center, new Color(1f, 1f, 1f, 0.75f));
            Anchor(dimensions.rectTransform, new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 12f), new Vector2(-16f, 32f));

            var view = card.gameObject.AddComponent<CatalogItemView>();
            view.Configure(definition, button, background, thumbnail, nameLabel, dimensions);
            return view;
        }

        static HudButton CreateToolButton(string name, RectTransform parent, Style style, string label, Sprite icon,
            Color idle, Color active, Color idleContent, Color activeContent)
        {
            var rect = CreateRect(name, parent);
            var background = rect.gameObject.AddComponent<Image>();
            background.sprite = style.Rounded;
            background.type = Image.Type.Sliced;
            background.raycastTarget = true;
            var button = rect.gameObject.AddComponent<Button>();
            ConfigureButtonTransition(button, background);

            var iconImage = CreateImage("Icon", rect, icon, idleContent, false);
            iconImage.preserveAspect = true;
            Anchor(iconImage.rectTransform, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -16f), new Vector2(70f, 70f));
            var text = CreateText("Label", rect, style, label, 26f, FontStyles.Bold, TextAlignmentOptions.Center, idleContent);
            Anchor(text.rectTransform, new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 12f), new Vector2(0f, 36f));

            var hudButton = rect.gameObject.AddComponent<HudButton>();
            hudButton.Configure(button, background, iconImage, text, idle, active, idleContent, activeContent);
            return hudButton;
        }

        static HudButton CreateTextButton(string name, RectTransform parent, Style style, string label, float fontSize,
            Color idle, Color active, Color idleContent, Color activeContent)
        {
            var rect = CreateRect(name, parent);
            var background = rect.gameObject.AddComponent<Image>();
            background.sprite = style.Rounded;
            background.type = Image.Type.Sliced;
            background.raycastTarget = true;
            var button = rect.gameObject.AddComponent<Button>();
            ConfigureButtonTransition(button, background);
            var text = CreateText("Label", rect, style, label, fontSize, FontStyles.Bold, TextAlignmentOptions.Center, idleContent);
            Stretch(text.rectTransform);
            var hudButton = rect.gameObject.AddComponent<HudButton>();
            hudButton.Configure(button, background, null, text, idle, active, idleContent, activeContent);
            return hudButton;
        }

        static RectTransform CreateOptionsRow(string name, RectTransform parent, Style style)
        {
            var row = CreatePanel(name, parent, style, PanelColor, true);
            Anchor(row, new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), Vector2.zero, new Vector2(0f, 112f));
            var layout = row.gameObject.AddComponent<HorizontalLayoutGroup>();
            layout.padding = new RectOffset(20, 20, 12, 12);
            layout.spacing = 12f;
            layout.childAlignment = TextAnchor.MiddleCenter;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = false;
            layout.childForceExpandHeight = true;
            row.gameObject.AddComponent<ContentSizeFitter>().horizontalFit = ContentSizeFitter.FitMode.PreferredSize;
            return row;
        }

        static TextMeshProUGUI AddRowLabel(RectTransform row, Style style, string text, float width)
        {
            var label = CreateText("Label", row, style, text, 28f, FontStyles.Bold, TextAlignmentOptions.MidlineLeft, Color.white);
            var element = label.gameObject.AddComponent<LayoutElement>();
            element.preferredWidth = width;
            return label;
        }

        static HudButton CreateChip(string name, RectTransform row, Style style, string label, float width)
        {
            var chip = CreateTextButton(name, row, style, label, 28f, ChipIdle, Accent, Color.white, AccentText);
            var element = chip.gameObject.AddComponent<LayoutElement>();
            element.preferredWidth = width;
            element.preferredHeight = 88f;
            return chip;
        }

        static RectTransform CreatePanel(string name, Transform parent, Style style, Color color, bool blocksTouches)
        {
            var rect = CreateRect(name, parent);
            var image = rect.gameObject.AddComponent<Image>();
            image.sprite = style.Rounded;
            image.type = Image.Type.Sliced;
            image.color = color;
            image.raycastTarget = blocksTouches;
            return rect;
        }

        static Image CreateImage(string name, Transform parent, Sprite sprite, Color color, bool raycastTarget)
        {
            var rect = CreateRect(name, parent);
            var image = rect.gameObject.AddComponent<Image>();
            image.sprite = sprite;
            image.color = color;
            image.raycastTarget = raycastTarget;
            return image;
        }

        static TextMeshProUGUI CreateText(string name, Transform parent, Style style, string text, float size,
            FontStyles fontStyle, TextAlignmentOptions alignment, Color color)
        {
            var rect = CreateRect(name, parent);
            var label = rect.gameObject.AddComponent<TextMeshProUGUI>();
            label.font = style.Font;
            label.text = text;
            label.fontSize = size;
            label.fontStyle = fontStyle;
            label.alignment = alignment;
            label.color = color;
            label.raycastTarget = false;
            label.textWrappingMode = TextWrappingModes.NoWrap;
            label.overflowMode = TextOverflowModes.Ellipsis;
            return label;
        }

        static void ConfigureButtonTransition(Button button, Graphic target)
        {
            button.targetGraphic = target;
            button.transition = Selectable.Transition.ColorTint;
            var colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = Color.white;
            colors.selectedColor = Color.white;
            colors.pressedColor = new Color(0.75f, 0.75f, 0.75f, 1f);
            colors.disabledColor = new Color(0.7f, 0.7f, 0.7f, 0.6f);
            colors.fadeDuration = 0.08f;
            button.colors = colors;
            var navigation = button.navigation;
            navigation.mode = Navigation.Mode.None;
            button.navigation = navigation;
        }

        static RectTransform CreateRect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = UILayer;
            var rect = (RectTransform)go.transform;
            rect.SetParent(parent, false);
            return rect;
        }

        static void Stretch(RectTransform rect)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = Vector2.zero;
        }

        static void Anchor(RectTransform rect, Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 position, Vector2 size)
        {
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.pivot = pivot;
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
        }
    }
}
