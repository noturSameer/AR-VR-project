# AR Interior Design System — Project Rules

## 1. Role and objective

Act as a senior Unity AR engineer, C# developer, 3D artist, UI/UX designer, and QA engineer.

Build a complete Android augmented-reality furniture placement application for a university project demonstration. Follow the supplied project plan as the primary source of project requirements.

The application must let users scan a real room, detect surfaces, place virtual furniture, select objects, move, rotate, scale, and delete them. It must include a polished mobile interface and a yellow-orange selection outline.

## 2. Technical baseline

- Use a Unity LTS release compatible with the selected AR Foundation and ARCore XR Plugin versions.
- Use C# and Unity UI (uGUI), Canvas, TextMeshPro, and EventSystem where appropriate.
- Target Android devices supported by ARCore.
- Keep the real AR mode separate from an Editor demo mode.
- Record the exact Unity and package versions used in the project documentation.
- Verify package compatibility before implementing features. Do not guess APIs or combine incompatible versions.
- Do not add unnecessary dependencies or Android permissions.

## 3. Required features

### AR
- AR Session and camera background.
- Plane detection and visual plane feedback.
- Raycast-based furniture placement on detected surfaces.
- Useful guidance when scanning, tracking, or surface detection is not ready.
- Graceful handling of temporary tracking loss.
- Use anchors only where they improve stability; do not create excessive anchors.

### Furniture
Provide at least five distinct furniture models:
1. Modern Chair
2. Dining Table
3. Sofa
4. Floor Lamp
5. Bookshelf

Each model must have meaningful geometry, sensible real-world dimensions in metres, an appropriate pivot, a suitable collider, materials, and a Unity prefab. Use separate model files and texture files where practical. If external model assets are unavailable, generate procedural models with multiple meaningful components. Do not represent a complete furniture model as a single plain cube.

### Selection and transforms
- Select objects by touch and allow deselection.
- Show a clear yellow-orange outline around the selected object (for example #FFB000 or #FF8C00).
- Ensure the outline works in the Android runtime and the selected render pipeline, not only as an Editor gizmo.
- Move objects using reliable surface dragging and, where implemented, real axis handles for X/Y/Z.
- Rotate around the selected axis with smooth input and optional 15-degree snapping.
- Scale uniformly and keep scale positive and within configurable minimum/maximum bounds.
- Delete the selected object safely and clear selection state.
- Prevent multiple input handlers from changing the same Transform simultaneously.

### Touch and UI
- Single touch selects; drag performs the active mode's action.
- Two-finger scaling and rotation may be implemented if reliable.
- UI touches must take priority over scene interactions.
- Prevent duplicate placement caused by repeated touch events.
- Handle mode changes and gesture cancellation cleanly.
- Provide a polished, responsive mobile UI titled “AR Interior Design”.
- Include a furniture catalogue, Select, Move, Rotate, Scale, Delete, selection status, AR status, and scanning guidance.
- Every interactive control must be connected to real functionality. Do not create decorative controls that do nothing.

## 4. Engineering rules

1. Inspect the existing repository and environment before editing.
2. Preserve existing working functionality and user files.
3. Create a short implementation plan, then execute it; do not stop at planning.
4. Work in small milestones and verify each milestone before moving on.
5. Keep scripts modular, readable, and maintainable.
6. Use explicit component references where practical and validate required references.
7. Handle null references, object destruction, event subscriptions, and resource cleanup safely.
8. Avoid unnecessary per-frame work, uncontrolled Instantiate/Destroy calls, and brittle scene searches.
9. Do not suppress exceptions with empty catch blocks.
10. Do not leave TODOs, empty methods, pseudocode, or fake implementations in delivered features.
11. Do not overwrite unrelated files.
12. Create a Git checkpoint before risky changes when Git is available.
13. Keep a list of unresolved defects and update documentation when architecture changes.
14. Never claim a feature, build, or test is complete unless the available evidence supports that claim.

## 5. Workflow

### Milestone A — Audit
- Inspect the current project, installed Unity version, available command-line tools, and existing files.
- Read the provided project plan.
- Record assumptions, dependencies, and constraints.
- Identify which checks can actually be executed in this environment.

### Milestone B — Foundation
- Establish a valid Unity project structure and compatible package manifest.
- Configure AR and Android settings where the environment permits.
- Create MainARScene and DemoScene.
- If direct scene authoring is unreliable, create an idempotent Unity Editor setup wizard that generates and wires scenes, prefabs, materials, UI, and build settings without duplicates.

### Milestone C — Models and prefabs
- Create at least five distinct furniture assets.
- Verify dimensions, pivots, colliders, materials, and catalogue references.
- Prefer independent model files and textures when practical.
- Document any procedural asset-generation method.

### Milestone D — AR and interactions
- Implement plane detection, placement, selection outline, transforms, touch priority, and deletion.
- Verify each mode independently.
- Fix conflicts before adding optional advanced gestures.

### Milestone E — UI and QA
- Finish the responsive mobile UI.
- Run available static checks, tests, and compilation.
- Inspect actual error output and fix issues.
- Re-run checks after fixes to detect regressions.

### Milestone F — Delivery
- Prepare documentation, Android build settings, and a demo script.
- Create an APK only if a real build can be performed.
- Create a ZIP archive only after checking its contents.
- Report remaining limitations honestly.

## 6. Verification standards

Use these statuses consistently:
- `PASSED`: the check was actually run and passed.
- `FAILED`: the check was run and failed.
- `NOT RUN`: the check could not be executed.

Never mark a test `PASSED` based only on code inspection. Never claim Unity compilation or Android device testing happened unless it actually happened.

When possible:
- Compile scripts with the actual Unity Editor.
- Run Unity Test Framework tests.
- Verify scene and prefab references.
- Verify every catalogue entry resolves to a real prefab.
- Verify selection outline, transforms, deletion, and UI input priority.
- Build the Android APK and confirm the output exists and is non-empty.
- Test on a physical ARCore-compatible device if one is available.

If Unity Editor, Android tooling, or a physical device is unavailable, state exactly what could not be tested and provide the next steps.

## 7. Documentation and deliverables

Maintain:
- `README.md` — setup, Unity version, opening the project, running DemoScene and MainARScene, and Android build steps.
- `Documentation/PROJECT_OVERVIEW.md` — purpose, features, technologies, limitations.
- `Documentation/ARCHITECTURE.md` — component responsibilities, dependencies, data flow, touch handling, placement, selection outline, transforms.
- `Documentation/USER_GUIDE.md` — how to use the application.
- `Documentation/DEMO_SCRIPT.md` — a 3–5 minute professor demonstration.
- `Documentation/TEST_REPORT.md` — test cases, expected and actual results, status, reproduction steps.
- `Documentation/KNOWN_LIMITATIONS.md` — unresolved limitations and untested behaviour.
- `Documentation/FINAL_DELIVERY_REPORT.md` — requirement-by-requirement delivery checklist.
- `CHANGELOG.md` — meaningful changes.
- `.gitignore` — standard Unity exclusions.

The source code must remain accessible and organized in separate files. Explain the purpose of the main classes in the documentation.

## 8. Final delivery checklist

Before declaring completion, verify:
- [ ] At least five distinct furniture models exist.
- [ ] Every model has a usable prefab and catalogue entry.
- [ ] AR plane detection and placement are implemented.
- [ ] Selection outline is yellow-orange and works at runtime.
- [ ] Select, Move, Rotate, Scale, and Delete perform real actions.
- [ ] UI touches do not accidentally interact with the scene.
- [ ] Both AR and demo scenes are present where supported by the project setup.
- [ ] Package versions and build settings are documented.
- [ ] All available tests and builds have honest results.
- [ ] Setup and professor-demo documentation is present.
- [ ] ZIP/APK outputs are reported only if they were actually created and verified.

## 9. Communication

Be concise but specific. Do not merely describe what should be done: make the changes in the working repository. If a requirement is blocked, explain why, implement the best reliable alternative, and record the limitation. At each milestone, summarize files changed, checks executed, results, and the next concrete step.
