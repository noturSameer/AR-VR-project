# Changelog

## 1.0.0 — 2026-10-23

### Added
- Unity 6000.6.5f1 project with AR Foundation 6.6.2, Google ARCore XR Plugin 6.6.2, XR Plug-in Management 4.7.0,
  URP 17.6.0, Input System 1.20.1, uGUI/TextMeshPro 2.6.0 and Unity Test Framework 1.8.0 (minimal manifest).
- Runtime systems: touch router + gesture recogniser, interaction controller, transform owner lock,
  selection manager, URP selection outline (#FFB000), X/Y/Z move gizmo, placement controller with duplicate
  guards, AR plane surface provider with one anchor per item, AR session status/guidance, demo-mode surface,
  status and orbit camera, mobile HUD.
- Five procedural furniture models (Modern Chair, Dining Table, Sofa, Floor Lamp, Bookshelf) with separate
  mesh files, generated PNG textures, URP materials, prefabs, catalogue entries and CPU-rendered thumbnails.
- URP shaders: SelectionOutline, SelectionStencilMask, UnlitColor (gizmo, plane boundary), PlaneGrid.
- Idempotent Editor setup wizard (textures, materials, models, prefabs, catalogue, URP + AR background
  feature, XR/ARCore, Android player settings, MainARScene, DemoScene, build scenes), project validator and
  APK builder with batch-mode entry points.
- 68 EditMode and 21 PlayMode tests, opt-in screenshot capture, documentation set.

### Fixed during development
- AR availability check when no XR subsystem exists (previously stuck in “Checking AR support…”).
- Catalogue reference lost after `EditorSceneManager.NewScene` during scene generation.
- Pinch emitted an update in its start frame.
- Inverted triangle winding in the box/rounded-box generator and icon triangle fill.
- Obsolete Unity 6.6 API usage; read-only URP property assignment.
- Android build intermediates excluded from version control.
