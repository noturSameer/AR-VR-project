
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using UnityEngine.InputSystem.EnhancedTouch;
using Touch = UnityEngine.InputSystem.EnhancedTouch.Touch;

public class ARFurniturePlacement : MonoBehaviour
{
    public GameObject furniturePrefab;
    public GameObject tablePrefab;
    public GameObject chairPrefab;

    public float rotationSpeed = 1f;
    public float scaleSpeed = 1f;
    public float minScale = 0.5f;
    public float maxScale = 2f;

    private ARRaycastManager raycastManager;
    private Camera arCamera;

    private GameObject selectedFurniture;
    private bool isDragging;

    private readonly List<GameObject> placedFurniture =
        new List<GameObject>();

    private static readonly List<ARRaycastHit> hits =
        new List<ARRaycastHit>();

    void Awake()
    {
        raycastManager = GetComponent<ARRaycastManager>();
        arCamera = GetComponentInChildren<Camera>();
    }

    void OnEnable()
    {
        EnhancedTouchSupport.Enable();
    }

    void OnDisable()
    {
        EnhancedTouchSupport.Disable();
    }

    void Update()
    {
        if (furniturePrefab == null ||
            raycastManager == null ||
            arCamera == null)
            return;

        var touches = Touch.activeTouches;

        if (touches.Count == 0)
        {
            isDragging = false;
            return;
        }

        // Two fingers: rotate and resize furniture
        if (touches.Count >= 2)
        {
            isDragging = false;

            if (selectedFurniture == null)
                return;

            Vector2 first = touches[0].screenPosition;
            Vector2 second = touches[1].screenPosition;

            Vector2 firstPrevious =
                first - touches[0].delta;

            Vector2 secondPrevious =
                second - touches[1].delta;

            Vector2 previousDirection =
                secondPrevious - firstPrevious;

            Vector2 currentDirection =
                second - first;

            // Rotation
            if (previousDirection.sqrMagnitude > 1f &&
                currentDirection.sqrMagnitude > 1f)
            {
                float angle = Vector2.SignedAngle(
                    previousDirection,
                    currentDirection
                );

                selectedFurniture.transform.Rotate(
                    Vector3.up,
                    -angle * rotationSpeed,
                    Space.World
                );
            }

            // Pinch to scale
            float previousDistance =
                previousDirection.magnitude;

            float currentDistance =
                currentDirection.magnitude;

            if (previousDistance > 1f &&
                currentDistance > 1f)
            {
                float scaleFactor =
                    Mathf.Pow(
                        currentDistance / previousDistance,
                        scaleSpeed
                    );

                float currentScale =
                    selectedFurniture.transform.localScale.x;

                float newScale = Mathf.Clamp(
                    currentScale * scaleFactor,
                    minScale,
                    maxScale
                );

                selectedFurniture.transform.localScale =
                    Vector3.one * newScale;
            }

            return;
        }

        var touch = touches[0];

        // Select existing furniture or create new furniture
        if (touch.phase ==
            UnityEngine.InputSystem.TouchPhase.Began)
        {
            isDragging = false;
            selectedFurniture = null;

            Ray ray = arCamera.ScreenPointToRay(
                touch.screenPosition
            );

            if (Physics.Raycast(
                ray,
                out RaycastHit hit,
                100f))
            {
                foreach (GameObject furniture in placedFurniture)
                {
                    if (furniture != null &&
                        (hit.transform == furniture.transform ||
                         hit.transform.IsChildOf(furniture.transform)))
                    {
                        selectedFurniture = furniture;
                        isDragging = true;

                        Debug.Log("Furniture selected!");
                        return;
                    }
                }
            }

            if (raycastManager.Raycast(
                touch.screenPosition,
                hits,
                TrackableType.PlaneWithinPolygon))
            {
                selectedFurniture = Instantiate(
                    furniturePrefab,
                    hits[0].pose.position,
                    Quaternion.identity
                );

                placedFurniture.Add(selectedFurniture);

                Debug.Log("Furniture created!");
            }
        }
        // Move furniture with one finger
        else if (touch.phase ==
                 UnityEngine.InputSystem.TouchPhase.Moved)
        {
            if (isDragging &&
                selectedFurniture != null)
            {
                if (raycastManager.Raycast(
                    touch.screenPosition,
                    hits,
                    TrackableType.PlaneWithinPolygon))
                {
                    selectedFurniture.transform.position =
                        hits[0].pose.position;
                }
            }
        }
        else if (touch.phase ==
                     UnityEngine.InputSystem.TouchPhase.Ended ||
                 touch.phase ==
                     UnityEngine.InputSystem.TouchPhase.Canceled)
        {
            isDragging = false;
        }
    }

    public void DeleteSelectedFurniture()
    {
        if (selectedFurniture != null)
        {
            placedFurniture.Remove(selectedFurniture);

            Destroy(selectedFurniture);

            selectedFurniture = null;
            isDragging = false;

            Debug.Log("Furniture deleted!");
        }
    }

    public void SelectTable()
    {
        if (tablePrefab == null)
        {
            Debug.LogWarning("Table Prefab is not assigned!");
            return;
        }

        furniturePrefab = tablePrefab;
        selectedFurniture = null;
        isDragging = false;

        Debug.Log("Table selected!");
    }

    public void SelectChair()
    {
        if (chairPrefab == null)
        {
            Debug.LogWarning("Chair Prefab is not assigned!");
            return;
        }

        furniturePrefab = chairPrefab;
        selectedFurniture = null;
        isDragging = false;

        Debug.Log("Chair selected!");
    }


}
