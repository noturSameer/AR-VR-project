
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class ARDebugStatus : MonoBehaviour
{
    void OnGUI()
    {
        GUI.color = Color.white;

        GUIStyle style = new GUIStyle(GUI.skin.label);
        style.fontSize = 32;
        style.normal.textColor = Color.white;

        string status =
            "AR Session: " + ARSession.state +
            "\nTracking: " + ARSession.notTrackingReason;

        GUI.Label(new Rect(30, 80, Screen.width - 60, 180),
                  status, style);
    }
}
